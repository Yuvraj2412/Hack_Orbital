#!/usr/bin/env python3
"""STEP 4 SUPPORT: ground receiver + browser WebSocket bridge.

Run this on the ground-station computer. It serves live_ground.html and accepts the
satellite computer's outbound WebSocket connection. It also writes received images to
./received/ and forwards telemetry/events to the browser in real time.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import re
from pathlib import Path
from typing import Optional

from aiohttp import web, WSMsgType

SAFE_ID = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")


class GroundState:
    def __init__(self, root: Path, received: Path):
        self.root = root
        self.received = received
        self.received.mkdir(parents=True, exist_ok=True)
        self.satellite: Optional[web.WebSocketResponse] = None
        self.ui_clients: set[web.WebSocketResponse] = set()
        self.pending_commands: list[dict] = []
        self.uploads: dict[tuple[str, str], tuple[Path, object]] = {}
        self.latest_telemetry: Optional[dict] = None
        self.recent_events: list[dict] = []
        # FIX (2026-10-31, duplicate frame_00006): recent_events was capped at
        # 80 and flooded by telemetry (every 2 sim seconds), so a UI that
        # connected late or reconnected only replayed the last delivery.
        # These two lists are kept separately, without telemetry, so a late
        # or reconnecting UI gets the full inbox and event log, not just the
        # last frame. Delivered frames are excluded from event_history
        # because they are replayed from delivered_history below.
        self.delivered_history: list[dict] = []
        self.event_history: list[dict] = []
        self.last_satellite_info: Optional[dict] = None
        self.connected = False

    async def broadcast(self, payload: dict):
        self.recent_events.append(payload)
        if len(self.recent_events) > 80:
            self.recent_events = self.recent_events[-80:]
        if payload.get("type") == "delivered":
            self.delivered_history.append(dict(payload))
            # SYNCED: a pass can deliver ~250 tiles, so the old 100 cap
            # silently dropped deliveries on replay. Cap is now 1000.
            if len(self.delivered_history) > 1000:
                self.delivered_history = self.delivered_history[-1000:]
        elif payload.get("type") not in ("telemetry", "chunk"):
            self.event_history.append(payload)
            if len(self.event_history) > 500:
                self.event_history = self.event_history[-500:]
        stale = []
        for client in tuple(self.ui_clients):
            try:
                await client.send_json(payload)
            except Exception:
                stale.append(client)
        for c in stale:
            self.ui_clients.discard(c)

    async def send_command(self, command: dict):
        if self.satellite and not self.satellite.closed:
            await self.satellite.send_json(command)
            return True
        self.pending_commands.append(command)
        return False

    async def close_upload(self, key):
        item = self.uploads.pop(key, None)
        if item:
            _, handle = item
            try:
                handle.close()
            except Exception:
                pass


async def index(request: web.Request):
    state: GroundState = request.app["state"]
    return web.FileResponse(state.root / "live_ground.html")


# FINAL ADDITION — serve the Demo/Replay console from the same server, so
# one codebase serves both screens. No new trust boundary: these are the
# same static files already in this folder, served only on the private LAN.
async def static_file(request: web.Request):
    state: GroundState = request.app["state"]
    name = request.match_info["name"]
    allowed = {"console.html", "engine.js", "manifest5.json", "Orbit-Triage-Flowchart.html"}
    if name not in allowed:
        raise web.HTTPNotFound()
    path = state.root / name
    if not path.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(path)


async def health(request: web.Request):
    state: GroundState = request.app["state"]
    return web.json_response({"ok": True, "satellite_connected": bool(state.satellite and not state.satellite.closed),
                              "received_dir": str(state.received)})


async def received_file(request: web.Request):
    state: GroundState = request.app["state"]
    name = request.match_info["name"]
    if not SAFE_ID.fullmatch(name):
        raise web.HTTPBadRequest(text="Invalid file name")
    path = state.received / name
    if not path.is_file():
        raise web.HTTPNotFound()
    return web.FileResponse(path)


async def ws_ui(request: web.Request):
    state: GroundState = request.app["state"]
    ws = web.WebSocketResponse(heartbeat=25)
    await ws.prepare(request)
    state.ui_clients.add(ws)
    await ws.send_json({"type": "connection", "satellite_connected": bool(state.satellite and not state.satellite.closed),
                        "satellite": state.last_satellite_info})
    if state.latest_telemetry:
        await ws.send_json(state.latest_telemetry)
    # Replay the full inbox first (chronological; the UI unshifts, so the
    # newest card ends up first, exactly as in a live run), then the
    # non-telemetry event log. Telemetry is already sent above as
    # latest_telemetry, so replaying it would only flood the log.
    for event in state.delivered_history:
        await ws.send_json(event)
    for event in state.event_history[-50:]:
        await ws.send_json(event)
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                except json.JSONDecodeError:
                    await ws.send_json({"type": "server_error", "message": "Invalid JSON"})
                    continue
                if data.get("type") == "command":
                    command = {"type": "command", "command": data.get("command"), "payload": data.get("payload", {})}
                    sent = await state.send_command(command)
                    await ws.send_json({"type": "command_status", "command": command.get("command"),
                                        "status": "sent to satellite" if sent else "queued until satellite reconnects"})
                elif data.get("type") == "subscribe":
                    await ws.send_json({"type": "connection", "satellite_connected": bool(state.satellite and not state.satellite.closed),
                                        "satellite": state.last_satellite_info})
            elif msg.type in (WSMsgType.CLOSED, WSMsgType.ERROR):
                break
    finally:
        state.ui_clients.discard(ws)
    return ws


async def ws_satellite(request: web.Request):
    state: GroundState = request.app["state"]
    ws = web.WebSocketResponse(heartbeat=25, max_msg_size=8 * 1024 * 1024)
    await ws.prepare(request)
    old = state.satellite
    state.satellite = ws
    state.connected = True
    if old and old is not ws and not old.closed:
        await old.close(message=b"replaced by a newer satellite session")
    await state.broadcast({"type": "satellite_connection", "connected": True})
    for command in state.pending_commands:
        await ws.send_json(command)
    state.pending_commands.clear()
    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                try:
                    data = json.loads(msg.data)
                except json.JSONDecodeError:
                    continue
                kind = data.get("type")
                if kind == "hello":
                    state.last_satellite_info = data
                    await state.broadcast({**data, "type": "satellite_hello"})
                elif kind == "telemetry":
                    state.latest_telemetry = data
                    await state.broadcast(data)
                elif kind == "frame_meta":
                    frame_id, mode = str(data.get("frame_id", "")), str(data.get("mode", ""))
                    if not SAFE_ID.fullmatch(frame_id) or mode not in ("full", "preview"):
                        await state.broadcast({"type": "server_error", "message": "Rejected unsafe frame metadata"})
                        continue
                    key = (frame_id, mode)
                    await state.close_upload(key)
                    temp_path = state.received / f".{frame_id}_{mode}.part"
                    final_path = state.received / f"{frame_id}_{mode}.jpg"
                    # A new frame_meta means a fresh transfer. In-pass interruption does not
                    # resend frame_meta, so the existing partial file remains untouched then.
                    handle = temp_path.open("w+b")
                    state.uploads[key] = (temp_path, handle)
                    await state.broadcast(data)
                elif kind == "chunk":
                    frame_id, mode = str(data.get("frame_id", "")), str(data.get("mode", ""))
                    key = (frame_id, mode)
                    item = state.uploads.get(key)
                    if not item:
                        continue
                    try:
                        raw = base64.b64decode(data.get("data", ""), validate=True)
                        offset = int(data.get("offset", 0))
                        if offset < 0 or len(raw) > 128 * 1024:
                            continue
                        _, handle = item
                        handle.seek(offset)
                        handle.write(raw)
                        handle.flush()
                    except Exception:
                        await state.broadcast({"type": "server_error", "message": f"Could not write chunk for {frame_id}"})
                elif kind == "delivered":
                    frame_id, mode = str(data.get("frame_id", "")), str(data.get("mode", ""))
                    key = (frame_id, mode)
                    item = state.uploads.get(key)
                    if item:
                        temp_path, handle = item
                        try:
                            handle.flush(); handle.close()
                        except Exception:
                            pass
                        state.uploads.pop(key, None)
                        # FIX (2026-10-31, real satellite pipeline): tiles are
                        # PNG, not JPEG. Saving PNG bytes as .jpg worked in
                        # most browsers by sniffing, but it is wrong and
                        # breaks any magic-byte check. Keep the real format.
                        ext = ".png" if data.get("content_type") == "image/png" else ".jpg"
                        final_name = f"{frame_id}_{mode}{ext}"
                        final_path = state.received / final_name
                        temp_path.replace(final_path)
                        data["image_url"] = f"/received/{final_name}"
                        await state.broadcast(data)
                        # FIX (2026-10-31, ACK blocker): the new satellite
                        # sender waits for an explicit ACK after 'delivered'
                        # and, without it, times out after 15 s and resends
                        # the same tile forever. The old ground never sent
                        # one, so every tile was delivered 3+ times in tests.
                        # This ACK is sent only to the satellite, not to UI.
                        try:
                            await ws.send_json({"type": "ack", "frame_id": frame_id, "mode": mode, "ok": True})
                        except Exception:
                            pass
                    else:
                        await state.broadcast({"type": "server_error", "message": f"Delivery event without frame data: {frame_id}"})
                        await state.broadcast(data)
                        try:
                            await ws.send_json({"type": "ack", "frame_id": frame_id, "mode": mode, "ok": False, "reason": "Delivery event without frame data"})
                        except Exception:
                            pass
                else:
                    await state.broadcast(data)
            elif msg.type in (WSMsgType.CLOSED, WSMsgType.ERROR):
                break
    finally:
        if state.satellite is ws:
            state.satellite = None
            state.connected = False
            await state.broadcast({"type": "satellite_connection", "connected": False})
    return ws


async def create_app(root: Path, received: Path):
    app = web.Application()
    app["state"] = GroundState(root, received)
    app.add_routes([
        web.get("/", index),
        web.get("/health", health),
        web.get("/received/{name}", received_file),
        web.get("/static/{name}", static_file),
        web.get("/ws/ui", ws_ui),
        web.get("/ws/satellite", ws_satellite),
    ])
    return app


def main():
    ap = argparse.ArgumentParser(description="Ground station receiver and live browser bridge")
    ap.add_argument("--host", default="0.0.0.0", help="Use 0.0.0.0 to accept LAN connections")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--web-root", default=str(Path(__file__).resolve().parent), help="Folder containing live_ground.html")
    ap.add_argument("--received-dir", default="received", help="Folder where completed downlinked images are saved")
    a = ap.parse_args()
    root = Path(a.web_root).expanduser().resolve()
    received = Path(a.received_dir).expanduser().resolve()
    if not (root / "live_ground.html").is_file():
        raise FileNotFoundError(f"live_ground.html not found in {root}")
    print(f"Ground receiver listening on http://{a.host}:{a.port}/")
    print(f"Satellite endpoint: ws://<GROUND-IP>:{a.port}/ws/satellite")
    print(f"Saving received files in: {received}")
    web.run_app(create_app(root, received), host=a.host, port=a.port, print=None)


if __name__ == "__main__":
    main()
