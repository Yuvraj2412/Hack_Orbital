import argparse
import asyncio
from pathlib import Path

from inference.inference_engine import SatelliteInferenceEngine
from scheduler import SmartDownlinkScheduler
from acquisition.image_source import ImageFolderIngestor
from storage.queue_manager import QueueManager
from downlink.pass_controller import PassController
from downlink.satellite_ws_client import SatelliteWebSocketClient

SATELLITE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = SATELLITE_DIR / "storage"


def parse_args():
    parser = argparse.ArgumentParser(description="Continuous satellite simulation")

    parser.add_argument("--incoming", default=str(STORAGE_DIR / "incoming"))

    parser.add_argument("--ground", required=True, help="Ground station WebSocket URL")

    parser.add_argument("--poll-interval", type=float, default=2.0)
    # SYNCED: 0.1 s, not 0.5 s, so a feeder dropping one image per second
    # does not waste half a second per file on stability checks.
    parser.add_argument("--stable-wait", type=float, default=0.1)

    # SYNCED mission flags. --interest is the new name; --requested is kept
    # as an alias for old scripts. If both are given, --interest wins.
    parser.add_argument(
        "--interest",
        nargs="*",
        default=None,
        choices=["Forest", "Cropland", "Urban", "Water", "Cloud", "Ship"],
        help="Mission interest classes (CloudShadow is not a mission target)",
    )
    parser.add_argument(
        "--requested",
        nargs="*",
        default=None,
        choices=["Forest", "Cropland", "Urban", "Water", "Ship"],
        help="Deprecated alias for --interest",
    )
    parser.add_argument("--picky", type=float, default=0.70)
    parser.add_argument("--band", type=float, default=0.20)

    # Deprecated, ignored: hard cloud/shadow dropping is removed in the
    # synced scheduler. Kept only so old commands do not crash.
    parser.add_argument("--cloud-threshold", type=float, default=0.80, help="Deprecated, ignored")
    parser.add_argument("--shadow-threshold", type=float, default=0.80, help="Deprecated, ignored")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--cpu", action="store_true")

    # Simulated orbital pass settings
    parser.add_argument("--first-pass", type=float, default=10.0)
    parser.add_argument("--pass-period", type=float, default=120.0)
    parser.add_argument("--pass-length", type=float, default=60.0)
    parser.add_argument("--peak-kbps", type=float, default=256.0)

    # Transmission settings
    parser.add_argument("--packet-bytes", type=int, default=1024)
    parser.add_argument("--ack-timeout", type=float, default=15.0)

    return parser.parse_args()


async def async_main():

    args = parse_args()

    if args.poll_interval <= 0:
        raise ValueError("poll interval must be positive")

    incoming = Path(args.incoming).expanduser().resolve()

    STORAGE_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Load ONNX inference engine
    print("\n[1] Loading ONNX inference engine")

    engine = SatelliteInferenceEngine(batch_size=args.batch_size, use_cuda=not args.cpu)

    # 2. Load persistent SQLite queue
    print("\n[2] Loading SQLite queue")

    queue = QueueManager(STORAGE_DIR / "queue.db")

    # 3. Initialize scheduler (SYNCED: relevance + picky/band, no hard drops)
    print("\n[3] Initializing scheduler")

    interest = args.interest if args.interest is not None else args.requested
    scheduler = SmartDownlinkScheduler(
        interest=interest,
        picky=args.picky,
        band=args.band,
        queue_manager=queue,
    )
    print("Mission profile:", scheduler.profile)

    # Shared timing for telemetry (ingestor writes, ws_client reads).
    timing: dict = {}

    # 5. Initialize pass controller FIRST, so its monotonic start is the
    # shared mission epoch for capture_t, telemetry t and latency_s.
    pass_controller = PassController(
        first_pass_s=args.first_pass,
        pass_period_s=args.pass_period,
        pass_duration_s=args.pass_length,
        peak_kbps=args.peak_kbps,
    )

    # 4. Initialize image acquisition
    print("\n[4] Initializing image acquisition")

    ingestor = ImageFolderIngestor(
        incoming_dir=incoming,
        tile_dir=STORAGE_DIR / "tiles",
        archive_dir=STORAGE_DIR / "archive",
        metadata_dir=STORAGE_DIR / "metadata",
        engine=engine,
        scheduler=scheduler,
        stable_wait_s=args.stable_wait,
        mission_epoch_monotonic=pass_controller.started_at,
        timing=timing,
    )

    def recycle() -> dict:
        """New cycle: archive images go back to incoming, queue resets.

        Safe only when no tile is currently SENDING. At pass start,
        before the first claim, SENDING is 0 even though in_pass is
        True, so a pass-start recycle is allowed. A mid-pass new_cycle
        while a tile is in flight is refused, to avoid deleting the
        row of the tile being sent.
        Steps: clear queue rows, delete processed markers, delete tiles/
        and metadata/*.json, copy archive/ -> incoming/. Ingestor then
        re-processes them under the current (or new) mission profile.
        Archive originals are kept as the source; they are NOT deleted.
        """
        import shutil

        sending = queue.get_queue_statistics().get("SENDING", {}).get("count", 0)
        if sending:
            return {"error": "Cannot recycle while a tile is sending; wait for pass end"}
        cleared = queue.reset_queue()
        markers_dir = STORAGE_DIR / "metadata" / "processed_markers"
        markers = 0
        if markers_dir.is_dir():
            for f in markers_dir.glob("*.json"):
                try:
                    f.unlink()
                    markers += 1
                except Exception:
                    pass
        tiles_deleted = 0
        tiles_dir = STORAGE_DIR / "tiles"
        if tiles_dir.is_dir():
            for child in tiles_dir.iterdir():
                if child.is_dir():
                    shutil.rmtree(child, ignore_errors=True)
                    tiles_deleted += 1
                elif child.is_file():
                    child.unlink(missing_ok=True)
                    tiles_deleted += 1
        meta_deleted = 0
        meta_dir = STORAGE_DIR / "metadata"
        if meta_dir.is_dir():
            for f in meta_dir.glob("*.json"):
                try:
                    f.unlink()
                    meta_deleted += 1
                except Exception:
                    pass
        copied = 0
        archive_dir = STORAGE_DIR / "archive"
        incoming_dir = incoming
        incoming_dir.mkdir(parents=True, exist_ok=True)
        if archive_dir.is_dir():
            for src in sorted(archive_dir.iterdir()):
                if src.is_file() and src.suffix.lower() in (".jpg", ".jpeg", ".png"):
                    dst = incoming_dir / src.name
                    if not dst.exists():
                        shutil.copy2(src, dst)
                        copied += 1
        return {
            "cleared_rows": cleared,
            "markers_deleted": markers,
            "tiles_deleted": tiles_deleted,
            "metadata_deleted": meta_deleted,
            "copied_to_incoming": copied,
        }

    # 6. Initialize WebSocket downlink
    downlink = SatelliteWebSocketClient(
        queue=queue,
        ground_url=args.ground,
        pass_controller=pass_controller,
        packet_bytes=args.packet_bytes,
        ack_timeout_s=args.ack_timeout,
        scheduler=scheduler,
        mission_start_monotonic=pass_controller.started_at,
        recycle_callback=recycle,
        timing=timing,
    )

    # Run downlink independently from image acquisition
    downlink_task = asyncio.create_task(downlink.run_forever())

    print("\n======================================")
    print("SATELLITE SIMULATION STARTED")
    print("======================================")
    print("Incoming folder:", incoming)
    print("Queue database:", STORAGE_DIR / "queue.db")
    print("Ground station:", args.ground)
    print("First pass:", args.first_pass, "seconds")
    print("Pass period:", args.pass_period, "seconds")
    print("Pass duration:", args.pass_length, "seconds")
    print("Peak bandwidth:", args.peak_kbps, "kbps")
    print("SYNCED: passes are AUTOMATIC on range. There is no Open-pass")
    print("button in the ground UI. A mission chosen on ground applies at")
    print("the NEXT pass start; if none is chosen, the old mission continues.")
    print("Press Ctrl+C to stop.")
    print("======================================\n")

    try:

        while True:

            # Detect and process newly arrived images
            reports = await asyncio.to_thread(ingestor.process_available)

            if reports:
                print(f"\n[ACQUISITION] Processed " f"{len(reports)} image(s)")

                print("[QUEUE STATUS]", queue.get_queue_statistics())

            await asyncio.sleep(args.poll_interval)

    finally:

        print("\n[STOP] Stopping satellite simulation")

        downlink.stop()
        downlink_task.cancel()

        await asyncio.gather(downlink_task, return_exceptions=True)

        print("[FINAL QUEUE]")
        print(queue.get_queue_statistics())


def main():

    try:
        asyncio.run(async_main())

    except KeyboardInterrupt:
        print("\nSatellite simulation stopped.")


if __name__ == "__main__":
    main()
