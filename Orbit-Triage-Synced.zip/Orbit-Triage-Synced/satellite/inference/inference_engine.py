import argparse
import json

from pathlib import Path

import numpy as np
import onnxruntime as ort

try:
    from .preprocessing import preprocess_image
except ImportError:
    from preprocessing import preprocess_image


CLASSES = [
    "Forest",
    "Cropland",
    "Urban",
    "Water",
    "Cloud",
    "CloudShadow",
    "Ship",
]

SATELLITE_DIR = Path(__file__).resolve().parents[1]

DEFAULT_MODEL_PATH = SATELLITE_DIR / "model" / "model_qat_int8_packed.onnx"


class SatelliteInferenceEngine:
    def __init__(self, model_path=DEFAULT_MODEL_PATH, batch_size=32, use_cuda=True):

        self.model_path = Path(model_path).expanduser().resolve()

        if not self.model_path.is_file():
            raise FileNotFoundError(f"ONNX model not found: {self.model_path}")

        if batch_size <= 0:
            raise ValueError("batch_size must be positive")

        self.batch_size = batch_size

        # Use CUDA when ONNX Runtime supports it.
        available = ort.get_available_providers()

        if use_cuda and "CUDAExecutionProvider" in available:
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        else:
            providers = ["CPUExecutionProvider"]

        options = ort.SessionOptions()
        options.log_severity_level = 3

        self.session = ort.InferenceSession(
            str(self.model_path), sess_options=options, providers=providers
        )

        inputs = self.session.get_inputs()
        outputs = self.session.get_outputs()

        if len(inputs) != 1 or len(outputs) != 1:
            raise RuntimeError("Expected one input and one output from the ONNX model")

        self.input_name = inputs[0].name
        self.output_name = outputs[0].name

        input_shape = inputs[0].shape
        output_shape = outputs[0].shape

        # Check the model input contract.
        if len(input_shape) != 4:
            raise RuntimeError(f"Expected NCHW input, got {input_shape}")

        if isinstance(input_shape[1], int) and input_shape[1] != 3:
            raise RuntimeError(f"Expected 3 input channels, got {input_shape}")

        if any(
            isinstance(input_shape[i], int) and input_shape[i] != 64 for i in (2, 3)
        ):
            raise RuntimeError(f"Expected 64x64 input tiles, got {input_shape}")

        # Reject the old seven-class model.
        output_classes = output_shape[-1]

        if isinstance(output_classes, int) and output_classes != len(CLASSES):
            raise RuntimeError(
                f"Model produces {output_classes} outputs. "
                f"This inference engine expects {len(CLASSES)} outputs."
            )

        print("ONNX model loaded:", self.model_path)
        print("Providers:", self.session.get_providers())
        print("Input:", input_shape)
        print("Output:", output_shape)

    @staticmethod
    def sigmoid(logits):

        logits = np.clip(logits.astype(np.float32), -80.0, 80.0)

        return 1.0 / (1.0 + np.exp(-logits))

    def classify_image(self, image_path, tile_output_dir=None):
        """
        Classifies an image tile-by-tile.

        Returns:
            Overall mean tile scores
            Maximum tile scores
            Individual tile predictions
        """

        batch, tile_info = preprocess_image(image_path, save_dir=tile_output_dir)

        all_probabilities = []

        # Run inference in batches.
        for start in range(0, len(batch), self.batch_size):

            batch_x = np.ascontiguousarray(
                batch[start : start + self.batch_size], dtype=np.float32
            )

            logits = self.session.run([self.output_name], {self.input_name: batch_x})[0]

            logits = np.asarray(logits)

            if logits.ndim != 2 or logits.shape[1] != len(CLASSES):
                raise RuntimeError(
                    f"Expected model output (batch, 6), got {logits.shape}"
                )

            probabilities = self.sigmoid(logits)

            all_probabilities.append(probabilities)

        tile_probabilities = np.concatenate(all_probabilities, axis=0)

        if len(tile_probabilities) != len(tile_info):
            raise RuntimeError("Prediction count does not match tile count")

        # Aggregate tile scores for the complete image.
        mean_scores = tile_probabilities.mean(axis=0)
        max_scores = tile_probabilities.max(axis=0)

        tile_results = []

        for info, scores in zip(tile_info, tile_probabilities):

            top_index = int(np.argmax(scores))

            tile_results.append(
                {
                    **info,
                    "top_scoring_class": CLASSES[top_index],
                    "top_scoring_score": float(scores[top_index]),
                    "scores": {
                        name: float(score) for name, score in zip(CLASSES, scores)
                    },
                }
            )

        dominant_index = int(np.argmax(mean_scores))

        result = {
            "image_path": str(Path(image_path).resolve()),
            "num_tiles": len(tile_results),
            "top_scoring_class": CLASSES[dominant_index],
            "top_scoring_mean_tile_score": float(mean_scores[dominant_index]),
            "mean_tile_scores": {
                name: float(score) for name, score in zip(CLASSES, mean_scores)
            },
            "max_tile_scores": {
                name: float(score) for name, score in zip(CLASSES, max_scores)
            },
            "tiles": tile_results,
        }

        return result


# Command-line entry point.
def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("image", help="Path to an RGB JPG or PNG image")

    parser.add_argument("--model", default=str(DEFAULT_MODEL_PATH))

    parser.add_argument("--batch-size", type=int, default=32)

    parser.add_argument("--cpu", action="store_true")

    args = parser.parse_args()

    engine = SatelliteInferenceEngine(
        model_path=args.model, batch_size=args.batch_size, use_cuda=not args.cpu
    )

    result = engine.classify_image(args.image)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
