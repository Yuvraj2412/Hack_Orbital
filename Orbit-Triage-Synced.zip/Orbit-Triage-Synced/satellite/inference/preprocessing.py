from pathlib import Path

import numpy as np
from PIL import Image

TILE_SIZE = 64


def preprocess_image(image_path, tile_size=TILE_SIZE, save_dir=None):
    """
    Returns:
        batch:
            float32 array, shape (N, 3, 64, 64), values in [0, 1]

        tile_info:
            Coordinates and dimensions of each extracted tile.
    """

    image_path = Path(image_path).expanduser().resolve()

    if not image_path.is_file():
        raise FileNotFoundError(f"Image not found: {image_path}")

    if tile_size <= 0:
        raise ValueError("tile_size must be positive")
    if save_dir is not None:
        save_dir = Path(save_dir).expanduser().resolve()
        save_dir.mkdir(parents=True, exist_ok=True)
    try:
        with Image.open(image_path) as image:
            image = image.convert("RGB")
    except Exception as exc:
        raise ValueError(f"Could not read image: {exc}") from exc

    original_width, original_height = image.size

    # For images smaller than 64 pixels, enlarge proportionally.
    scale = max(1.0, tile_size / original_width, tile_size / original_height)

    if scale > 1.0:
        new_size = (
            max(tile_size, int(round(original_width * scale))),
            max(tile_size, int(round(original_height * scale))),
        )

        image = image.resize(new_size, Image.Resampling.BICUBIC)

    # RGB image: H x W x 3
    image_array = np.asarray(image, dtype=np.uint8)

    height, width, channels = image_array.shape

    if channels != 3:
        raise ValueError(f"Expected RGB image, got {channels} channels")

    tiles = []
    tile_info = []

    tile_index = 0

    for y in range(0, height, tile_size):
        for x in range(0, width, tile_size):

            tile = image_array[y : y + tile_size, x : x + tile_size]

            valid_height, valid_width = tile.shape[:2]

            # Pad incomplete tiles at the right/bottom edges.
            pad_height = tile_size - valid_height
            pad_width = tile_size - valid_width

            if pad_height or pad_width:
                tile = np.pad(
                    tile, ((0, pad_height), (0, pad_width), (0, 0)), mode="edge"
                )

            tiles.append(tile)

            tile_record = {
                "tile_id": tile_index,
                "x": x,
                "y": y,
                "valid_width": valid_width,
                "valid_height": valid_height,
            }

            # Save the actual tile for storage and later downlink.
            if save_dir is not None:
                tile_path = save_dir / f"tile_{tile_index:06d}.png"

                Image.fromarray(tile).save(tile_path, format="PNG")

                tile_record["image_ref"] = str(tile_path)

            # IMPORTANT: store metadata for this tile
            tile_info.append(tile_record)

            tile_index += 1

    # NHWC uint8 -> NCHW float32 [0, 1]
    batch = np.stack(tiles, axis=0)
    batch = batch.transpose(0, 3, 1, 2)
    batch = np.ascontiguousarray(batch, dtype=np.float32) / 255.0

    return batch, tile_info
