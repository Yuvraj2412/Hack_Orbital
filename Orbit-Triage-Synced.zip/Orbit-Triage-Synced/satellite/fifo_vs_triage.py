#!/usr/bin/env python3
"""fifo_vs_triage.py -- real-data FIFO vs triage comparison, satellite side.

For ONE pass, compare what triage actually delivered against what FIFO
(capture order) would have delivered with the SAME byte budget.

Budget: bytes actually ACKED in that pass (sum of estimated_wire_bytes
for ACKED tiles with that pass_id). If --pass-id is not given, the
latest pass_id in the DB is used.

Relevance: computed from stored scores_json with the SAME formula as
the synced scheduler (interest sum minus Cloud/CloudShadow unless in
interest), with --interest / --picky / --band. A tile is "mission
relevant" if relevance >= picky + band (priority 1, MISSION).

Truth: uses tile_metadata.original_image_id / original_tile_id, which
are kept on the satellite for scoring. The ground UI never sees those
names (it sees neutral IMG#### IDs).

Usage:
    python3 fifo_vs_triage.py --db storage/queue.db --pass-id PASS_0001 \
        --interest Forest Cropland --picky 0.70 --band 0.20

This is NOT the Demo console comparison. That one uses simulated sizes
from manifest5.json. This one uses real tile sizes and real model scores.
"""
from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from scheduler import relevance_for
except Exception:
    # Fallback copy of the formula, in case scheduler cannot be imported.
    def relevance_for(scores, profile):
        interest = set(profile.get("interest") or [])
        s = sum(float(scores.get(c, 0.0)) for c in interest)
        for adv in ("Cloud", "CloudShadow"):
            if adv not in interest:
                s -= float(scores.get(adv, 0.0))
        return s


def main() -> int:
    ap = argparse.ArgumentParser(description="FIFO vs triage, real data, one pass")
    ap.add_argument("--db", default="storage/queue.db")
    ap.add_argument("--pass-id", default=None, help="e.g. PASS_0001. Default: latest pass_id")
    ap.add_argument("--interest", nargs="*", default=["Forest", "Cropland"])
    ap.add_argument("--picky", type=float, default=0.70)
    ap.add_argument("--band", type=float, default=0.20)
    args = ap.parse_args()
    profile = {"interest": args.interest, "picky": args.picky, "band": args.band}
    con = sqlite3.connect(args.db)
    con.row_factory = sqlite3.Row
    if args.pass_id is None:
        row = con.execute(
            "SELECT pass_id FROM tiles WHERE pass_id IS NOT NULL ORDER BY pass_id DESC LIMIT 1"
        ).fetchone()
        if row is None:
            print("No pass_id in DB yet (no pass has claimed tiles).")
            return 2
        args.pass_id = row["pass_id"]
    rows = con.execute("SELECT * FROM tiles ORDER BY created_at ASC, tile_id ASC").fetchall()
    if not rows:
        print("Queue DB is empty.")
        return 2
    # Triage actually delivered in this pass
    acked = [r for r in rows if r["status"] == "ACKED" and r["pass_id"] == args.pass_id]
    budget = sum(int(r["estimated_wire_bytes"]) for r in acked)
    def is_relevant(r) -> bool:
        scores = json.loads(r["scores_json"])
        return relevance_for(scores, profile) >= args.picky + args.band
    triage_relevant = sum(1 for r in acked if is_relevant(r))
    # FIFO: capture order, fill the same budget, in created_at order.
    # Capture order is created_at (DB insert order); for tiles ingested in
    # the same batch, tile_id breaks ties deterministically.
    fifo = []
    used = 0
    for r in rows:
        w = int(r["estimated_wire_bytes"])
        if used + w <= budget or not fifo:
            fifo.append(r)
            used += w
        if used >= budget:
            break
    fifo_relevant = sum(1 for r in fifo if is_relevant(r))
    total_relevant = sum(1 for r in rows if is_relevant(r))
    print(f"Pass: {args.pass_id}")
    print(f"Mission: interest={args.interest}, picky={args.picky}, band={args.band}")
    print(f"Byte budget (ACKED in this pass): {budget} bytes")
    print(f"Triage delivered: {len(acked)} tiles, {triage_relevant} mission-relevant")
    print(f"FIFO would deliver: {len(fifo)} tiles, {fifo_relevant} mission-relevant")
    print(f"Mission-relevant tiles in whole queue: {total_relevant} / {len(rows)}")
    print(f"Gain: triage delivered {triage_relevant - fifo_relevant} more relevant tiles than FIFO")
    print("Triage IDs:", [r["tile_id"] for r in acked])
    print("FIFO IDs:  ", [r["tile_id"] for r in fifo])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
