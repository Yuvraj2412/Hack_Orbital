"""Folder-based image acquisition for the satellite simulation.

Drop source JPG/PNG/TIFF images into storage/incoming/. Each stable image is
processed once: tile extraction -> ONNX inference -> persistent scheduler queue.
Original images are retained in storage/archive/ after successful processing.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp"}


class ImageFolderIngestor:
    def __init__(
        self,
        incoming_dir: str | Path,
        tile_dir: str | Path,
        archive_dir: str | Path,
        metadata_dir: str | Path,
        engine: Any,
        scheduler: Any,
        stable_wait_s: float = 0.5,
        mission_epoch_monotonic: float | None = None,
        timing: dict | None = None,
    ) -> None:
        self.incoming_dir = Path(incoming_dir).expanduser().resolve()
        self.tile_dir = Path(tile_dir).expanduser().resolve()
        self.archive_dir = Path(archive_dir).expanduser().resolve()
        self.metadata_dir = Path(metadata_dir).expanduser().resolve()
        self.processed_dir = self.metadata_dir / "processed_markers"

        for directory in (
            self.incoming_dir,
            self.tile_dir,
            self.archive_dir,
            self.metadata_dir,
            self.processed_dir,
        ):
            directory.mkdir(parents=True, exist_ok=True)

        self.engine = engine
        self.scheduler = scheduler
        self.stable_wait_s = max(0.0, float(stable_wait_s))
        # Shared monotonic epoch with pass_controller, so capture_t is
        # mission-elapsed seconds, not wall-clock time (the two laptops'
        # clocks may differ). None = capture_t_elapsed is not recorded.
        self.mission_epoch_monotonic = mission_epoch_monotonic
        self.timing = timing

    def _file_fingerprint(self, source: Path) -> str:
        digest = hashlib.sha256()
        with source.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()

    def _marker_path(self, source: Path) -> Path:
        # Content-based marker: a later image with the same filename is still processed.
        return self.processed_dir / f"{self._file_fingerprint(source)}.json"

    def _is_stable(self, path: Path) -> bool:
        try:
            first = path.stat()
            if first.st_size <= 0:
                return False
            if self.stable_wait_s:
                time.sleep(self.stable_wait_s)
            second = path.stat()
            return (
                first.st_size == second.st_size
                and first.st_mtime_ns == second.st_mtime_ns
            )
        except (FileNotFoundError, PermissionError):
            return False

    def find_unprocessed(self) -> list[Path]:
        candidates = []
        for path in sorted(self.incoming_dir.iterdir()):
            if not path.is_file() or path.suffix.lower() not in IMAGE_EXTENSIONS:
                continue
            if self._marker_path(path).exists():
                continue
            if self._is_stable(path):
                candidates.append(path)
        return candidates

    def process_image(self, source: str | Path) -> dict[str, Any]:
        source = Path(source).expanduser().resolve()
        if source.parent != self.incoming_dir:
            raise ValueError(f"Image must be directly inside {self.incoming_dir}")
        if not source.is_file():
            raise FileNotFoundError(source)

        image_fingerprint = self._file_fingerprint(source)
        image_id = f"{source.stem}_{image_fingerprint[:10]}"
        tile_output_dir = self.tile_dir / image_id
        archive_path = self.archive_dir / f"{image_id}{source.suffix.lower()}"
        marker_path = self._marker_path(source)

        print(f"\n[ACQUISITION] Processing {source.name}")

        # SYNCED: capture time = when the image arrived, in mission time.
        # capture_t_elapsed is monotonic seconds since pass_controller start;
        # capture_utc is a human-readable wall-clock string for logs.
        if self.mission_epoch_monotonic is not None:
            capture_t_elapsed = round(time.monotonic() - self.mission_epoch_monotonic, 3)
        else:
            capture_t_elapsed = None
        capture_info = {
            "capture_t_elapsed": capture_t_elapsed,
            "capture_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "capture_source": source.name,
        }

        # Keep the original image; inference works on the original path.
        # Time the classification for telemetry (mean/last ms).
        _t0 = time.perf_counter()
        inference_result = self.engine.classify_image(
            source,
            tile_output_dir=tile_output_dir,
        )
        _ms = (time.perf_counter() - _t0) * 1000.0
        if self.timing is not None:
            self.timing["count"] = int(self.timing.get("count", 0)) + 1
            self.timing["last_ms"] = round(_ms, 1)
            total = float(self.timing.get("_total_ms", 0.0)) + _ms
            self.timing["_total_ms"] = total
            self.timing["mean_ms"] = round(total / self.timing["count"], 1)

        scheduling_results = self.scheduler.process_inference_result(
            inference_result,
            image_id=image_id,
            capture_info=capture_info,
        )

        report = {
            "image_id": image_id,
            "source_image": str(source),
            "num_tiles": inference_result["num_tiles"],
            "mean_tile_scores": inference_result["mean_tile_scores"],
            "max_tile_scores": inference_result["max_tile_scores"],
            "scheduler_results": scheduling_results,
            "queue_statistics": self.scheduler.get_queue_statistics(),
            "processed_at_unix": time.time(),
        }

        metadata_path = self.metadata_dir / f"{image_id}.json"
        temp_metadata = metadata_path.with_suffix(".json.tmp")
        temp_metadata.write_text(json.dumps(report, indent=2), encoding="utf-8")
        temp_metadata.replace(metadata_path)

        # Archive source after queue records have been committed.
        if archive_path.exists():
            archive_path = self.archive_dir / (
                f"{source.stem}_{int(source.stat().st_mtime)}{source.suffix}"
            )
        shutil.move(str(source), str(archive_path))

        report["archived_image"] = str(archive_path)
        marker_path.write_text(
            json.dumps(
                {
                    "image_id": image_id,
                    "archived_image": str(archive_path),
                    "metadata": str(metadata_path),
                    "processed_at_unix": report["processed_at_unix"],
                },
                indent=2,
            ),
            encoding="utf-8",
        )

        print(
            f"[ACQUISITION] {image_id}: {report['num_tiles']} tiles | "
            f"queued={sum(x['status'] == 'Queued' for x in scheduling_results)} | "
            f"dropped={sum(x['status'] == 'Dropped' for x in scheduling_results)}"
        )
        return report

    def process_available(self) -> list[dict[str, Any]]:
        reports = []
        for source in self.find_unprocessed():
            try:
                reports.append(self.process_image(source))
            except Exception as exc:
                # Do not mark it processed; the next polling cycle can retry it.
                print(f"[ACQUISITION ERROR] {source.name}: {type(exc).__name__}: {exc}")
        return reports
