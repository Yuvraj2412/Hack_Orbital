"""SYNCED satellite tile scheduler.

What changed vs the shipped version, and why:

* 7 classes are KEPT (user decision, 2026-10-31). No 6-class re-export.
  CLASSES = Forest, Cropland, Urban, Water, Cloud, CloudShadow, Ship.
  INTEREST_CLASSES = all of those except CloudShadow. CloudShadow is an
  adverse observation, never a mission target, so the ground UI does not
  offer it as a selectable mission class. Its score still affects relevance.
* No dropping at ingest, and no hard cloud/shadow thresholds. Every tile
  is stored with its raw scores. A tile that is not mission-relevant now
  is HELD onboard (DB status DROPPED, tile file kept on disk), NOT deleted,
  so a later mission can bring it back via re-rank.
* One decision function, copied from the UI team's SatelliteAgent:
      relevance = sum(interest scores)
                  - Cloud score (unless Cloud is in interest)
                  - CloudShadow score (unless CloudShadow is in interest)
      relevance >= picky + band  -> priority 1, MISSION, sendable
      relevance <= picky - band  -> priority 3, HELD, kept onboard
      otherwise                  -> priority 2, AMBIGUOUS, sendable (later)
  Defaults picky=0.70, band=0.20 (same as the UI).
* apply_profile(profile) swaps the active profile and re-ranks every
  PENDING / RETRY / DROPPED row from its stored scores_json, in one
  transaction. Held tiles can move back to PENDING. SENDING / ACKED
  rows are never touched.
* Tile IDs are neutral: IMG<hash>_<index>. The original, label-bearing
  name is kept only in tile_metadata.original_tile_id / original_image_id
  for scoring / FIFO truth on the satellite, and is never used as the
  frame_id sent to ground.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path
from typing import Any

try:
    from .storage.queue_manager import QueueManager
except ImportError:
    from storage.queue_manager import QueueManager


CLASSES = [
    "Forest",
    "Cropland",
    "Urban",
    "Water",
    "Cloud",
    "CloudShadow",
    "Ship",
]

# Kept for backward compatibility; predicted_class is now argmax over all
# CLASSES (see process_tile), not over TARGET_CLASSES.
TARGET_CLASSES = ["Forest", "Cropland", "Urban", "Water", "Ship"]

# Selectable mission classes. CloudShadow is excluded on purpose: it is
# an adverse observation, not a target a ground operator would request.
INTEREST_CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "Ship"]

ADVERSE_CLASSES = ["Cloud", "CloudShadow"]


def relevance_for(scores: dict[str, float], profile: dict[str, Any]) -> float:
    """UI-team relevance: interest sum minus adverse scores not in interest."""
    interest = set(profile.get("interest") or [])
    score = sum(float(scores.get(c, 0.0)) for c in interest)
    for adverse in ADVERSE_CLASSES:
        if adverse not in interest:
            score -= float(scores.get(adverse, 0.0))
    return score


def decide(scores: dict[str, float], profile: dict[str, Any]):
    """Return (priority, priority_name, relevance, db_status)."""
    relevance = relevance_for(scores, profile)
    picky = float(profile.get("picky", 0.70))
    band = float(profile.get("band", 0.20))
    if relevance >= picky + band:
        return 1, "MISSION", relevance, "PENDING"
    if relevance <= picky - band:
        return 3, "HELD", relevance, "DROPPED"
    return 2, "AMBIGUOUS", relevance, "PENDING"


class SmartDownlinkScheduler:
    def __init__(
        self,
        requested_classes: list[str] | None = None,
        interest: list[str] | None = None,
        picky: float = 0.70,
        band: float = 0.20,
        queue_manager: QueueManager | None = None,
        # Deprecated, ignored: hard cloud/shadow dropping is removed.
        cloud_drop_threshold: float | None = None,
        shadow_drop_threshold: float | None = None,
        ambiguous_low: float | None = None,
        ambiguous_high: float | None = None,
    ) -> None:
        chosen = interest if interest is not None else requested_classes
        if chosen is None:
            chosen = ["Forest", "Cropland", "Urban", "Water"]
        chosen = [str(c) for c in chosen]
        invalid = [c for c in chosen if c not in INTEREST_CLASSES]
        if invalid:
            raise ValueError(
                f"Invalid mission classes: {invalid}. "
                f"Allowed (interest) classes: {INTEREST_CLASSES}. "
                f"CloudShadow is not a mission target."
            )
        self.profile: dict[str, Any] = {
            "interest": list(chosen),
            "picky": float(picky),
            "band": float(band),
        }
        # Backward-compat alias used by older callers.
        self.requested = set(chosen)
        self.queue_manager = queue_manager or QueueManager(
            Path(__file__).resolve().parent / "storage" / "queue.db"
        )
        self.queued_count = 0
        self.dropped_count = 0
        self.held_count = 0
        self.duplicate_count = 0

    def apply_profile(self, profile: dict[str, Any]) -> dict[str, Any]:
        """Swap the active profile and re-rank the whole waiting queue.

        profile = {"interest": [...], "picky": 0.70, "band": 0.20}
        Interest entries outside INTEREST_CLASSES are dropped (e.g.
        CloudShadow). If that leaves nothing, the old interest is kept.
        """
        interest = [
            str(c) for c in (profile.get("interest") or []) if str(c) in INTEREST_CLASSES
        ]
        if not interest:
            interest = list(self.profile["interest"])
        new_profile = {
            "interest": interest,
            "picky": float(profile.get("picky", self.profile["picky"])),
            "band": float(profile.get("band", self.profile["band"])),
        }
        self.profile = new_profile
        self.requested = set(interest)

        def _fn(scores, _meta):
            return decide(scores, new_profile)

        stats = self.queue_manager.reprioritize(_fn)
        stats["profile"] = dict(new_profile)
        return stats

    def process_tile(
        self,
        tile_id: str,
        scores: dict[str, float],
        image_ref: str | Path,
        tile_metadata: dict[str, Any] | None = None,
        image_id: str | None = None,
    ) -> dict[str, Any]:
        if set(scores) != set(CLASSES):
            raise ValueError(f"Expected exactly these score names: {CLASSES}")

        scores = {name: float(scores[name]) for name in CLASSES}
        for name, value in scores.items():
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise ValueError(f"Invalid {name} score: {value}")

        image_path = Path(image_ref).expanduser().resolve()
        if not image_path.is_file():
            raise FileNotFoundError(f"Tile image not found: {image_path}")

        # Predicted class is now the honest argmax over all 7 classes,
        # not over land classes only. A cloud-dominant tile is Cloud,
        # not the best land class it happens to resemble.
        predicted_class = max(CLASSES, key=lambda name: scores[name])
        confidence = scores[predicted_class]
        priority, priority_name, relevance, db_status = decide(scores, self.profile)

        size_bytes = image_path.stat().st_size
        item = {
            "tile_id": str(tile_id),
            "image_id": image_id,
            "image_ref": str(image_path),
            "size_bytes": size_bytes,
            "predicted_class": predicted_class,
            "confidence": confidence,
            "priority": priority,
            "priority_name": priority_name,
            "relevance": relevance,
            "scores": scores,
            "tile_metadata": tile_metadata or {},
            "estimated_wire_bytes": size_bytes + 512,
        }

        inserted = self.queue_manager.add_tile(item)
        if not inserted:
            self.duplicate_count += 1
            return {
                "status": "Duplicate",
                "tile_id": str(tile_id),
                "predicted_class": predicted_class,
                "confidence": confidence,
                "relevance": relevance,
            }

        if db_status == "DROPPED":
            # Held onboard, NOT deleted. Tile file and scores stay in DB.
            self.queue_manager.mark_dropped(
                str(tile_id), f"Held onboard: relevance {relevance:.3f} below band"
            )
            self.dropped_count += 1
            self.held_count += 1
            return {
                "status": "Held",
                "tile_id": str(tile_id),
                "predicted_class": predicted_class,
                "confidence": confidence,
                "relevance": relevance,
                "priority": priority,
                "priority_name": priority_name,
            }

        self.queued_count += 1
        return {
            "status": "Queued",
            "tile_id": str(tile_id),
            "predicted_class": predicted_class,
            "confidence": confidence,
            "relevance": relevance,
            "priority": priority,
            "priority_name": priority_name,
        }

    def process_inference_result(
        self,
        inference_result: dict[str, Any],
        image_id: str | None = None,
        capture_info: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        image_path = Path(inference_result["image_path"])
        image_id = image_id or image_path.stem
        results = []

        for tile in inference_result["tiles"]:
            tile_index = int(tile["tile_id"])
            image_ref = tile.get("image_ref")
            if not image_ref:
                raise ValueError(
                    f"Tile {tile_index} has no image_ref. "
                    "Call classify_image(..., tile_output_dir=...)."
                )

            old_tile_id = f"{image_id}_{tile_index:06d}"
            # Neutral ID: content-derived, no ground-truth label in it.
            # Deterministic for the same image+tile, so a fresh DB after a
            # cycle reset reuses the same neutral IDs without collision.
            neutral = hashlib.sha256(image_id.encode()).hexdigest()[:10]
            unique_tile_id = f"IMG{neutral}_{tile_index:06d}"
            meta: dict[str, Any] = {
                "x": tile["x"],
                "y": tile["y"],
                "valid_width": tile["valid_width"],
                "valid_height": tile["valid_height"],
                "original_tile_id": old_tile_id,
                "original_image_id": image_id,
            }
            if capture_info:
                meta.update(capture_info)
            result = self.process_tile(
                tile_id=unique_tile_id,
                image_id=image_id,
                scores=tile["scores"],
                image_ref=image_ref,
                tile_metadata=meta,
            )
            results.append(result)

        return results

    def get_queue_statistics(self) -> dict[str, Any]:
        return self.queue_manager.get_queue_statistics()
