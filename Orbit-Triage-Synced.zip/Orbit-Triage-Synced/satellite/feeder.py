#!/usr/bin/env python3
"""feeder.py -- drip dataset images into storage/incoming/ for a live demo.

Why: a pass carries ~250 tiles, but the shipped queue has only 90 tiles
and they are all already ACKED. Without a feeder, the queue empties in
the first pass and no choice ever has to be made. With a feeder, the
queue grows visibly between passes, timestamps spread out, and a later
mission re-ranks a real backlog.

Usage (from the satellite/ folder, in a separate terminal):
    python3 feeder.py --source-dir /path/to/dataset --interval 1.0

    --source-dir   Folder with original JPG/PNG images. This folder is
                   NEVER modified; feeder only copies FROM it.
    --incoming-dir Default: storage/incoming/
    --interval     Seconds between copies. Default 1.0.
    --limit        Stop after N copies. Default: all files, once.
    --shuffle      Copy in random order instead of sorted order.
    --loop         After the last file, start again from the first.
                   Use with care: the ingestor skips same-content files
                   unless markers/queue were reset (new cycle), so looping
                   without a reset will simply be skipped.

Stop with Ctrl+C. The satellite ingestor moves each copied file from
incoming/ to archive/ after processing, so incoming/ stays small.
"""
from __future__ import annotations

import argparse
import random
import shutil
import sys
import time
from pathlib import Path

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp"}


def main() -> int:
    ap = argparse.ArgumentParser(description="Drip dataset images into incoming/")
    ap.add_argument("--source-dir", required=True, help="Pristine dataset folder (never modified)")
    ap.add_argument("--incoming-dir", default="storage/incoming")
    ap.add_argument("--interval", type=float, default=1.0)
    ap.add_argument("--limit", type=int, default=0, help="0 = all files, once")
    ap.add_argument("--shuffle", action="store_true")
    ap.add_argument("--loop", action="store_true")
    args = ap.parse_args()

    source = Path(args.source_dir).expanduser().resolve()
    incoming = Path(args.incoming_dir).expanduser().resolve()
    if not source.is_dir():
        print(f"Source folder not found: {source}", file=sys.stderr)
        return 2
    incoming.mkdir(parents=True, exist_ok=True)
    files = sorted(
        [p for p in source.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS]
    )
    if not files:
        print(f"No images in {source}", file=sys.stderr)
        return 2
    if args.shuffle:
        random.shuffle(files)
    print(f"Feeder: {len(files)} images from {source} -> {incoming}, every {args.interval}s")
    sent = 0
    try:
        while True:
            for src in files:
                if args.limit and sent >= args.limit:
                    print(f"Feeder done: {sent} copied.")
                    return 0
                dst = incoming / src.name
                if dst.exists():
                    # Ingestor has not picked it up yet; wait a cycle.
                    print(f"Skip (still in incoming): {src.name}")
                else:
                    shutil.copy2(src, dst)
                    sent += 1
                    print(f"[{sent}] {src.name} -> incoming/")
                time.sleep(max(0.0, args.interval))
            if not args.loop:
                print(f"Feeder done: {sent} copied.")
                return 0
            print("Feeder looping from the start (new cycle must have reset markers).")
    except KeyboardInterrupt:
        print(f"\nFeeder stopped: {sent} copied.")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
