"""Persistent onboard tile queue for the satellite simulation.

This module is independent of ONNX inference, scheduling policy and networking.
It stores queue metadata in SQLite; image bytes remain in files referenced by
image_ref.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VALID_STATUSES = ("PENDING", "SENDING", "RETRY", "ACKED", "DROPPED")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class QueueManager:
    """SQLite-backed persistent queue for satellite tile records."""

    def __init__(self, db_path: str | Path = "storage/queue.db") -> None:
        self.db_path = Path(db_path).expanduser().resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialise_database()
        # Unacknowledged transfers must be retried after a process restart.
        self.reset_interrupted_transfers()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 30000")
        return conn

    def _initialise_database(self) -> None:
        with self._connect() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tiles (
                    tile_id TEXT PRIMARY KEY,
                    image_id TEXT,
                    image_ref TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL CHECK (size_bytes >= 0),
                    predicted_class TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK (confidence >= 0.0 AND confidence <= 1.0),
                    priority INTEGER NOT NULL,
                    priority_name TEXT NOT NULL,
                    relevance REAL NOT NULL DEFAULT 0,
                    scores_json TEXT NOT NULL,
                    tile_metadata_json TEXT NOT NULL,
                    estimated_wire_bytes INTEGER NOT NULL CHECK (estimated_wire_bytes >= 0),
                    status TEXT NOT NULL DEFAULT 'PENDING'
                        CHECK (status IN ('PENDING','SENDING','RETRY','ACKED','DROPPED')),
                    attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
                    pass_id TEXT,
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    acked_at TEXT
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tiles_queue "
                "ON tiles(status, priority, created_at)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tiles_pass "
                "ON tiles(pass_id, status)"
            )
            # SYNCED: old DBs (shipped queue.db) have no relevance column.
            cols = [r[1] for r in conn.execute("PRAGMA table_info(tiles)")]
            if "relevance" not in cols:
                conn.execute("ALTER TABLE tiles ADD COLUMN relevance REAL NOT NULL DEFAULT 0")

    @staticmethod
    def _decode_row(row: sqlite3.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        item = dict(row)
        item["scores"] = json.loads(item.pop("scores_json"))
        item["tile_metadata"] = json.loads(item.pop("tile_metadata_json"))
        return item

    def add_tile(self, tile_data: dict[str, Any]) -> bool:
        """Insert a scheduler item as PENDING. Return False for duplicate IDs."""
        required = (
            "tile_id", "image_ref", "predicted_class", "confidence",
            "priority", "priority_name", "scores",
        )
        missing = [key for key in required if key not in tile_data]
        if missing:
            raise ValueError(f"Tile record missing required fields: {missing}")

        tile_id = str(tile_data["tile_id"]).strip()
        image_ref = str(tile_data["image_ref"]).strip()
        predicted_class = str(tile_data["predicted_class"]).strip()
        priority_name = str(tile_data["priority_name"]).strip()
        if not all((tile_id, image_ref, predicted_class, priority_name)):
            raise ValueError("tile_id, image_ref, predicted_class and priority_name cannot be empty")

        confidence = float(tile_data["confidence"])
        if not 0.0 <= confidence <= 1.0:
            raise ValueError(f"confidence must be in [0, 1], got {confidence}")

        scores = tile_data["scores"]
        if not isinstance(scores, dict) or not scores:
            raise ValueError("scores must be a non-empty dictionary")
        scores = {str(k): float(v) for k, v in scores.items()}
        if any(not 0.0 <= value <= 1.0 for value in scores.values()):
            raise ValueError("all class scores must be in [0, 1]")

        image_path = Path(image_ref).expanduser()
        default_size = image_path.stat().st_size if image_path.is_file() else 0
        size_bytes = int(tile_data.get("size_bytes", default_size))
        estimated_wire_bytes = int(tile_data.get("estimated_wire_bytes", size_bytes))
        priority = int(tile_data["priority"])
        if size_bytes < 0 or estimated_wire_bytes < 0:
            raise ValueError("image sizes cannot be negative")
        if priority < 1:
            raise ValueError("priority must be >= 1")

        image_id = tile_data.get("image_id")
        if image_id is None:
            image_id = tile_id.rsplit("_", 1)[0] if "_" in tile_id else tile_id

        now = _utc_now()
        with self._connect() as conn:
            cursor = conn.execute("""
                INSERT OR IGNORE INTO tiles (
                    tile_id, image_id, image_ref, size_bytes, predicted_class,
                    confidence, priority, priority_name, relevance, scores_json,
                    tile_metadata_json, estimated_wire_bytes, status, attempts,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', 0, ?, ?)
            """, (
                tile_id, str(image_id), image_ref, size_bytes, predicted_class,
                confidence, priority, priority_name,
                float(tile_data.get("relevance", confidence)),
                json.dumps(scores, separators=(",", ":")),
                json.dumps(tile_data.get("tile_metadata") or {}, separators=(",", ":")),
                estimated_wire_bytes, now, now,
            ))
            return cursor.rowcount == 1

    def get_next_pending_tile(self) -> dict[str, Any] | None:
        """Peek at next PENDING/RETRY tile without changing its status."""
        with self._connect() as conn:
            row = conn.execute("""
                SELECT * FROM tiles
                WHERE status IN ('PENDING', 'RETRY')
                ORDER BY priority ASC, relevance DESC, created_at ASC, tile_id ASC
                LIMIT 1
            """).fetchone()
            return self._decode_row(row)

    def claim_next_pending_tile(self, pass_id: str | None = None) -> dict[str, Any] | None:
        """Atomically claim next tile and mark it SENDING."""
        now = _utc_now()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("""
                SELECT * FROM tiles
                WHERE status IN ('PENDING', 'RETRY')
                ORDER BY priority ASC, relevance DESC, created_at ASC, tile_id ASC
                LIMIT 1
            """).fetchone()
            if row is None:
                return None
            tile_id = row["tile_id"]
            conn.execute("""
                UPDATE tiles
                SET status='SENDING', attempts=attempts+1, pass_id=?,
                    last_error=NULL, updated_at=?
                WHERE tile_id=? AND status IN ('PENDING','RETRY')
            """, (pass_id, now, tile_id))
            claimed = conn.execute(
                "SELECT * FROM tiles WHERE tile_id=?", (tile_id,)
            ).fetchone()
            return self._decode_row(claimed)

    def mark_sending(self, tile_id: str, pass_id: str | None = None) -> bool:
        """Mark a specific PENDING/RETRY tile SENDING and increment attempts."""
        now = _utc_now()
        with self._connect() as conn:
            cur = conn.execute("""
                UPDATE tiles
                SET status='SENDING', attempts=attempts+1, pass_id=?,
                    last_error=NULL, updated_at=?
                WHERE tile_id=? AND status IN ('PENDING','RETRY')
            """, (pass_id, now, str(tile_id)))
            return cur.rowcount == 1

    def mark_acked(self, tile_id: str) -> bool:
        """Mark delivered only after the ground station acknowledges the tile."""
        now = _utc_now()
        with self._connect() as conn:
            cur = conn.execute("""
                UPDATE tiles
                SET status='ACKED', acked_at=?, updated_at=?, last_error=NULL
                WHERE tile_id=? AND status IN ('SENDING','RETRY','PENDING')
            """, (now, now, str(tile_id)))
            return cur.rowcount == 1

    def mark_retry(self, tile_id: str, error: str = "") -> bool:
        """Return an unacknowledged tile to RETRY for a later pass."""
        now = _utc_now()
        with self._connect() as conn:
            cur = conn.execute("""
                UPDATE tiles SET status='RETRY', last_error=?, updated_at=?
                WHERE tile_id=? AND status IN ('SENDING','PENDING','RETRY')
            """, (str(error)[:2000], now, str(tile_id)))
            return cur.rowcount == 1

    def mark_dropped(self, tile_id: str, reason: str = "") -> bool:
        """Record an intentional scheduler drop."""
        now = _utc_now()
        with self._connect() as conn:
            cur = conn.execute("""
                UPDATE tiles SET status='DROPPED', last_error=?, updated_at=?
                WHERE tile_id=? AND status IN ('PENDING','RETRY')
            """, (str(reason)[:2000], now, str(tile_id)))
            return cur.rowcount == 1

    def reprioritize(self, fn) -> dict[str, Any]:
        """Re-rank PENDING/RETRY/DROPPED rows from their stored scores.

        fn(scores, tile_metadata) -> (priority, priority_name, relevance, status)
        where status is 'PENDING' (sendable) or 'DROPPED' (held onboard, kept
        on disk, NOT deleted). Runs in one BEGIN IMMEDIATE transaction.
        Never touches SENDING or ACKED rows.
        """
        now = _utc_now()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            rows = conn.execute("""
                SELECT tile_id, scores_json, tile_metadata_json, status, priority
                FROM tiles WHERE status IN ('PENDING', 'RETRY', 'DROPPED')
            """).fetchall()
            changed = 0
            pending = 0
            held = 0
            for row in rows:
                scores = json.loads(row["scores_json"])
                meta = json.loads(row["tile_metadata_json"] or "{}")
                priority, priority_name, relevance, status = fn(scores, meta)
                if status not in ("PENDING", "DROPPED"):
                    raise ValueError(f"reprioritize: bad status {status!r}")
                cur = conn.execute("""
                    UPDATE tiles SET priority=?, priority_name=?, relevance=?,
                        status=?, updated_at=?, last_error=NULL
                    WHERE tile_id=?
                """, (int(priority), str(priority_name), float(relevance), status, now, row["tile_id"]))
                if cur.rowcount and (row["status"] != status or int(row["priority"]) != int(priority)):
                    changed += 1
                if status == "PENDING":
                    pending += 1
                else:
                    held += 1
            return {"total": len(rows), "changed": changed, "pending": pending, "held": held}

    def reset_queue(self) -> int:
        """Delete ALL queue rows. Used only for a new cycle (see recycle).

        Callers must also delete processed markers, tiles/ and metadata/
        (but keep archive/ as the source to re-ingest from) before new
        images are ingested, otherwise duplicate tile_ids will be ignored.
        """
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM tiles")
            return cur.rowcount

    def reset_interrupted_transfers(self) -> int:
        """Recover SENDING records as RETRY when the satellite process restarts."""
        now = _utc_now()
        with self._connect() as conn:
            cur = conn.execute("""
                UPDATE tiles
                SET status='RETRY', last_error='Recovered after satellite restart',
                    updated_at=?
                WHERE status='SENDING'
            """, (now,))
            return cur.rowcount

    def get_queue_statistics(self) -> dict[str, Any]:
        """Return record counts and image bytes grouped by status."""
        with self._connect() as conn:
            rows = conn.execute("""
                SELECT status, COUNT(*) AS count,
                       COALESCE(SUM(size_bytes), 0) AS bytes
                FROM tiles GROUP BY status
            """).fetchall()
        result = {s: {"count": 0, "bytes": 0} for s in VALID_STATUSES}
        for row in rows:
            result[row["status"]] = {
                "count": int(row["count"]),
                "bytes": int(row["bytes"]),
            }
        result["total_count"] = sum(v["count"] for v in result.values())
        result["waiting_count"] = result["PENDING"]["count"] + result["RETRY"]["count"]
        result["held_count"] = result["DROPPED"]["count"]
        result["waiting_bytes"] = result["PENDING"]["bytes"] + result["RETRY"]["bytes"]
        return result

    def list_tiles(self, status: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        """List queue records, optionally filtered by status."""
        if limit <= 0:
            raise ValueError("limit must be positive")
        if status is not None:
            status = status.upper()
            if status not in VALID_STATUSES:
                raise ValueError(f"status must be one of {VALID_STATUSES}")
        with self._connect() as conn:
            if status is None:
                rows = conn.execute("""
                    SELECT * FROM tiles
                    ORDER BY priority ASC, relevance DESC, created_at ASC
                    LIMIT ?
                """, (int(limit),)).fetchall()
            else:
                rows = conn.execute("""
                    SELECT * FROM tiles WHERE status=?
                    ORDER BY priority ASC, relevance DESC, created_at ASC
                    LIMIT ?
                """, (status, int(limit))).fetchall()
        return [self._decode_row(row) for row in rows]

    def get_tile(self, tile_id: str) -> dict[str, Any] | None:
        """Fetch one tile record by ID."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM tiles WHERE tile_id=?", (str(tile_id),)
            ).fetchone()
        return self._decode_row(row)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Inspect the satellite SQLite queue")
    parser.add_argument("--db", default="storage/queue.db")
    parser.add_argument("--list", choices=VALID_STATUSES)
    parser.add_argument("--limit", type=int, default=20)
    args = parser.parse_args()

    manager = QueueManager(args.db)
    print(json.dumps(manager.get_queue_statistics(), indent=2))
    if args.list:
        print(json.dumps(manager.list_tiles(args.list, args.limit), indent=2))
