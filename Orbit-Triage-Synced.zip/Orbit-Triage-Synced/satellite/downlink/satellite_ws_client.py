"""SYNCED adapter from the SQLite tile queue to the UI team's GS protocol.

Sync rules (user decisions, 2026-10-31):
* 7 classes kept. INTEREST_CLASSES = all except CloudShadow (adverse only).
* A ground profile command does NOT apply immediately. It is stored as
  _pending_profile, acknowledged with command_received apply="next pass
  start", and applied at the NEXT pass start via scheduler.apply_profile,
  which re-ranks PENDING/RETRY/DROPPED rows. If no new profile arrives,
  the previous profile simply continues -- the pass never waits for a popup.
* hello carries run_id (uuid, once per satellite process, changed on a
  new cycle). Ground clears its inbox only when run_id changes, so a
  Wi-Fi reconnect with the same run_id does NOT wipe the screen.
* frame_meta / delivered carry profile-based relevance (not top-class
  confidence), priority_name, numeric capture_t (mission-elapsed seconds,
  shared monotonic epoch with pass_controller) and latency_s (send time
  minus capture time, computed on the satellite, so the two laptops'
  wall clocks do not matter).
* Dead code removed: _command_loop and _ack_reader are gone. All commands
  are handled in _run_connected.read_messages only.
"""

from __future__ import annotations

import asyncio
import base64
import json
import random
import re
import time
import uuid
from pathlib import Path
from typing import Any

import aiohttp

SAFE_ID = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")
CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
INTEREST_CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "Ship"]


class SatelliteWebSocketClient:
    """Sends queued tile files as frame_meta/chunk/delivered events."""

    def __init__(
        self,
        queue,
        ground_url: str,
        pass_controller,
        packet_bytes: int = 1024,
        ack_timeout_s: float = 15.0,
        reconnect_delay_s: float = 3.0,
        seed: int = 7,
        scheduler=None,
        mission_start_monotonic: float | None = None,
        recycle_callback=None,
        timing: dict | None = None,
    ):
        if packet_bytes <= 0:
            raise ValueError("packet_bytes must be positive")
        self.queue = queue
        self.ground_url = ground_url
        self.pass_controller = pass_controller
        self.packet_bytes = int(packet_bytes)
        self.ack_timeout_s = float(ack_timeout_s)
        self.reconnect_delay_s = float(reconnect_delay_s)
        self.rng = random.Random(seed)
        self.ws = None
        self.running = True
        self._manual_event = asyncio.Event()
        self._tx_count = 0
        self._dropped_count = 0
        # Shared monotonic epoch with pass_controller, so capture_t and
        # telemetry t use the same mission clock.
        self._started = float(mission_start_monotonic) if mission_start_monotonic is not None else time.monotonic()
        self.run_id = str(uuid.uuid4())
        self.scheduler = scheduler
        self.recycle_callback = recycle_callback
        self.timing = timing
        self._last_telemetry = 0.0
        self._last_link_sample = 0.0
        if scheduler is not None:
            self._profile = dict(scheduler.profile)
        else:
            self._profile = {
                "interest": ["Forest", "Cropland", "Urban", "Water"],
                "picky": 0.70,
                "band": 0.20,
            }
        self._pending_profile: dict | None = None
        self._acks: dict[str, dict] = {}
        self._ack_event = asyncio.Event()

    def _latency_s(self, item: dict) -> float | None:
        meta = item.get("tile_metadata") or {}
        cap = meta.get("capture_t_elapsed")
        if cap is None:
            return None
        try:
            return max(0.0, round((time.monotonic() - self._started) - float(cap), 3))
        except Exception:
            return None

    def _capture_t(self, item: dict):
        meta = item.get("tile_metadata") or {}
        cap = meta.get("capture_t_elapsed")
        if cap is not None:
            return round(float(cap), 3)
        return 0

    async def _send_hello(self):
        await self._send(
            {
                "type": "hello",
                "role": "satellite",
                "run_id": self.run_id,
                "classes": CLASSES,
                "interest_classes": INTEREST_CLASSES,
                "manifest_frames": self.queue.get_queue_statistics().get("total_count", 0),
                "model_inference": True,
                "model": "model_qat_int8_packed.onnx",
                "queue_backend": "sqlite",
                "profile": dict(self._profile),
            }
        )

    async def _apply_pending_at_pass_start(self):
        """Apply a pending profile (and recycle if the queue is empty).

        Returns the profile_applied payload fields, or None.
        Called only from the pass-start block, never while a pass is open.
        """
        if self._pending_profile is None:
            return None
        pending = self._pending_profile
        self._pending_profile = None
        recycled = None
        # Recycle ONLY when the queue is truly empty (no PENDING/RETRY
        # and no HELD/DROPPED rows left). If held tiles are still waiting,
        # they are simply re-ranked below -- no re-ingest, no re-send of
        # already-ACKED tiles. Recycling with held tiles present would
        # discard them and re-send tiles judges already saw.
        # A manual "new_cycle" command always recycles, even with held
        # tiles present, because the operator asked for a fresh cycle.
        try:
            stats_q = self.queue.get_queue_statistics()
            waiting = stats_q.get("waiting_count", 0)
            held = stats_q.get("held_count", stats_q.get("DROPPED", {}).get("count", 0))
        except Exception:
            waiting = 1
            held = 1
        if waiting == 0 and held == 0 and self.recycle_callback is not None:
            try:
                recycled = self.recycle_callback()
            except Exception as exc:
                recycled = {"error": f"{type(exc).__name__}: {exc}"}
            # If recycling actually happened, the ground inbox must reset,
            # otherwise re-delivered tiles (same neutral IDs) are deduped
            # by the UI and never appear as new cards. Send a fresh hello
            # with a new run_id BEFORE pass_start, so ground clears.
            if isinstance(recycled, dict) and "error" not in recycled:
                self.run_id = str(uuid.uuid4())
                try:
                    await self._send_hello()
                except Exception:
                    pass
        if self.scheduler is not None:
            stats = self.scheduler.apply_profile(pending)
            self._profile = dict(self.scheduler.profile)
        else:
            self._profile = dict(pending)
            stats = {"total": 0, "changed": 0, "pending": 0, "held": 0}
        out = {"profile": dict(self._profile), "re-rank": stats}
        if recycled is not None:
            out["recycled"] = recycled
        return out

    async def _send(self, payload: dict):
        if self.ws is None or self.ws.closed:
            raise ConnectionError("Ground station is disconnected")
        await self.ws.send_json(payload)

    async def _send_event(self, kind: str, **fields):
        await self._send(
            {"type": kind, "t": round(time.monotonic() - self._started, 3), **fields}
        )

    def _queue_counts(self) -> tuple[int, int, int, int]:
        stats = self.queue.get_queue_statistics()
        pending = stats.get("PENDING", {}).get("count", 0)
        retry = stats.get("RETRY", {}).get("count", 0)
        sending = stats.get("SENDING", {}).get("count", 0)
        dropped = stats.get("DROPPED", {}).get("count", 0)
        return pending + retry + sending, pending + retry, sending, dropped

    async def _send_telemetry(self, state: dict):
        now = time.monotonic()
        if now - self._last_telemetry < 2.0:
            return
        self._last_telemetry = now
        stats = self.queue.get_queue_statistics()
        waiting, pending_retry, sending, dropped = self._queue_counts()
        used_bytes = (
            stats.get("PENDING", {}).get("bytes", 0)
            + stats.get("RETRY", {}).get("bytes", 0)
            + stats.get("SENDING", {}).get("bytes", 0)
        )
        cap_bytes = 600_000_000
        link = {
            "kbps": float(state.get("kbps", 0.0)),
            "loss": float(state.get("loss", 1.0)),
            "elevation": max(0.0, min(1.0, float(state.get("progress", 0.0)))),
        }
        await self._send(
            {
                "type": "telemetry",
                "t": round(now - self._started, 2),
                "pass": {
                    "in_pass": bool(state["in_pass"]),
                    "number": state.get("pass_number") if state["in_pass"] else None,
                    "x": float(state.get("progress", 0.0)),
                    "next_in_s": float(state.get("seconds_to_next_pass", 0.0)),
                },
                "link": link,
                "queue": {"frames": waiting, "full": waiting, "preview": 0},
                "storage": {
                    "used_bytes": used_bytes,
                    "used_mb": used_bytes / 1_000_000,
                    "cap_mb": cap_bytes / 1_000_000,
                    "percent": min(100.0, 100.0 * used_bytes / cap_bytes),
                },
                "stats": {
                    "captured": stats.get("total_count", 0),
                    # DROPPED in this pipeline means HELD onboard, not deleted.
                    # Ground UI renames it to "held onboard".
                    "dropped": dropped,
                    "held": dropped,
                    "evicted": 0,
                    "released": 0,
                    "delivered_full": stats.get("ACKED", {}).get("count", 0),
                    "delivered_preview": 0,
                    "pkt_sent": self._tx_count,
                    "pkt_lost": self._dropped_count,
                },
                "inference": {
                    "count": stats.get("total_count", 0),
                    "mean_ms": (self.timing or {}).get("mean_ms"),
                    "last_ms": (self.timing or {}).get("last_ms"),
                },
                "power": {
                    "battery_wh": 0.0,
                    "capacity_wh": 0.0,
                    "infer_energy_wh": 0.0,
                    "radio_energy_wh": 0.0,
                    "solar_energy_wh": 0.0,
                    "source": "No physical power telemetry connected; values unavailable.",
                },
                "profile": self._profile,
            }
        )

    async def _send_tile(self, item: dict, pass_state: dict) -> bool:
        tile_id = str(item["tile_id"])
        if not SAFE_ID.fullmatch(tile_id):
            self.queue.mark_retry(
                tile_id, "tile_id contains characters rejected by ground receiver"
            )
            return False

        image_path = Path(item["image_ref"]).expanduser()
        if not image_path.is_file():
            self.queue.mark_retry(tile_id, f"Missing tile file: {image_path}")
            await self._send_event(
                "agent_error",
                frame_id=tile_id,
                message=f"Tile file not found: {image_path}",
            )
            return False

        payload = image_path.read_bytes()
        total_chunks = (len(payload) + self.packet_bytes - 1) // self.packet_bytes
        suffix = image_path.suffix.lower()
        content_type = (
            "image/png"
            if suffix == ".png"
            else (
                "image/jpeg"
                if suffix in (".jpg", ".jpeg")
                else "application/octet-stream"
            )
        )

        await self._send_event(
            "frame_meta",
            frame_id=tile_id,
            mode="full",
            bytes=len(payload),
            chunks=total_chunks,
            # Profile-based relevance, NOT top-class confidence.
            relevance=float(item.get("relevance", item["confidence"])),
            confidence=float(item["confidence"]),
            probs=item["scores"],
            predicted_class=item["predicted_class"],
            priority=int(item["priority"]),
            priority_name=item["priority_name"],
            capture_t=self._capture_t(item),
            capture_utc=(item.get("tile_metadata") or {}).get("capture_utc"),
            latency_s=self._latency_s(item),
            pass_number=pass_state["pass_number"],
            content_type=content_type,
            image_id=item.get("image_id"),
            tile_metadata=item.get("tile_metadata", {}),
        )

        for index in range(total_chunks):
            current = self.pass_controller.state()
            if not current["in_pass"]:
                self.queue.mark_retry(
                    tile_id, "Pass ended before tile transfer completed"
                )
                return False

            start = index * self.packet_bytes
            chunk = payload[start : start + self.packet_bytes]
            packet_time = (len(chunk) * 8.0) / max(1.0, current["kbps"] * 1000.0)
            await asyncio.sleep(packet_time)

            # Simulated packet loss: a lost chunk is retried in this pass.
            retries = 0
            while self.rng.random() < current["loss"]:
                self._dropped_count += 1
                retries += 1
                if retries > 8 or not self.pass_controller.state()["in_pass"]:
                    self.queue.mark_retry(
                        tile_id, f"Chunk {index} retry limit/pass end"
                    )
                    return False
                await asyncio.sleep(packet_time)

            await self._send(
                {
                    "type": "chunk",
                    "frame_id": tile_id,
                    "mode": "full",
                    "offset": start,
                    "index": index,
                    "total": total_chunks,
                    "data": base64.b64encode(chunk).decode("ascii"),
                }
            )
            self._tx_count += 1

        self._ack_event.clear()
        self._acks.pop(tile_id, None)
        await self._send_event(
            "delivered",
            frame_id=tile_id,
            mode="full",
            bytes=len(payload),
            chunks=total_chunks,
            relevance=float(item.get("relevance", item["confidence"])),
            confidence=float(item["confidence"]),
            probs=item["scores"],
            predicted_class=item["predicted_class"],
            priority=int(item["priority"]),
            priority_name=item["priority_name"],
            capture_t=self._capture_t(item),
            capture_utc=(item.get("tile_metadata") or {}).get("capture_utc"),
            latency_s=self._latency_s(item),
            pass_number=pass_state["pass_number"],
            lost_packets=self._dropped_count,
            content_type=content_type,
        )

        # Receiver ACK extension is required; without it we cannot safely mark
        # a record ACKED. For now the sender waits for the receiver's explicit ACK.
        try:
            await asyncio.wait_for(self._ack_event.wait(), timeout=self.ack_timeout_s)
        except asyncio.TimeoutError:
            self.queue.mark_retry(tile_id, "Ground station ACK timeout")
            return False

        ack = self._acks.pop(tile_id, {})
        self._ack_event.clear()
        if ack.get("ok") is True:
            self.queue.mark_acked(tile_id)
            return True
        self.queue.mark_retry(
            tile_id, str(ack.get("reason", "Ground station rejected tile"))
        )
        return False

    async def _run_connected(self):
        self._acks.clear()
        self._ack_event.clear()
        await self._send_hello()

        # The receiver task handles commands and ACKs from the same websocket.
        async def read_messages():
            async for msg in self.ws:
                if msg.type != aiohttp.WSMsgType.TEXT:
                    if msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                        break
                    continue
                try:
                    data = json.loads(msg.data)
                except json.JSONDecodeError:
                    continue
                if data.get("type") == "ack":
                    self._acks[str(data.get("frame_id", ""))] = data
                    self._ack_event.set()
                elif data.get("type") == "command":
                    command = data.get("command")
                    payload = data.get("payload") or {}
                    if command == "open_pass":
                        # Kept for rehearsal only. The synced UI has no
                        # Open-pass button: passes are automatic on range.
                        opened, number = self.pass_controller.request_open()
                        await self._send_event(
                            "manual_pass_requested" if opened else "pass_already_open",
                            pass_number=number,
                            apply="immediately" if opened else "already open",
                        )
                    elif command == "profile":
                        # SYNCED: store only. Do NOT apply now, do NOT
                        # rewrite the queue now. It applies at the next
                        # pass start (see _apply_pending_at_pass_start).
                        # If no new profile arrives, the old one continues
                        # and the pass never waits for a popup.
                        self._pending_profile = {
                            "interest": [
                                c for c in payload.get("interest", []) if c in INTEREST_CLASSES
                            ],
                            "picky": payload.get("picky", self._profile.get("picky", 0.70)),
                            "band": payload.get("band", self._profile.get("band", 0.20)),
                        }
                        await self._send_event(
                            "command_received",
                            command="profile",
                            apply="next pass start",
                            profile=self._pending_profile,
                        )
                    elif command == "new_cycle":
                        # Operator wants the same images again under a new
                        # mission. Recycle now (archive -> incoming,
                        # queue/markers cleared), then tell ground with a
                        # fresh run_id so it clears its inbox.
                        recycled = None
                        if self.recycle_callback is not None:
                            try:
                                recycled = self.recycle_callback()
                            except Exception as exc:
                                recycled = {"error": f"{type(exc).__name__}: {exc}"}
                        self.run_id = str(uuid.uuid4())
                        await self._send_hello()
                        await self._send_event(
                            "cycle_restarted", run_id=self.run_id, recycled=recycled or {}
                        )
                    elif command == "request_full":
                        await self._send_event(
                            "request_missed",
                            frame_id=str(payload.get("frame_id", "")),
                            reason="Only full-resolution tiles are stored; no preview/full pair exists.",
                        )
                    elif command == "fault":
                        await self._send_event(
                            "fault_state",
                            kind=payload.get("kind"),
                            seconds=payload.get("seconds", 0),
                            note="Fault injection is not implemented in this sender.",
                        )

        reader_task = asyncio.create_task(read_messages())
        current_pass = None
        try:
            while self.running and not self.ws.closed:
                state = self.pass_controller.state()
                await self._send_telemetry(state)

                if not state["in_pass"]:
                    if current_pass is not None:
                        await self._send_event(
                            "pass_end",
                            pass_number=current_pass,
                            waiting_frames=self.queue.get_queue_statistics().get(
                                "waiting_count", 0
                            ),
                            cut_off=False,
                        )
                        current_pass = None
                    await asyncio.sleep(
                        min(0.5, max(0.1, state["seconds_to_next_pass"]))
                    )
                    continue

                pass_number = int(state["pass_number"])
                if current_pass != pass_number:
                    current_pass = pass_number
                    # SYNCED: apply any pending mission FIRST, then open.
                    applied = await self._apply_pending_at_pass_start()
                    if applied is not None:
                        await self._send_event("profile_applied", pass_number=pass_number, **applied)
                    await self._send_event(
                        "pass_start",
                        pass_number=pass_number,
                        pass_length_s=self.pass_controller.pass_duration_s,
                    )
                    await self._send_event(
                        "link_sample",
                        pass_number=pass_number,
                        kbps=state["kbps"],
                        loss=state["loss"],
                        elevation=state["progress"],
                    )

                item = self.queue.claim_next_pending_tile(
                    pass_id=f"PASS_{pass_number:04d}"
                )
                if item is None:
                    await asyncio.sleep(0.25)
                    continue

                ok = False
                try:
                    ok = await self._send_tile(item, state)
                except Exception as exc:
                    self.queue.mark_retry(
                        item["tile_id"],
                        f"Transfer exception: {type(exc).__name__}: {exc}",
                    )
                    print(f"[DOWNLINK] {item['tile_id']} failed: {exc}")

                if not ok and not self.pass_controller.state()["in_pass"]:
                    continue

                if not self.pass_controller.state()["in_pass"]:
                    await self._send_event(
                        "pass_end",
                        pass_number=pass_number,
                        waiting_frames=self.queue.get_queue_statistics().get(
                            "waiting_count", 0
                        ),
                        cut_off=True,
                    )
                    current_pass = None

        finally:
            reader_task.cancel()
            await asyncio.gather(reader_task, return_exceptions=True)

    async def run_forever(self):
        timeout = aiohttp.ClientTimeout(total=None, sock_connect=10, sock_read=None)
        while self.running:
            try:
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    print(f"[DOWNLINK] Connecting to {self.ground_url}")
                    async with session.ws_connect(
                        self.ground_url, heartbeat=25, max_msg_size=8 * 1024 * 1024
                    ) as ws:
                        self.ws = ws
                        print("[DOWNLINK] Connected to ground station")
                        await self._run_connected()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                print(f"[DOWNLINK] Connection error: {type(exc).__name__}: {exc}")
                await asyncio.sleep(self.reconnect_delay_s)
            finally:
                self.ws = None

    def stop(self):
        self.running = False
