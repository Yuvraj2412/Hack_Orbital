"""Pass clock for the ONNX + SQLite satellite pipeline.

Supports both scheduled passes and the UI's manual `open_pass` command.
The LAN connection can remain open outside a pass; image data is only sent in a pass.
"""

from __future__ import annotations

import math
import time


class PassController:
    def __init__(
        self,
        first_pass_s: float = 10.0,
        pass_period_s: float = 120.0,
        pass_duration_s: float = 60.0,
        peak_kbps: float = 256.0,
    ):
        if first_pass_s < 0:
            raise ValueError("first_pass_s cannot be negative")
        if pass_period_s <= 0 or pass_duration_s <= 0:
            raise ValueError("pass period and duration must be positive")
        if pass_duration_s > pass_period_s:
            raise ValueError("pass duration cannot exceed pass period")
        if peak_kbps <= 0:
            raise ValueError("peak_kbps must be positive")

        self.first_pass_s = float(first_pass_s)
        self.pass_period_s = float(pass_period_s)
        self.pass_duration_s = float(pass_duration_s)
        self.peak_kbps = float(peak_kbps)
        self.started_at = time.monotonic()
        self._manual_start: float | None = None
        self._manual_until: float | None = None
        self._manual_number = 0
        self._last_pass_number = 0

    def request_open(self) -> tuple[bool, int]:
        """Open a manual pass immediately; return (opened, pass_number)."""
        now = time.monotonic()
        current = self.state(now)
        if current["in_pass"]:
            return False, int(current["pass_number"])
        self._manual_number = max(self._manual_number, self._last_pass_number) + 1
        self._manual_start = now
        self._manual_until = now + self.pass_duration_s
        self._last_pass_number = self._manual_number
        return True, self._manual_number

    def _link(self, progress: float) -> tuple[float, float]:
        elevation = math.sin(math.pi * max(0.0, min(1.0, progress)))
        kbps = self.peak_kbps * (0.4 + 0.6 * elevation)
        loss = 0.02 + 0.25 * (1.0 - elevation) ** 2
        return kbps, min(loss, 0.9)

    def state(self, now: float | None = None) -> dict:
        now = time.monotonic() if now is None else now

        if self._manual_start is not None and self._manual_until is not None:
            if now < self._manual_until:
                elapsed = now - self._manual_start
                progress = elapsed / self.pass_duration_s
                kbps, loss = self._link(progress)
                self._last_pass_number = self._manual_number
                return {
                    "in_pass": True,
                    "pass_number": self._manual_number,
                    "seconds_to_next_pass": 0.0,
                    "seconds_remaining": self._manual_until - now,
                    "progress": progress,
                    "kbps": kbps,
                    "loss": loss,
                }
            self._manual_start = None
            self._manual_until = None

        elapsed = now - self.started_at
        if elapsed < self.first_pass_s:
            return {
                "in_pass": False,
                "pass_number": 0,
                "seconds_to_next_pass": self.first_pass_s - elapsed,
                "seconds_remaining": 0.0,
                "progress": 0.0,
                "kbps": 0.0,
                "loss": 1.0,
            }

        since_first = elapsed - self.first_pass_s
        pass_index = int(since_first // self.pass_period_s)
        offset = since_first - pass_index * self.pass_period_s
        pass_number = pass_index + 1
        self._last_pass_number = max(self._last_pass_number, pass_number)

        if offset >= self.pass_duration_s:
            return {
                "in_pass": False,
                "pass_number": pass_number,
                "seconds_to_next_pass": self.pass_period_s - offset,
                "seconds_remaining": 0.0,
                "progress": 0.0,
                "kbps": 0.0,
                "loss": 1.0,
            }

        progress = offset / self.pass_duration_s
        kbps, loss = self._link(progress)
        return {
            "in_pass": True,
            "pass_number": pass_number,
            "seconds_to_next_pass": 0.0,
            "seconds_remaining": self.pass_duration_s - offset,
            "progress": progress,
            "kbps": kbps,
            "loss": loss,
        }
