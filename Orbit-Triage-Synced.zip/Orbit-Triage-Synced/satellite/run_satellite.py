import argparse
import json
import shutil

from pathlib import Path

from inference.inference_engine import SatelliteInferenceEngine
from scheduler import SmartDownlinkScheduler

SATELLITE_DIR = Path(__file__).resolve().parent

TILE_STORAGE = SATELLITE_DIR / "storage" / "tiles"

DOWNLINK_OUTBOX = SATELLITE_DIR / "storage" / "downlink_outbox"


def simulated_transmission(item):
    """
    Local downlink simulation.

    Copies the selected tile and its metadata into the
    downlink outbox.

    This is NOT a real radio/UART transmission.
    """

    source = Path(item["image_ref"])

    if not source.is_file():
        raise FileNotFoundError(source)

    tile_id = item["tile_id"]

    destination = DOWNLINK_OUTBOX / f"{tile_id}.png"
    metadata_path = DOWNLINK_OUTBOX / f"{tile_id}.json"

    shutil.copy2(source, destination)

    metadata = {
        "tile_id": tile_id,
        "predicted_class": item["predicted_class"],
        "confidence": item["confidence"],
        "priority": item["priority"],
        "priority_name": item["priority_name"],
        "scores": item["scores"],
        "tile_metadata": item.get("tile_metadata"),
        "image_file": destination.name,
        "image_size_bytes": destination.stat().st_size,
    }

    with open(metadata_path, "w") as file:
        json.dump(metadata, file, indent=2)

    print(f"DOWNLINK SIMULATED: {tile_id}")

    # Local file copy succeeded.
    return True


def main():

    parser = argparse.ArgumentParser(
        description="Satellite image inference and scheduling pipeline"
    )

    parser.add_argument("image", help="Input satellite image path")

    parser.add_argument(
        "--requested",
        nargs="*",
        default=[],
        choices=[
            "Forest",
            "Cropland",
            "Urban",
            "Water",
            "Ship",
        ],
        help="Classes requested by ground station",
    )

    parser.add_argument(
        "--pass-kb", type=int, default=512, help="Available downlink capacity in KB"
    )

    parser.add_argument(
        "--cpu", action="store_true", help="Force ONNX inference to use CPU"
    )

    args = parser.parse_args()

    image_path = Path(args.image).expanduser().resolve()

    if not image_path.is_file():
        raise FileNotFoundError(image_path)

    if args.pass_kb <= 0:
        parser.error("--pass-kb must be positive")

    TILE_STORAGE.mkdir(parents=True, exist_ok=True)
    DOWNLINK_OUTBOX.mkdir(parents=True, exist_ok=True)

    # ----------------------------------------
    # STEP 1: LOAD INFERENCE ENGINE
    # ----------------------------------------

    print("\n[1] Loading satellite inference engine")

    engine = SatelliteInferenceEngine(batch_size=32, use_cuda=not args.cpu)

    # ----------------------------------------
    # STEP 2: PREPROCESS + INFERENCE
    # ----------------------------------------

    print("\n[2] Preprocessing and classifying image")

    tile_output_dir = TILE_STORAGE / image_path.stem

    inference_result = engine.classify_image(
        image_path, tile_output_dir=tile_output_dir
    )

    print(f"Original image: {image_path.name}")

    print(f"Tiles generated: {inference_result['num_tiles']}")

    print(
        "Mean image scores:", json.dumps(inference_result["mean_tile_scores"], indent=2)
    )

    # ----------------------------------------
    # STEP 3: INITIALIZE SCHEDULER
    # ----------------------------------------

    print("\n[3] Initializing priority scheduler")

    scheduler = SmartDownlinkScheduler(
        requested_classes=args.requested,
        cloud_drop_threshold=0.80,
        shadow_drop_threshold=0.80,
    )

    # ----------------------------------------
    # STEP 4: SEND INFERENCE OUTPUT TO SCHEDULER
    # ----------------------------------------

    print("\n[4] Processing tiles through scheduler")

    scheduling_results = scheduler.process_inference_result(inference_result)

    for status in scheduling_results:
        print(status)

    print("\nScheduler summary:")

    print("Total tiles:", len(scheduling_results))
    print("Queued:", scheduler.queued_count)
    print("Dropped:", scheduler.dropped_count)

    # ----------------------------------------
    # STEP 5: SIMULATE A DOWNLINK PASS
    # ----------------------------------------

    print("\n[5] Starting simulated downlink pass")

    available_bytes = args.pass_kb * 1024

    report = scheduler.transmit_on_pass(
        available_bytes=available_bytes, send_fn=simulated_transmission
    )

    print("\nDOWNLINK REPORT")
    print(json.dumps(report, indent=2))

    print("\nPipeline complete.")

    print("Transmitted tile files:", DOWNLINK_OUTBOX)


if __name__ == "__main__":
    main()
