# Orbit Triage — Synced version (satellite ↔ ground)

Ye package dono ends ko sync karta hai. Purana `Orbit-Triage-Final` isko
replace nahi karta — wo fallback ke liye rakh lo, ye synced package alag
folder mein hai.

## Tumhare faisle (jo maine lagu kiye)

- **7 classes hi rahenge** — Forest, Cropland, Urban, Water, Cloud,
  CloudShadow, Ship. Koi 6-class re-export nahi hua, model file wahi hai.
- **Power card hata diya** — ground UI mein ab power section nahi hai.
- **Open-pass button hata diya** — pass automatic hain, jab satellite
  range mein aata hai. Button dabane ki zaroorat nahi.
- **Sab change kar sakta hoon** — isliye satellite ke scheduler, queue,
  ws_client, satellite_main aur ground UI, sab change kiye hain. Model
  file aur inference engine ke class list ko haath nahi lagaya.

## Naya flow (judges ko yahi samjhana hai)

1. **Capture + infer + store, koi dropping nahi.** Har tile apne raw
   scores ke saath queue mein jaata hai. Jo tile mission ke liye relevant
   nahi hai, wo **held onboard** hota hai (DB mein DROPPED, file disk
   par hi rehti hai, delete nahi hoti). UI mein "dropped" ki jagah
   "held onboard" likha hai.
2. **Relevance formula (UI wala, ab dono taraf same hai):**
   relevance = interest classes ke scores ka sum
               − Cloud score (agar Cloud interest mein nahi hai)
               − CloudShadow score (agar CloudShadow interest mein nahi hai)
   relevance ≥ picky+band (default 0.70+0.20 = 0.90) → priority 1, MISSION
   relevance ≤ picky−band (0.50) → held onboard
   beech mein → priority 2, AMBIGUOUS (baad mein bheja jaata hai)
3. **Mission popup, timed, non-blocking.** Pass khatam hote hi ground UI
   mein popup aata hai: "Next mission?" 60 second ka timer chalta hai,
   aur usmein satellite ke agle pass tak ka movement bhi dikhta hai
   (telemetry se "Next pass in X s"). Agar tum 60 sec mein naya mission
   chunte ho, to wo **next pass start par** apply hota hai, queue
   re-rank hoti hai, held tiles wapas PENDING ho sakte hain.
   **Agar tum kuch nahi chunte, to popup band ho jaata hai aur purana
   mission hi agle pass tak chalta hai — satellite kabhi popup ka wait
   nahi karta.**
4. **Ground par profile turant apply nahi hota.** Ground se profile
   bhejte hi satellite pehle `command_received (apply = next pass start)`
   bhejta hai, phir next pass start par `profile_applied` bhejta hai,
   re-rank stats ke saath. Yehi pehle ka sabse bada mismatch tha.
5. **Recycle — 90 images wapas incoming mein, sirf jab queue khaali ho.**
   - Agar pass ke baad held tiles bache hain, to recycle NAHI hota.
     Sirf re-rank hota hai, aur held tiles hi agle pass mein jaate hain.
     Already-ACKED tiles dobara nahi bheje jaate.
   - Agar queue bilkul khaali hai (koi PENDING/RETRY aur koi HELD nahi)
     aur naya mission aata hai, to satellite archive images ko wapas
     `incoming/` mein copy karta hai, markers/queue/tiles saaf karta hai,
     aur ingestor unko naye mission ke hisaab se dobara queue karta hai.
     Ground ko naya `run_id` ke saath hello milta hai, isliye inbox
     saaf ho jaata hai aur naye cycle ke cards fresh dikhte hain.
   - **Manual new cycle:** Ground UI mein "Start new cycle (same images
     again)" button hai. Ye kabhi bhi recycle kar dega (held tiles hon
     tab bhi), kyunki tumne khud maanga hai. Pass ke beech mein agar koi
     tile sending mein hai, to recycle refuse ho jaata hai.
6. **Tile IDs neutral hain.** Ab frame_id `IMG<hash>_000000` jaisa hai.
   Original, label wala naam sirf satellite ke `tile_metadata` mein hai
   (FIFO comparison ke liye), ground UI par kabhi nahi dikhta.
7. **Capture time aur latency cards par dikhte hain.** Har card par:
   Capture (mission time, jaise T+ 00:12), Latency (send time − capture
   time, satellite par hi calculate hota hai, isliye dono laptop ki
   ghadiyan alag hon tab bhi sahi hai), Priority (MISSION/AMBIGUOUS).
8. **Chips interest_classes se bante hain.** Ground UI mein selectable
   classes hain: Forest, Cropland, Urban, Water, Cloud, Ship.
   CloudShadow selectable nahi hai (wo adverse observation hai, target
   nahi), par uska score relevance mein ab bhi ghat-ta hai.
9. **Inbox wipe bug fix.** Satellite har reconnect par hello bhejta hai,
   par ground inbox tabhi saaf karta hai jab `run_id` badle. Wi-Fi blip
   par screen saaf nahi hogi. Inbox cap 100 se badha kar 1000 kar diya
   hai, aur inbox header mein har class ka count dikhta hai
   (jaise "Forest 12 · Cropland 8").

## Kya change hua, file-wise

Satellite:
- `scheduler.py` — relevance/picky/band decide, `apply_profile`,
  predicted_class ab saare 7 classes ka argmax hai, neutral IDs, koi
  hard cloud/shadow drop nahi.
- `storage/queue_manager.py` — `relevance` column (purane DB mein
  auto-migrate hoti hai), sort `priority, relevance DESC, created_at`,
  `reprioritize(fn)` ek transaction mein, `reset_queue()`.
- `downlink/satellite_ws_client.py` — pending profile at pass start,
  `run_id` hello, `interest_classes` hello, capture_t/latency/relevance
  frame_meta aur delivered mein, dead `_command_loop` / `_ack_reader`
  delete, `new_cycle` command, recycle par naya hello.
- `acquisition/image_source.py` — capture_t_elapsed + capture_utc,
  inference timing (mean/last ms) telemetry ke liye.
- `satellite_main.py` — `--interest`, `--picky`, `--band` (purana
  `--requested` alias ki tarah kaam karta hai, cloud/shadow threshold
  ab ignore hote hain), `--stable-wait` default 0.1, shared mission
  epoch (pass_controller.started_at), recycle function.
- `feeder.py` (naya) — dataset folder se har N second mein ek image
  `incoming/` mein copy karta hai, taaki queue pass ke beech mein
  badhta dikhe. Source folder ko kabhi modify nahi karta.
- `fifo_vs_triage.py` (naya) — ek pass ke liye real-data FIFO vs
  triage comparison (neeche dekho).
- `run_satellite.py` — IGNORE karo, ye purana single-image local-copy
  CLI hai, network demo ke liye nahi hai. Ismein koi change nahi kiya.

Ground:
- `ground/live_ground.html` — power card hataya, Open-pass button
  hataya, mission popup (60s, timed), run_id inbox logic, inbox cap
  1000 + class counts, card fields (capture/latency/priority),
  chips interest_classes se, "held onboard" wording.
- `ground/ground_receiver.py` — delivered cap 100 → 1000, event cap
  100 → 500, ACK + PNG fix pehle wala hi hai (is package mein bhi hai).

## Run steps — two laptops (Linux satellite, Windows ground)

Ground (Windows, PowerShell, `Orbit-Triage-Synced/ground` folder mein):
```
python -m pip install -r requirements.txt
python .\ground_receiver.py --host 0.0.0.0 --port 8765
```
Browser: `http://localhost:8765/` — shuru mein inbox khaali hona chahiye,
yehi proof hai ki ground sirf receive hone par dikhata hai.

Satellite (Linux, `Orbit-Triage-Synced/satellite` folder mein, pehli baar):
```
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
```
Har baar (venv activate karke):
```
python3 satellite_main.py --ground ws://<GROUND_IP>:8765/ws/satellite \
  --interest Forest Cropland Urban Water --cpu \
  --first-pass 10 --pass-period 120 --pass-length 60 --peak-kbps 256 \
  --stable-wait 0.1
```
`<GROUND_IP>` Windows laptop ka hotspot IP hai (usually 192.168.137.1,
`ipconfig` se verify karo). **127.0.0.1 satellite par kabhi mat use karo
do-laptop run mein.**

Feeder (alag terminal, satellite laptop par, jab demo ke liye 800 tiles
chahiye hon):
```
python3 feeder.py --source-dir /path/to/dataset --interval 1.0
```
Dataset folder pristine rehna chahiye — feeder sirf copy karta hai.

Fresh start (purana queue saaf karke naya demo):
Satellite folder mein `storage/queue.db*`, `storage/tiles/*`,
`storage/metadata/*.json` delete karo. `storage/archive/` mat delete
karo — wahi recycle ka source hai. Agar naya dataset chahiye, to
archive bhi saaf karke feeder se naya dataset daalo.

## Demo flow jo test kiya hai

1. Ground inbox khaali dikhao, satellite par queue badhta dikhao
   (`python3 storage/queue_manager.py --list PENDING`).
2. Mission A: Forest. Pass automatic khulta hai, Forest tiles pehle
   jaate hain, baaki held rehte hain, pass backlog ke saath band hota hai.
3. Pass end popup mein Mission B: Vegetation (Forest+Cropland) chuno.
   Agle pass start par held Cropland tiles re-rank hokar jaate hain,
   unki latency ~50 sec dikhti hai (wo Pass 1 se wait kar rahe the).
4. Agar queue khaali ho jaaye aur naya mission chuno, to recycle hota
   hai — archive images wapas incoming mein, naya run, fresh inbox.
5. FIFO comparison ke liye satellite par:
```
python3 fifo_vs_triage.py --db storage/queue.db --pass-id PASS_0001 \
  --interest Forest --picky 0.70 --band 0.20
```

## Test results (is machine par, real ONNX model ke saath)

- Unit test (scheduler + queue): Forest mission se Water mission par
  re-rank sahi hua — Water tile PENDING, Forest tile HELD, order
  priority → relevance → capture time ke hisaab se.
- Fake integration (real ws_client + real ground): profile bhejne par
  `command_received` aaya, `profile_applied` sirf pass start par aaya,
  Water tile MISSION priority par pehle gaya, replay mein wahi 1 tile
  ek baar aaya, `new_cycle` par naya `run_id` hello aaya.
- Real ONNX full test (6 images, Forest → Vegetation, automatic pass):
  Pass 1: 3 Forest tiles MISSION, relevance ~0.999, capture_t ~0.65s,
  latency ~5s, files `.png` sahi. 3 Cropland tiles held.
  Pass 2 (Vegetation): wahi 3 held Cropland tiles MISSION/AMBIGUOUS
  par gaye, latency ~50s (Pass 1 se wait kar rahe the). Total 6/6 ACKED,
  koi duplicate nahi, koi Forest tile dobara nahi bheja gaya.
  Pass-start recycle test (purana version) mein 6 tiles dobara gaye the
  — final version mein recycle sirf queue khaali hone par hota hai,
  isliye Pass 2 mein sirf held tiles gaye.

## Honest limits — judges se ye mat chhupana

- **Water mission is dataset mein khaali ja sakta hai.** Real model ke
  Water tiles mein Cloud score 0.61–0.68 hota hai, isliye Water mission
  mein relevance = Water − Cloud − CloudShadow ≈ −0.36 hota hai, wo
  held rehte hain. Isliye demo ke liye Vegetation (Forest+Cropland)
  preset use karo, ya mission mein Cloud ko bhi interest mein lo.
  Ye model calibration ki baat hai, UI ki nahi — picky 0.70 sigmoid
  scores ke liye strict hai, sirf saaf tiles hi MISSION bante hain.
- **FIFO gain har pass mein nahi dikhega.** Pass 1 (Forest) mein triage
  ne 3 relevant bheje, FIFO ne 2 tiles mein 0 relevant bheje (gain +3).
  Pass 2 (Vegetation) mein baaki saare tiles hi relevant the, isliye
  FIFO aur triage dono ne 3 relevant bheje (gain 0). Ye sahi hai —
  FIFO comparison tabhi meaningful hai jab queue mein mixed relevance ho.
- **Link, sensor aur pass timing simulated hain.** Radio throttled
  WebSocket hai, sensor dataset tiles hain, pass timing emulated hai.
  Power card isliye hataya hai (koi sensor nahi hai).
- **STM32 is pipeline mein nahi hai.** Model laptop par ONNX se chalta
  hai. Jo keh sakte ho: int8 model 1.27 MB hai, 4.2 MB budget ke andar
  hai. Activation RAM measure nahi hui hai, isliye total RAM mat claim
  karo.
- **Fault buttons** ground UI mein ab bhi hain, par satellite ki taraf
  se reply aata hai "fault injection not implemented" — wo link ko
  asli mein affect nahi karte.
- **No auth** — port 8765 sirf trusted private LAN par rakho.
- **Two-laptop LAN run tumhare machines par abhi test nahi hua hai.**
  Yahan one-laptop aur local sender integration test hue hain, Windows
  ground + Linux satellite ka asli LAN test tumko apne laptops par
  karna hai.
