import os

import dotenv
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image, ImageDraw
from torchvision.models import mobilenet_v3_small

dotenv.load_dotenv()

# ---------------- Paths ----------------
data_root = os.getenv("DATA_ROOT")
cache_dir = os.path.join(data_root, "cache")
models_dir = os.path.join(data_root, "models")
out_dir = os.path.join(models_dir, "diagnostics")
os.makedirs(out_dir, exist_ok=True)
# ---------------- Settings ----------------
SEED = 0
CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
HAZE_TILES = 1500                       # EuroSAT tiles used in the haze test
HAZE_ALPHAS = [0.0, 0.2, 0.4, 0.6, 0.8]
HAZE_COLOURS = {"white": 255.0, "light grey": 200.0}
MONTAGE_TILES = 32                      # tiles per montage
MONTAGE_COLS = 8
MONTAGE_SCALE = 3                       # tiles are shown 3x larger

rng = np.random.default_rng(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
use_amp = device.type == "cuda"


# ---------------- Model (same as train_baseline.py) ----------------
class Net(nn.Module):
    def __init__(self, num_classes, input_size):
        super().__init__()
        backbone = mobilenet_v3_small(weights=None)
        self.input_size = input_size
        self.features = backbone.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.drop = nn.Dropout(0.2)
        self.fc = nn.Linear(576, num_classes)
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, x):
        if self.input_size != x.shape[-1]:
            x = F.interpolate(x, size=(self.input_size, self.input_size), mode="bilinear", align_corners=False)
        x = (x - self.mean) / self.std
        x = self.pool(self.features(x)).flatten(1)
        return self.fc(self.drop(x))


ckpt = torch.load(os.path.join(models_dir, "best_fp32.pt"), map_location=device)
model = Net(len(CLASSES), ckpt["input_size"]).to(device)
model.load_state_dict(ckpt["state_dict"])
model.eval()
print(f"Loaded best model from epoch {ckpt['epoch']} (input {ckpt['input_size']}x{ckpt['input_size']}), device {device}")


@torch.no_grad()
def predict_uint8(X, bs=1024):
    out = []
    for i in range(0, len(X), bs):
        xb = torch.from_numpy(np.ascontiguousarray(X[i:i + bs])).to(device).permute(0, 3, 1, 2).float() / 255.0
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            logits = model(xb)
        out.append(torch.sigmoid(logits.float()).cpu())
    return torch.cat(out).numpy()


# ---------------- Data ----------------
print("Loading calibration split...")
cal = np.load(os.path.join(cache_dir, "cal.npz"))
X, Y, M = cal["X"], cal["Y"], cal["M"]
group, source = cal["group"], cal["source"]
saved = np.load(os.path.join(models_dir, "cal_probs.npz"))
probs = saved["probs"]
assert probs.shape[0] == X.shape[0], "cal_probs.npz does not match cal.npz (re-run train_baseline.py)"

check = predict_uint8(X[:2000])
print(f"Sanity check: model reproduces the saved predictions, max difference {np.abs(check - probs[:2000]).max():.4f} "
      f"(should be below about 0.01)")


# ---------------- Helpers ----------------
def curve(y, s):
    """Average precision, best F1 and its threshold, plus the precision/recall curve."""
    order = np.argsort(-s, kind="mergesort")
    y_s, s_s = y[order], s[order]
    tp = np.cumsum(y_s)
    fp = np.cumsum(1 - y_s)
    prec = tp / (tp + fp)
    total = max(float(y.sum()), 1.0)
    rec = tp / total
    ap = float((prec * y_s).sum() / total)
    f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
    k = int(f1.argmax())
    return ap, float(f1[k]), float(s_s[k]), prec, rec


def counts_at(y, s, thr):
    pred = s >= thr
    tp = int((pred & (y == 1)).sum())
    fp = int((pred & (y == 0)).sum())
    fn = int((~pred & (y == 1)).sum())
    tn = int((~pred & (y == 0)).sum())
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn, 1)
    return tp, fp, fn, tn, prec, rec


def montage(idx, titles, path, header):
    """Grid of tiles with a small caption on each."""
    size = X.shape[1] * MONTAGE_SCALE
    rows = int(np.ceil(len(idx) / MONTAGE_COLS))
    bar = 22
    canvas = Image.new("RGB", (MONTAGE_COLS * size, rows * size + bar), (25, 25, 25))
    draw = ImageDraw.Draw(canvas)
    draw.text((6, 5), header, fill=(255, 255, 255))
    for n, (i, t) in enumerate(zip(idx, titles)):
        r, c = divmod(n, MONTAGE_COLS)
        im = Image.fromarray(X[i]).resize((size, size), Image.NEAREST)
        canvas.paste(im, (c * size, bar + r * size))
        x0, y0 = c * size + 3, bar + r * size + 2
        draw.text((x0 + 1, y0 + 1), t, fill=(0, 0, 0))
        draw.text((x0, y0), t, fill=(255, 255, 0))
    canvas.save(path)
    print(f"  saved {path}")


# ======================================================================
print("\n" + "=" * 74)
print("1. CloudShadow and Cloud: where does the difficulty sit? (CloudSEN12 cal tiles)")
print("=" * 74)
cs = source == "cloudsen12"
for cname, pos_groups in (("CloudShadow", ["CloudShadow", "CloudBoth"]), ("Cloud", ["Cloud", "CloudBoth"])):
    j = CLASSES.index(cname)
    y_all = np.isin(group[cs], pos_groups).astype(np.float32)
    s_all = probs[cs, j]
    ap, f1, thr, _, _ = curve(y_all, s_all)
    print(f"\n{cname}: AP {ap:.3f}, best F1 {f1:.3f} at threshold {thr:.3f}")
    print(f"  {'group':12s} {'tiles':>7s} {'mean prob':>10s} {'flagged at best-F1 threshold':>30s}")
    for g in ["Clear", "Cloud", "CloudShadow", "CloudBoth"]:
        sel = group[cs] == g
        if sel.sum() == 0:
            continue
        role = "positive" if g in pos_groups else "negative"
        print(f"  {g:12s} {int(sel.sum()):7d} {s_all[sel].mean():10.3f} {100 * (s_all[sel] >= thr).mean():24.1f} %   ({role})")

print("\nLike-for-like contrasts for CloudShadow (AP, tiles with the same cloud situation):")
j = CLASSES.index("CloudShadow")
for pos, neg, label in (("CloudShadow", "Clear", "shadow only vs clear (no cloud anywhere)"),
                        ("CloudBoth", "Cloud", "shadow+cloud vs cloud only")):
    sel = cs & np.isin(group, [pos, neg])
    y = (group[sel] == pos).astype(np.float32)
    ap, f1, thr, _, _ = curve(y, probs[sel, j])
    print(f"  {label:45s} AP {ap:.3f}  best F1 {f1:.3f}  ({int(y.sum())} positives, {int((1 - y).sum())} negatives)")

# ======================================================================
print("\n" + "=" * 74)
print("2. Operating points on the calibration split (useful for choosing thresholds)")
print("=" * 74)
for cname in ("Cloud", "CloudShadow", "Ship"):
    j = CLASSES.index(cname)
    src = {"Cloud": "cloudsen12", "CloudShadow": "cloudsen12", "Ship": "hrsid"}[cname]
    sel = (M[:, j] == 1) & (source == src)
    y, s = Y[sel, j], probs[sel, j]
    ap, f1, thr, prec, rec = curve(y, s)
    print(f"\n{cname} ({src}, {int(y.sum())} positives of {len(y)} tiles): AP {ap:.3f}")
    tp, fp, fn, tn, p_, r_ = counts_at(y, s, thr)
    print(f"  best F1 {f1:.3f} at threshold {thr:.3f}: precision {p_:.3f}, recall {r_:.3f}  (TP {tp}, FP {fp}, FN {fn})")
    tp, fp, fn, tn, p_, r_ = counts_at(y, s, 0.5)
    print(f"  at threshold 0.5:        precision {p_:.3f}, recall {r_:.3f}  (TP {tp}, FP {fp}, FN {fn})")
    for target in (0.95, 0.90, 0.80):
        ok = rec[prec >= target]
        print(f"  best recall with precision >= {target:.2f}: {ok.max() if len(ok) else 0.0:.3f}"
              f"      best precision with recall >= {target:.2f}: "
              f"{prec[rec >= target].max() if (rec >= target).any() else 0.0:.3f}")
    if cname == "Ship":
        pos_s = s[y == 1]
        print("  Ship-tile score percentiles (10/25/50/75/90):",
              np.round(np.percentile(pos_s, [10, 25, 50, 75, 90]), 3))
        print("  NoShip-tile score percentiles (50/90/99/99.9):",
              np.round(np.percentile(s[y == 0], [50, 90, 99, 99.9]), 4))

# ======================================================================
print("\n" + "=" * 74)
print("3. Haze test: does the Cloud output respond to real cloud-like haze on EuroSAT tiles?")
print("=" * 74)
e_idx = np.where(source == "eurosat")[0]
e_idx = rng.choice(e_idx, min(HAZE_TILES, len(e_idx)), replace=False)
base = X[e_idx].astype(np.float32)
jc, js = CLASSES.index("Cloud"), CLASSES.index("CloudShadow")
print(f"{'blend':12s} {'alpha':>6s} {'mean Cloud prob':>16s} {'Cloud > 0.5':>12s} {'mean Shadow prob':>17s}")
for cname_, colour in HAZE_COLOURS.items():
    for a in HAZE_ALPHAS:
        hazy = np.clip((1 - a) * base + a * colour, 0, 255).astype(np.uint8)
        p = predict_uint8(hazy)
        print(f"{cname_:12s} {a:6.1f} {p[:, jc].mean():16.3f} {100 * (p[:, jc] > 0.5).mean():10.1f} % {p[:, js].mean():17.3f}")
print("Reading it: Cloud probability should climb steadily as the blend gets stronger. If it stays near 0 even at\n"
      "alpha 0.6-0.8 (tiles that are mostly white), the model is probably using 'looks like EuroSAT' as a shortcut.")

# ======================================================================
print("\n" + "=" * 74)
print("4. Land outputs on CloudSEN12 'Clear' tiles (no land labels exist for these)")
print("=" * 74)
clear_idx = np.where(cs & (group == "Clear"))[0]
pc = probs[clear_idx, :4]
print(f"Clear tiles: {len(clear_idx)}")
print(f"{'class':10s} {'mean':>7s} {'> 0.5':>8s} {'> 0.9':>8s}")
for j, c in enumerate(CLASSES[:4]):
    print(f"{c:10s} {pc[:, j].mean():7.3f} {100 * (pc[:, j] > 0.5).mean():6.1f} % {100 * (pc[:, j] > 0.9).mean():6.1f} %")
print(f"Tiles where NO land class exceeds 0.5: {100 * (pc.max(axis=1) <= 0.5).mean():.1f} %")
print(f"Tiles where some land class exceeds 0.9: {100 * (pc.max(axis=1) > 0.9).mean():.1f} %")
print("Reading it: a high share above 0.9 is only a problem if the montage below shows the tiles do NOT look like\n"
      "that land type (for example snow or bare rock called Water).")

# ======================================================================
print("\n" + "=" * 74)
print("5. Montages of the worst mistakes (read straight from the cache)")
print("=" * 74)
n = MONTAGE_TILES

j = CLASSES.index("Ship")
ship_pos = np.where((source == "hrsid") & (Y[:, j] == 1))[0]
ship_neg = np.where((source == "hrsid") & (Y[:, j] == 0))[0]
worst_fn = ship_pos[np.argsort(probs[ship_pos, j])[:n]]
worst_fp = ship_neg[np.argsort(-probs[ship_neg, j])[:n]]
montage(worst_fn, [f"{probs[i, j]:.2f}" for i in worst_fn], os.path.join(out_dir, "ship_missed.png"),
        "Ship tiles the model scored LOWEST (missed ships). Are there visible ships?")
montage(worst_fp, [f"{probs[i, j]:.2f}" for i in worst_fp], os.path.join(out_dir, "ship_false_alarms.png"),
        "NoShip tiles scored HIGHEST (false alarms). Are there real ships the labels missed?")

j = CLASSES.index("CloudShadow")
sh_pos = np.where(cs & np.isin(group, ["CloudShadow", "CloudBoth"]))[0]
sh_neg = np.where(cs & np.isin(group, ["Clear", "Cloud"]))[0]
worst_fn = sh_pos[np.argsort(probs[sh_pos, j])[:n]]
worst_fp = sh_neg[np.argsort(-probs[sh_neg, j])[:n]]
montage(worst_fn, [f"{group[i][:6]} {probs[i, j]:.2f}" for i in worst_fn], os.path.join(out_dir, "shadow_missed.png"),
        "Shadow-labelled tiles scored LOWEST. Is the shadow visible, or only a thin sliver?")
montage(worst_fp, [f"{group[i][:6]} {probs[i, j]:.2f}" for i in worst_fp], os.path.join(out_dir, "shadow_false_alarms.png"),
        "Tiles WITHOUT shadow label scored HIGHEST. Do they actually contain shadow?")

for j, c in enumerate(CLASSES[:4]):
    cand = clear_idx[probs[clear_idx, j] > 0.9]
    if len(cand) == 0:
        continue
    pick = rng.choice(cand, min(n, len(cand)), replace=False)
    montage(pick, [f"{probs[i, j]:.2f}" for i in pick], os.path.join(out_dir, f"clear_called_{c}.png"),
            f"CloudSEN12 Clear tiles the model calls {c} (prob > 0.9). Does that look right?")

print(f"\nDone. Open the PNG files in {out_dir}")
