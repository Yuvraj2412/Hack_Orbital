import json
import os
import time

import dotenv
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import MobileNet_V3_Small_Weights, mobilenet_v3_small

dotenv.load_dotenv()

# ---------------- Paths ----------------
data_root = os.getenv("DATA_ROOT")
cache_dir = os.path.join(data_root, "cache")
models_dir = os.path.join(data_root, "models")
os.makedirs(models_dir, exist_ok=True)

# ---------------- Settings ----------------
SEED = 0
INPUT_SIZE = 96          # tiles are 64x64; they are resized INSIDE the model to this size (64 = no resize)
BATCH = 256
EPOCHS = 20
PATIENCE = 4             # stop if macro AP on the calibration split has not improved for this many epochs
LR = 2e-3
WEIGHT_DECAY = 1e-4
PRETRAINED = True        # ImageNet weights (needs internet the first time); False = random start
DATA_ON_GPU = True       # keep the uint8 tiles on the GPU (about 1.6 GB for train + cal); falls back to CPU if it does not fit
USE_AMP = True           # mixed precision on the GPU

CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
# Each class is scored only on the source where its labels are real. Cloud and CloudShadow use CloudSEN12
# only, because EuroSAT tiles are all "no cloud" and would make the score look better than it is.
EVAL_SOURCE = {"Forest": "eurosat", "Cropland": "eurosat", "Urban": "eurosat", "Water": "eurosat",
               "Cloud": "cloudsen12", "CloudShadow": "cloudsen12", "Ship": "hrsid"}
NUM_CLASSES = len(CLASSES)

# Mild brightness/contrast jitter so the model cannot lean on global brightness
BRIGHT_JITTER = 0.15     # factor drawn from [1 - x, 1 + x]
CONTRAST_JITTER = 0.15

torch.manual_seed(SEED)
np.random.seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
use_amp = USE_AMP and device.type == "cuda"
print(f"Device: {device}" + (f" ({torch.cuda.get_device_name(0)})" if device.type == "cuda" else ""))
if device.type == "cpu":
    print("WARNING: no GPU found by PyTorch, training on CPU will be slow.")


# ---------------- Data ----------------
def load_split(name):
    d = np.load(os.path.join(cache_dir, f"{name}.npz"))
    return {k: d[k] for k in ["X", "Y", "M", "group", "source"]}


def to_device_tensors(split, dev):
    return (torch.from_numpy(split["X"]).to(dev),
            torch.from_numpy(split["Y"]).to(dev),
            torch.from_numpy(split["M"]).to(dev))


print("Loading cache...")
train = load_split("train")
cal = load_split("cal")
print(f"train tiles: {len(train['X'])}   cal tiles: {len(cal['X'])}")

data_device = device if (DATA_ON_GPU and device.type == "cuda") else torch.device("cpu")
try:
    Xtr, Ytr, Mtr = to_device_tensors(train, data_device)
    Xca, Yca, Mca = to_device_tensors(cal, data_device)
except torch.cuda.OutOfMemoryError:
    print("GPU memory too small for the data, keeping tiles on the CPU instead.")
    torch.cuda.empty_cache()
    data_device = torch.device("cpu")
    Xtr, Ytr, Mtr = to_device_tensors(train, data_device)
    Xca, Yca, Mca = to_device_tensors(cal, data_device)

# Balanced sampling: each tile is drawn with weight 1/sqrt(size of its group)
groups, counts = np.unique(train["group"], return_counts=True)
count_of = dict(zip(groups.tolist(), counts.tolist()))
sample_w = np.array([1.0 / np.sqrt(count_of[g]) for g in train["group"].tolist()], dtype=np.float64)
sample_w = torch.tensor(sample_w / sample_w.sum(), dtype=torch.float32)
print("train groups:", count_of)


# ---------------- Model ----------------
class Net(nn.Module):
    """Input: float tiles in [0, 1], shape (B, 3, 64, 64). Resize and normalisation are inside the model,
    so the exported model needs no extra preprocessing."""

    def __init__(self, num_classes, input_size, pretrained):
        super().__init__()
        weights = MobileNet_V3_Small_Weights.IMAGENET1K_V1 if pretrained else None
        try:
            backbone = mobilenet_v3_small(weights=weights)
        except Exception as e:
            print(f"Could not load pretrained weights ({type(e).__name__}); starting from random weights.")
            backbone = mobilenet_v3_small(weights=None)
        self.input_size = input_size
        self.features = backbone.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.drop = nn.Dropout(0.2)
        self.fc = nn.Linear(576, num_classes)     # light head: one linear layer instead of the 1000-class MLP
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, x):
        if self.input_size != x.shape[-1]:
            x = F.interpolate(x, size=(self.input_size, self.input_size), mode="bilinear", align_corners=False)
        x = (x - self.mean) / self.std
        x = self.pool(self.features(x)).flatten(1)
        return self.fc(self.drop(x))


model = Net(NUM_CLASSES, INPUT_SIZE, PRETRAINED).to(device)
n_params = sum(p.numel() for p in model.parameters())
print(f"Parameters: {n_params / 1e6:.2f} M  (about {n_params * 4 / 1e6:.1f} MB as float32, "
      f"{n_params / 1e6:.1f} MB as int8)")


# ---------------- Loss, augmentation, metrics ----------------
def masked_bce(logits, y, m):
    """Binary cross-entropy over labelled entries only, averaged per class, then over classes with labels."""
    loss = F.binary_cross_entropy_with_logits(logits, y, reduction="none") * m
    n = m.sum(0)
    per_class = loss.sum(0) / n.clamp(min=1.0)
    return per_class[n > 0].mean()


def augment(x):
    """x: float (B, 3, H, W) in [0, 1] on the GPU."""
    b = x.shape[0]
    hflip = torch.rand(b, device=x.device) < 0.5
    vflip = torch.rand(b, device=x.device) < 0.5
    x = torch.where(hflip.view(-1, 1, 1, 1), x.flip(3), x)
    x = torch.where(vflip.view(-1, 1, 1, 1), x.flip(2), x)
    k = int(torch.randint(0, 4, (1,)).item())
    if k:
        x = torch.rot90(x, k, dims=(2, 3))
    bright = 1.0 + (torch.rand(b, 1, 1, 1, device=x.device) * 2 - 1) * BRIGHT_JITTER
    contrast = 1.0 + (torch.rand(b, 1, 1, 1, device=x.device) * 2 - 1) * CONTRAST_JITTER
    mean = x.mean(dim=(1, 2, 3), keepdim=True)
    x = ((x - mean) * contrast + mean) * bright
    return x.clamp(0.0, 1.0)


def pr_metrics(y, s):
    """Average precision and best F1 over all thresholds."""
    order = np.argsort(-s, kind="mergesort")
    y = y[order]
    tp = np.cumsum(y)
    prec = tp / np.arange(1, len(y) + 1)
    total = max(float(y.sum()), 1.0)
    rec = tp / total
    ap = float((prec * y).sum() / total)
    f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
    return ap, float(f1.max())


@torch.no_grad()
def predict(net, X, bs=1024):
    net.eval()
    out = []
    for i in range(0, len(X), bs):
        xb = X[i:i + bs].permute(0, 3, 1, 2).to(device).float() / 255.0
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            logits = net(xb)
        out.append(torch.sigmoid(logits.float()).cpu())
    return torch.cat(out).numpy()


def evaluate(probs, split):
    Y, M = split["Y"], split["M"]
    source, group = split["source"], split["group"]
    per_class = {}
    for j, c in enumerate(CLASSES):
        sel = (M[:, j] == 1) & (source == EVAL_SOURCE[c])
        y, s = Y[sel, j], probs[sel, j]
        if len(y) == 0 or y.sum() == 0 or y.sum() == len(y):
            per_class[c] = (float("nan"), float("nan"), int(len(y)), int(y.sum()))
        else:
            ap, f1 = pr_metrics(y, s)
            per_class[c] = (ap, f1, int(len(y)), int(y.sum()))
    macro_ap = float(np.nanmean([v[0] for v in per_class.values()]))
    es = source == "eurosat"
    checks = {
        "eurosat_cloud_over_0.5": float((probs[es, CLASSES.index("Cloud")] > 0.5).mean()),
        "eurosat_shadow_over_0.5": float((probs[es, CLASSES.index("CloudShadow")] > 0.5).mean()),
    }
    clear = (source == "cloudsen12") & (group == "Clear")
    land_on_clear = {c: float(probs[clear, j].mean()) for j, c in enumerate(CLASSES[:4])} if clear.any() else {}
    return per_class, macro_ap, checks, land_on_clear


# ---------------- Training ----------------
optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
steps_per_epoch = len(Xtr) // BATCH
scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=LR, total_steps=EPOCHS * steps_per_epoch,
                                                pct_start=0.15)
try:
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
except Exception:
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

best_path = os.path.join(models_dir, "best_fp32.pt")
best_macro, best_epoch, history = -1.0, 0, []
print(f"\nTraining: {EPOCHS} epochs max, {steps_per_epoch} steps per epoch, batch {BATCH}, input {INPUT_SIZE}x{INPUT_SIZE}\n")

for epoch in range(1, EPOCHS + 1):
    t0 = time.time()
    model.train()
    idx_all = torch.multinomial(sample_w, steps_per_epoch * BATCH, replacement=True)
    running = 0.0
    for s in range(steps_per_epoch):
        idx = idx_all[s * BATCH:(s + 1) * BATCH].to(data_device)
        xb = Xtr[idx].permute(0, 3, 1, 2).to(device, non_blocking=True).float() / 255.0
        yb = Ytr[idx].to(device, non_blocking=True)
        mb = Mtr[idx].to(device, non_blocking=True)
        xb = augment(xb)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=use_amp):
            logits = model(xb)
        loss = masked_bce(logits.float(), yb, mb)
        optimizer.zero_grad(set_to_none=True)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        scheduler.step()
        running += float(loss.item())

    probs = predict(model, Xca)
    per_class, macro_ap, checks, land_on_clear = evaluate(probs, cal)
    history.append({"epoch": epoch, "loss": running / steps_per_epoch, "macro_ap": macro_ap,
                    "ap": {c: v[0] for c, v in per_class.items()}, "checks": checks})
    ap_str = "  ".join(f"{c[:6]}={per_class[c][0]:.3f}" for c in CLASSES)
    print(f"epoch {epoch:2d}/{EPOCHS}  loss {running / steps_per_epoch:.4f}  macro AP {macro_ap:.4f}  "
          f"({time.time() - t0:.0f}s)")
    print(f"    AP: {ap_str}")
    print(f"    EuroSAT tiles flagged Cloud/Shadow at 0.5: "
          f"{checks['eurosat_cloud_over_0.5']:.4f} / {checks['eurosat_shadow_over_0.5']:.4f}")

    if macro_ap > best_macro:
        best_macro, best_epoch = macro_ap, epoch
        torch.save({"state_dict": model.state_dict(), "classes": CLASSES, "input_size": INPUT_SIZE,
                    "epoch": epoch, "macro_ap": macro_ap}, best_path)
        print("    saved new best model")
    elif epoch - best_epoch >= PATIENCE:
        print(f"No improvement for {PATIENCE} epochs, stopping early.")
        break

# ---------------- Final report on the calibration split (best epoch) ----------------
ckpt = torch.load(best_path, map_location=device)
model.load_state_dict(ckpt["state_dict"])
probs = predict(model, Xca)
per_class, macro_ap, checks, land_on_clear = evaluate(probs, cal)

print("\n" + "=" * 70)
print(f"Best epoch {best_epoch}, macro AP on calibration split: {macro_ap:.4f}")
print("=" * 70)
print(f"{'class':12s} {'AP':>7s} {'best F1':>8s} {'tiles':>8s} {'positives':>10s}   scored on")
for c in CLASSES:
    ap, f1, n, pos = per_class[c]
    print(f"{c:12s} {ap:7.3f} {f1:8.3f} {n:8d} {pos:10d}   {EVAL_SOURCE[c]}")
print("\nShortcut checks (calibration split):")
print(f"  EuroSAT tiles with Cloud prob > 0.5:       {checks['eurosat_cloud_over_0.5']:.4f}   (should be near 0)")
print(f"  EuroSAT tiles with CloudShadow prob > 0.5: {checks['eurosat_shadow_over_0.5']:.4f}   (should be near 0)")
if land_on_clear:
    print("  Mean land-class probability on CloudSEN12 'Clear' tiles (no land labels exist for these):")
    for c, v in land_on_clear.items():
        print(f"    {c:10s} {v:.3f}")
    print("  Judge these by eye: bare land and desert should not look like confident Forest or Water.")

np.savez(os.path.join(models_dir, "cal_probs.npz"), probs=probs, Y=cal["Y"], M=cal["M"],
         source=cal["source"], group=cal["group"])
with open(os.path.join(models_dir, "history.json"), "w") as f:
    json.dump(history, f, indent=1)
print(f"\nSaved: {best_path}")
print(f"Saved: {os.path.join(models_dir, 'cal_probs.npz')}  (for choosing per-class thresholds)")
print(f"Saved: {os.path.join(models_dir, 'history.json')}")
print("The test split was not touched.")
