import json
import os
import time
from bisect import bisect_left
from collections import defaultdict

import dotenv
import numpy as np
import onnx
import onnxruntime as ort
from onnx import numpy_helper

dotenv.load_dotenv()

data_root = os.getenv("DATA_ROOT")
cache_dir = os.path.join(data_root, "cache")
models_dir = os.path.join(data_root, "models")
onnx_path = os.path.join(models_dir, "model_qat_int8.onnx")
report_path = os.path.join(models_dir, "qat_report.json")
opt_path = os.path.join(models_dir, "model_qat_int8_ort_optimized.onnx")

EVAL_MAX_TILES = None     # None = the whole calibration split; set e.g. 20000 for a quicker run
EVAL_BATCH = 256
LATENCY_RUNS = 300
BUDGET_MB = 4.2

CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
EVAL_SOURCE = {"Forest": "eurosat", "Cropland": "eurosat", "Urban": "eurosat", "Water": "eurosat",
               "Cloud": "cloudsen12", "CloudShadow": "cloudsen12", "Ship": "hrsid"}


def prep(xb):
    """uint8 (N, 64, 64, 3) -> float32 (N, 3, 64, 64) in [0, 1]; resize and normalisation are inside the model."""
    return np.ascontiguousarray(xb.transpose(0, 3, 1, 2)).astype(np.float32) / 255.0


def pr_metrics(y, s):
    order = np.argsort(-s, kind="mergesort")
    y = y[order]
    tp = np.cumsum(y)
    prec = tp / np.arange(1, len(y) + 1)
    total = max(float(y.sum()), 1.0)
    rec = tp / total
    ap = float((prec * y).sum() / total)
    f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
    return ap, float(f1.max())


def evaluate(probs, Y, M, source):
    out = {}
    for j, c in enumerate(CLASSES):
        sel = (M[:, j] == 1) & (source == EVAL_SOURCE[c])
        y, s = Y[sel, j], probs[sel, j]
        out[c] = (float("nan"), float("nan")) if (len(y) == 0 or y.sum() == 0 or y.sum() == len(y)) \
            else pr_metrics(y, s)
    return out


# ---------------- Load data ----------------
d = np.load(os.path.join(cache_dir, "cal.npz"))
X, Y, M, source = d["X"], d["Y"], d["M"], d["source"]
if EVAL_MAX_TILES is not None and EVAL_MAX_TILES < len(X):
    idx = np.sort(np.random.RandomState(0).permutation(len(X))[:EVAL_MAX_TILES])
    X, Y, M, source = X[idx], Y[idx], M[idx], source[idx]
print(f"Calibration-split tiles used: {len(X)}")
print(f"Model file: {onnx_path} ({os.path.getsize(onnx_path) / 1e6:.2f} MB)")

# ---------------- 1. Accuracy in ONNX Runtime ----------------
so = ort.SessionOptions()
so.log_severity_level = 3
sess = ort.InferenceSession(onnx_path, so, providers=["CPUExecutionProvider"])
inp_name = sess.get_inputs()[0].name

print("\nRunning the ONNX model on the calibration split...")
t0 = time.time()
logits = []
for i in range(0, len(X), EVAL_BATCH):
    logits.append(sess.run(None, {inp_name: prep(X[i:i + EVAL_BATCH])})[0])
logits = np.concatenate(logits)
probs = 1.0 / (1.0 + np.exp(-logits.astype(np.float64)))
print(f"Done in {time.time() - t0:.0f}s")

onnx_pc = evaluate(probs, Y, M, source)
ref = {}
if os.path.exists(report_path):
    with open(report_path) as f:
        ref = json.load(f)
fp32 = ref.get("per_class_ap_fp32", {})
fq = ref.get("per_class_ap_qat", {})

print("\n" + "=" * 78)
print("Average precision on the calibration split")
print("=" * 78)
print(f"{'class':12s} {'FP32':>8s} {'QAT (fake)':>11s} {'ONNX int8':>10s} {'ONNX vs fake':>13s} {'ONNX F1':>9s}")
aps = []
for c in CLASSES:
    ap, f1 = onnx_pc[c]
    aps.append(ap)
    fq_v = fq.get(c, float("nan"))
    print(f"{c:12s} {fp32.get(c, float('nan')):8.3f} {fq_v:11.3f} {ap:10.3f} {ap - fq_v:+13.3f} {f1:9.3f}")
print(f"{'macro':12s} {np.nanmean(list(fp32.values())) if fp32 else float('nan'):8.3f} "
      f"{np.nanmean(list(fq.values())) if fq else float('nan'):11.3f} {np.nanmean(aps):10.3f}")

# ---------------- 2. Speed (one CPU thread) ----------------
so1 = ort.SessionOptions()
so1.intra_op_num_threads = 1
so1.inter_op_num_threads = 1
so1.log_severity_level = 3
sess1 = ort.InferenceSession(onnx_path, so1, providers=["CPUExecutionProvider"])
x1 = prep(X[:1])
for _ in range(20):
    sess1.run(None, {inp_name: x1})
times = []
for _ in range(LATENCY_RUNS):
    t = time.perf_counter()
    sess1.run(None, {inp_name: x1})
    times.append((time.perf_counter() - t) * 1000.0)
xb = prep(X[:128])
t = time.perf_counter()
for _ in range(10):
    sess1.run(None, {inp_name: xb})
tput = 10 * len(xb) / (time.perf_counter() - t)
print("\n" + "=" * 78)
print("Speed, ONNX Runtime CPU, ONE thread")
print("=" * 78)
print(f"Batch 1 latency: median {np.median(times):.2f} ms, 95th percentile {np.percentile(times, 95):.2f} ms")
print(f"Throughput at batch {len(xb)}: {tput:.0f} tiles/s")

# ---------------- 3. ONNX Runtime's own optimised copy (weights folded to int8) ----------------
try:
    so2 = ort.SessionOptions()
    so2.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_BASIC
    so2.optimized_model_filepath = opt_path
    so2.log_severity_level = 3
    ort.InferenceSession(onnx_path, so2, providers=["CPUExecutionProvider"])
    print(f"\nORT-optimised model saved: {opt_path} ({os.path.getsize(opt_path) / 1e6:.2f} MB)")
except Exception as e:
    print(f"\nCould not save the optimised model: {type(e).__name__}: {e}")


# ---------------- 4. Memory estimate ----------------
def estimate_memory(path, sample):
    model = onnx.load(path)
    g = model.graph
    nodes = list(g.node)
    inits = {t.name: t for t in g.initializer}
    graph_inputs = [i.name for i in g.input if i.name not in inits]

    # constants: initializers, Constant nodes, and anything computed only from constants
    const = set(inits)
    for n in nodes:
        if n.op_type == "Constant" or (len(n.input) > 0 and all((i == "" or i in const) for i in n.input)):
            const.update(n.output)

    # real shapes and dtypes of every intermediate tensor, by running the graph once
    m2 = onnx.load(path)
    existing = {o.name for o in m2.graph.output}
    for n in m2.graph.node:
        for o in n.output:
            if o and o not in existing:
                m2.graph.output.append(onnx.helper.make_empty_tensor_value_info(o))
    so_ = ort.SessionOptions()
    so_.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
    so_.log_severity_level = 3
    s = ort.InferenceSession(m2.SerializeToString(), so_, providers=["CPUExecutionProvider"])
    names = [o.name for o in s.get_outputs()]
    vals = s.run(names, {graph_inputs[0]: sample})
    info = {nm: (int(v.size), v.dtype) for nm, v in zip(names, vals)}
    info[graph_inputs[0]] = (int(sample.size), sample.dtype)

    produced_by = {}
    for i, n in enumerate(nodes):
        for o in n.output:
            produced_by[o] = i

    alias = {}
    for n in nodes:
        if n.op_type == "DequantizeLinear" and n.input[0] not in const:
            alias[n.output[0]] = n.input[0]

    def root(nm):
        while nm in alias:
            nm = alias[nm]
        return nm

    act_q = [i for i, n in enumerate(nodes) if n.op_type == "QuantizeLinear" and n.input[0] not in const]
    users, consumers = defaultdict(list), defaultdict(list)
    for i, n in enumerate(nodes):
        for nm in n.input:
            if nm and nm not in const:
                consumers[nm].append(i)
                users[root(nm)].append(i)

    def size_bytes(nm):
        if nm in alias or nm not in info:
            return 0
        numel, dt = info[nm]
        if nm in graph_inputs:
            return numel                                  # deployed as 8-bit pixels
        if dt in (np.uint8, np.int8):
            return numel
        cons = consumers.get(nm, [])
        if cons and all(nodes[c].op_type == "QuantizeLinear" for c in cons):
            return 0                                      # float result that is requantised right away
        return numel * dt.itemsize

    n_nodes = len(nodes)
    delta = np.zeros(n_nodes + 2, dtype=np.int64)
    spans = []
    for nm in list(info):
        if nm in const:
            continue
        sz = size_bytes(nm)
        if sz == 0:
            continue
        prod = produced_by.get(nm, 0)
        us = users.get(nm, [])
        if info[nm][1] in (np.uint8, np.int8) and nm not in graph_inputs:
            ends = []
            for c in us:
                j = bisect_left(act_q, c)
                ends.append(act_q[j] if j < len(act_q) else c)
            last = max(ends) if ends else prod
        else:
            last = max(us) if us else prod
        last = max(last, prod)
        delta[prod] += sz
        delta[last + 1] -= sz
        spans.append((nm, sz, prod, last))
    live = np.cumsum(delta)[:n_nodes]
    peak_i = int(live.argmax())
    peak = int(live[peak_i])
    top = sorted([sp for sp in spans if sp[2] <= peak_i <= sp[3]], key=lambda sp: -sp[1])[:5]

    qparam_names, q_in_weights = set(), set()
    for n in nodes:
        if n.op_type in ("QuantizeLinear", "DequantizeLinear"):
            qparam_names.update(x for x in n.input[1:] if x)
            if n.op_type == "QuantizeLinear" and n.input[0] in inits:
                q_in_weights.add(n.input[0])
    w_int8 = w_other = w_qparams = 0
    for name, t in inits.items():
        arr = numpy_helper.to_array(t)
        if name in qparam_names:
            w_qparams += arr.nbytes
        elif name in q_in_weights:
            w_int8 += arr.size
        else:
            w_other += arr.nbytes
    return {"peak": peak, "peak_op": nodes[peak_i].op_type, "peak_index": peak_i, "top": top,
            "w_int8": w_int8, "w_other": w_other, "w_qparams": w_qparams}


print("\n" + "=" * 78)
print("Memory estimate (assumes an integer-only runtime; ONNX Runtime itself allocates differently)")
print("=" * 78)
try:
    r = estimate_memory(onnx_path, prep(X[:1]))
    weights = r["w_int8"] + r["w_other"] + r["w_qparams"]
    print(f"Weights: int8 {r['w_int8'] / 1e6:.3f} MB + biases/other float {r['w_other'] / 1e6:.3f} MB "
          f"+ quantization scales {r['w_qparams'] / 1e6:.3f} MB = {weights / 1e6:.3f} MB")
    print(f"Peak activations: {r['peak'] / 1e6:.3f} MB (around node {r['peak_index']}, a {r['peak_op']})")
    print("  largest tensors alive at the peak:")
    for nm, sz, prod, last in r["top"]:
        print(f"    {sz / 1e3:8.1f} KB  {nm}")
    print(f"Weights + peak activations: {(weights + r['peak']) / 1e6:.3f} MB   (budget {BUDGET_MB} MB)")
    print(f"Peak activations alone:     {r['peak'] / 1e6:.3f} MB")
except Exception as e:
    print(f"Memory estimate failed: {type(e).__name__}: {e}")
print("\nDone.")
