import os
import types

import dotenv
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import mobilenet_v3_small

import torch.ao.quantization as taq
from torch.ao.quantization import QConfig, QConfigMapping, get_default_qat_qconfig_mapping
from torch.ao.quantization.fake_quantize import FusedMovingAvgObsFakeQuantize
from torch.ao.quantization.quantize_fx import prepare_qat_fx, convert_to_reference_fx

dotenv.load_dotenv()

data_root = os.getenv("DATA_ROOT")
models_dir = os.path.join(data_root, "models")
best_fp32_path = os.path.join(models_dir, "best_fp32.pt")
qat_state_path = os.path.join(models_dir, "qat_best_state.pt")
qat_onnx_path = os.path.join(models_dir, "model_qat_int8.onnx")
ONNX_OPSET = 13
NUM_CLASSES = 7


class Net(nn.Module):
    def __init__(self, num_classes, input_size):
        super().__init__()
        backbone = mobilenet_v3_small(weights=None)
        self.input_size = input_size
        self.features = backbone.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.drop = nn.Dropout(0.2)
        self.fc = nn.Linear(576, num_classes)
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, x):
        x = F.interpolate(x, size=(self.input_size, self.input_size), mode="bilinear", align_corners=False)
        x = (x - self.mean) / self.std
        x = self.pool(self.features(x)).flatten(1)
        return self.fc(self.drop(x))


def custom_qconfig_mapping():
    from torch.ao.quantization.fake_quantize import default_fused_per_channel_wt_fake_quant
    from torch.ao.quantization.observer import MovingAverageMinMaxObserver
    act = FusedMovingAvgObsFakeQuantize.with_args(
        observer=MovingAverageMinMaxObserver, quant_min=0, quant_max=255,
        dtype=torch.quint8, reduce_range=False)
    return QConfigMapping().set_global(QConfig(activation=act, weight=default_fused_per_channel_wt_fake_quant))


# ---------------- Rebuild the QAT model and load the saved weights (CPU only) ----------------
INPUT_SIZE = int(torch.load(best_fp32_path, map_location="cpu").get("input_size", 96))
saved = torch.load(qat_state_path, map_location="cpu")
kind = saved["qconfig"]
print(f"Saved QAT state: qconfig '{kind}', epoch {saved['epoch']}, macro AP {saved['macro_ap']:.4f}, "
      f"input {INPUT_SIZE}x{INPUT_SIZE}")

mapping = custom_qconfig_mapping() if kind == "custom" else get_default_qat_qconfig_mapping("x86")
model = Net(NUM_CLASSES, INPUT_SIZE)
model.train()
qat_model = prepare_qat_fx(model, mapping, (torch.rand(1, 3, 64, 64),))
qat_model.load_state_dict(saved["state_dict"])
qat_model.eval()
qat_model.apply(taq.disable_observer)

# ---------------- Convert to a reference quantized model ----------------
print("Converting to a reference quantized model...")
ref_model = convert_to_reference_fx(qat_model)
ref_model.eval()

# The reference layers put non-tensor values (weight_qscheme, weight_dtype) into their state dict,
# which breaks the ONNX exporter. Make them save only their tensors.
patched = 0
for mod in ref_model.modules():
    if hasattr(mod, "weight_qscheme"):
        mod._save_to_state_dict = types.MethodType(nn.Module._save_to_state_dict, mod)
        patched += 1
non_tensor = [k for k, v in ref_model.state_dict().items() if not torch.is_tensor(v)]
print(f"Patched {patched} reference layers. Non-tensor state dict entries left: {len(non_tensor)}")
if non_tensor:
    print("  first few:", non_tensor[:5])
    raise RuntimeError("Non-tensor entries remain in the state dict; the export would fail. Send me this output.")

with torch.no_grad():
    out = ref_model(torch.rand(2, 3, 64, 64))
print(f"Reference model runs on CPU, output shape {tuple(out.shape)}")

# ---------------- Export ----------------
print("Exporting INT8 QDQ model to ONNX...")
try:
    torch.onnx.export(
        ref_model,
        torch.rand(1, 3, 64, 64),
        qat_onnx_path,
        opset_version=ONNX_OPSET,
        input_names=["input"],
        output_names=["output"],
        dynamic_axes={"input": {0: "batch"}, "output": {0: "batch"}},
        dynamo=False,
    )
except Exception as e:
    print(f"ONNX export failed: {type(e).__name__}: {e}")
    raise
print(f"Saved: {qat_onnx_path} ({os.path.getsize(qat_onnx_path) / 1e6:.2f} MB)")
print("Next: run check_onnx_ort.py in the Python 3.12 venv.")
