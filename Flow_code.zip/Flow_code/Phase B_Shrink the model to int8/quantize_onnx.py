import os
import shutil
import time

import dotenv
import numpy as np
import onnx
import onnxruntime as ort
import torch
import torch.nn as nn
import torch.nn.functional as F
from onnx import TensorProto, shape_inference
from onnxruntime.quantization import (CalibrationDataReader, CalibrationMethod, QuantFormat, QuantType,
                                      quantize_static)
from torchvision.models import mobilenet_v3_small

dotenv.load_dotenv()

# ---------------- Paths ----------------
data_root = os.getenv("DATA_ROOT")
cache_dir = os.path.join(data_root, "cache")
models_dir = os.path.join(data_root, "models")
ckpt_path = os.path.join(models_dir, "best_fp32.pt")
fp32_path = os.path.join(models_dir, "model_fp32.onnx")
pre_path = os.path.join(models_dir, "model_fp32_prep.onnx")
int8_final = os.path.join(models_dir, "model_int8.onnx")
# ---------------- Settings ----------------
SEED = 0
CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
EVAL_SOURCE = {"Forest": "eurosat", "Cropland": "eurosat", "Urban": "eurosat", "Water": "eurosat",
               "Cloud": "cloudsen12", "CloudShadow": "cloudsen12", "Ship": "hrsid"}
CALIB_PER_GROUP = 40                     # calibration tiles per group (10 groups -> about 400 tiles)
CALIB_METHODS = ["MinMax", "Percentile"] # tried in turn; the better one becomes model_int8.onnx
EVAL_MAX_TILES = 25000                   # random subset of the cal split used for the comparison (None = all)
LATENCY_TILES = 300
SRAM_LIMIT_BYTES = 4.2 * 1000 * 1000     # the 4.2 MB on-board limit from the problem statement

rng = np.random.default_rng(SEED)
torch.set_num_threads(1)


# ---------------- Model (same as train_baseline.py) ----------------
class Net(nn.Module):
    def __init__(self, num_classes, input_size):
        super().__init__()
        backbone = mobilenet_v3_small(weights=None)
        self.input_size = input_size
        self.features = backbone.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.drop = nn.Dropout(0.2)
        self.fc = nn.Linear(576, num_classes)
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, x):
        if self.input_size != x.shape[-1]:
            x = F.interpolate(x, size=(self.input_size, self.input_size), mode="bilinear", align_corners=False)
        x = (x - self.mean) / self.std
        x = self.pool(self.features(x)).flatten(1)
        return self.fc(self.drop(x))


# ---------------- 1. Export to ONNX ----------------
print("1. Exporting the float32 model to ONNX...")
ckpt = torch.load(ckpt_path, map_location="cpu")
model = Net(len(CLASSES), ckpt["input_size"])
model.load_state_dict(ckpt["state_dict"])
model.eval()
dummy = torch.zeros(1, 3, 64, 64)
export_kwargs = dict(input_names=["input"], output_names=["logits"], opset_version=17,
                     dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}})
try:
    torch.onnx.export(model, dummy, fp32_path, dynamo=False, **export_kwargs)
except TypeError:
    torch.onnx.export(model, dummy, fp32_path, **export_kwargs)
onnx.checker.check_model(onnx.load(fp32_path))
print(f"   saved {fp32_path}  ({os.path.getsize(fp32_path) / 1e6:.2f} MB)")

# ---------------- 2. Data ----------------
print("2. Loading calibration split...")
cal = np.load(os.path.join(cache_dir, "cal.npz"))
X, Y, M = cal["X"], cal["Y"], cal["M"]
group, source = cal["group"], cal["source"]
saved_probs = np.load(os.path.join(models_dir, "cal_probs.npz"))["probs"]

if EVAL_MAX_TILES is not None and EVAL_MAX_TILES < len(X):
    eval_idx = np.sort(rng.choice(len(X), EVAL_MAX_TILES, replace=False))
else:
    eval_idx = np.arange(len(X))
print(f"   evaluating on {len(eval_idx)} of {len(X)} cal tiles")

# calibration tiles: a few from every group, so every class is represented
calib_idx = []
for g in np.unique(group):
    members = np.where(group == g)[0]
    calib_idx.extend(rng.choice(members, min(CALIB_PER_GROUP, len(members)), replace=False).tolist())
print(f"   calibration tiles for int8: {len(calib_idx)}")


def to_input(tiles_uint8):
    return (tiles_uint8.astype(np.float32) / 255.0).transpose(0, 3, 1, 2)


class Reader(CalibrationDataReader):
    def __init__(self, idx):
        self.idx = list(idx)
        self.i = 0

    def get_next(self):
        if self.i >= len(self.idx):
            return None
        x = to_input(X[self.idx[self.i]][None])
        self.i += 1
        return {"input": x}

    def rewind(self):
        self.i = 0


def make_session(path, threads=0):
    so = ort.SessionOptions()
    if threads:
        so.intra_op_num_threads = threads
    return ort.InferenceSession(path, so, providers=["CPUExecutionProvider"])


def run_model(path, idx, bs=256):
    sess = make_session(path)
    out = []
    for i in range(0, len(idx), bs):
        logits = sess.run(None, {"input": to_input(X[idx[i:i + bs]])})[0]
        out.append(1.0 / (1.0 + np.exp(-logits)))
    return np.concatenate(out)


def average_precision(y, s):
    order = np.argsort(-s, kind="mergesort")
    y = y[order]
    tp = np.cumsum(y)
    prec = tp / np.arange(1, len(y) + 1)
    total = max(float(y.sum()), 1.0)
    return float((prec * y).sum() / total)


def class_aps(probs, idx):
    out = {}
    for j, c in enumerate(CLASSES):
        sel = (M[idx, j] == 1) & (source[idx] == EVAL_SOURCE[c])
        y, s = Y[idx][sel, j], probs[sel, j]
        out[c] = average_precision(y, s) if 0 < y.sum() < len(y) else float("nan")
    return out


# ---------------- 3. Check the export matches PyTorch ----------------
print("3. Checking the ONNX model reproduces the PyTorch predictions...")
check_idx = np.arange(500)
p_onnx = run_model(fp32_path, check_idx)
print(f"   max difference on 500 tiles: {np.abs(p_onnx - saved_probs[:500]).max():.4f} (should be below about 0.01)")

# ---------------- 4. Quantize ----------------
print("4. Quantizing to int8 (static, per-channel, QDQ format)...")
src_model = fp32_path
try:
    from onnxruntime.quantization.shape_inference import quant_pre_process
    quant_pre_process(fp32_path, pre_path)
    src_model = pre_path
    print("   pre-processing step done")
except Exception as e:
    print(f"   pre-processing skipped ({type(e).__name__}); quantizing the exported model directly")

int8_paths = {}
for name in CALIB_METHODS:
    method = getattr(CalibrationMethod, name, None)
    if method is None:
        print(f"   calibration method {name} not available in this onnxruntime version, skipping")
        continue
    out_path = os.path.join(models_dir, f"model_int8_{name}.onnx")
    try:
        t0 = time.time()
        quantize_static(src_model, out_path, Reader(calib_idx), quant_format=QuantFormat.QDQ,
                        per_channel=True, weight_type=QuantType.QInt8, activation_type=QuantType.QUInt8,
                        calibrate_method=method,
                        extra_options={"ActivationSymmetric": False, "WeightSymmetric": True})
        int8_paths[name] = out_path
        print(f"   {name}: done in {time.time() - t0:.0f}s, file {os.path.getsize(out_path) / 1e6:.2f} MB")
    except Exception as e:
        print(f"   {name}: FAILED ({type(e).__name__}: {e})")
if not int8_paths:
    raise SystemExit("No int8 model could be produced. Paste the messages above.")

# ---------------- 5. Accuracy comparison ----------------
print("\n5. Accuracy on the calibration split (average precision per class)")
p_fp32 = run_model(fp32_path, eval_idx)
aps = {"float32": class_aps(p_fp32, eval_idx)}
for name, path in int8_paths.items():
    aps[f"int8 {name}"] = class_aps(run_model(path, eval_idx), eval_idx)
cols = list(aps)
print(f"{'class':12s}" + "".join(f"{c:>18s}" for c in cols))
for c in CLASSES:
    print(f"{c:12s}" + "".join(f"{aps[k][c]:18.3f}" for k in cols))
macro = {k: float(np.nanmean(list(aps[k].values()))) for k in cols}
print(f"{'macro AP':12s}" + "".join(f"{macro[k]:18.4f}" for k in cols))
best_int8 = max((k for k in cols if k != "float32"), key=lambda k: macro[k])
best_name = best_int8.replace("int8 ", "")
shutil.copy(int8_paths[best_name], int8_final)
print(f"\nBest int8 variant: {best_name} (macro AP drop vs float32: {macro['float32'] - macro[best_int8]:+.4f})")
print(f"Copied to {int8_final}")

# ---------------- 6. Latency ----------------
print("\n6. CPU latency, one tile at a time, one thread (this laptop, indicative only)")
lat_idx = eval_idx[:LATENCY_TILES]
for label, path in (("float32", fp32_path), ("int8", int8_final)):
    sess = make_session(path, threads=1)
    inputs = [to_input(X[i][None]) for i in lat_idx]
    for x in inputs[:30]:
        sess.run(None, {"input": x})
    t0 = time.time()
    for x in inputs:
        sess.run(None, {"input": x})
    print(f"   {label:8s} {1000 * (time.time() - t0) / len(inputs):.2f} ms per tile")


# ---------------- 7. Peak activation memory estimate ----------------
def peak_activation_bytes(path, bytes_per_elem):
    """Largest total size of tensors that must be alive at the same moment while the graph runs
    (batch of 1). Weights are not counted: they sit in flash, not in SRAM."""
    m = shape_inference.infer_shapes(onnx.load(path))
    g = m.graph
    inits = {i.name for i in g.initializer}
    sizes = {}
    for vi in list(g.value_info) + list(g.input) + list(g.output):
        if vi.name in inits or not vi.type.HasField("tensor_type"):
            continue
        n = 1
        for d in vi.type.tensor_type.shape.dim:
            n *= d.dim_value if (d.HasField("dim_value") and d.dim_value > 0) else 1
        sizes[vi.name] = n * (bytes_per_elem if bytes_per_elem else 4)
    nodes = list(g.node)
    produced = {inp.name: -1 for inp in g.input if inp.name not in inits}
    last_use = {}
    for i, n in enumerate(nodes):
        for t in n.input:
            if t in produced or t in sizes:
                last_use[t] = i
        for t in n.output:
            produced[t] = i
    for o in g.output:
        last_use[o.name] = len(nodes)
    unknown = {t for t in produced if t not in sizes}
    peak, peak_node = 0, ""
    for i, n in enumerate(nodes):
        total = sum(sizes[t] for t, p in produced.items()
                    if t in sizes and p <= i <= last_use.get(t, p))
        if total > peak:
            peak, peak_node = total, f"{n.op_type} ({n.name})"
    return peak, peak_node, len(unknown)


print("\n7. Peak activation memory estimate (batch of 1, weights excluded)")
for label, bpe in (("float32 activations (4 bytes each)", 4), ("int8 activations (1 byte each)", 1)):
    peak, node, unknown = peak_activation_bytes(fp32_path, bpe)
    print(f"   {label:36s} peak {peak / 1000:8.1f} KB  = {100 * peak / SRAM_LIMIT_BYTES:5.1f} % of 4.2 MB"
          f"   (at {node})" + (f"   [{unknown} tensors had unknown shape]" if unknown else ""))
print("   The int8 line assumes every activation is stored as one byte, which a deployment runtime would do after\n"
      "   converting HardSwish/HardSigmoid. It ignores runtime scratch buffers, so treat it as a lower bound.")
n_params_bytes = os.path.getsize(int8_final)
print(f"   Weights (flash): int8 model file is {n_params_bytes / 1e6:.2f} MB, float32 is {os.path.getsize(fp32_path) / 1e6:.2f} MB")

print("\nDone. Files in", models_dir)
