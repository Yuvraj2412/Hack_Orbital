import copy
import json
import os
import time

import dotenv
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import mobilenet_v3_small

import torch.ao.quantization as taq
from torch.ao.quantization import QConfig, QConfigMapping, get_default_qat_qconfig_mapping
from torch.ao.quantization.fake_quantize import FusedMovingAvgObsFakeQuantize
from torch.ao.quantization.quantize_fx import prepare_qat_fx, convert_to_reference_fx

try:
    import torch.ao.nn.intrinsic.qat as nniqat
    FREEZE_BN = getattr(nniqat, "freeze_bn_stats", None)
except Exception:
    FREEZE_BN = None

dotenv.load_dotenv()

# ---------------- Paths ----------------
data_root = os.getenv("DATA_ROOT")
cache_dir = os.path.join(data_root, "cache")
models_dir = os.path.join(data_root, "models")
os.makedirs(models_dir, exist_ok=True)
best_fp32_path = os.path.join(models_dir, "best_fp32.pt")
qat_state_path = os.path.join(models_dir, "qat_best_state.pt")
qat_onnx_path = os.path.join(models_dir, "model_qat_int8.onnx")
qat_report_path = os.path.join(models_dir, "qat_report.json")
# ---------------- Settings ----------------
SEED = 0
BATCH = 128
EPOCHS = 8
LR = 2e-4                    # starting guess; cosine decay to ~0 over all steps
WEIGHT_DECAY = 1e-5
BALANCE_POWER = 0.5          # 0.5 = same sampling as train_baseline.py (weight 1/sqrt(group size))
CALIB_BATCHES = 200          # batches used to set the quantization ranges before QAT
FREEZE_OBSERVER_EPOCH = 5    # ranges keep updating in epochs 1-4, frozen from epoch 5
FREEZE_BN_EPOCH = 0          # 0 = never freeze BatchNorm statistics
ONNX_OPSET = 13
EXPORT_ONLY = False          # True = skip training, load the saved QAT weights, only convert + export

BRIGHT_JITTER = 0.15
CONTRAST_JITTER = 0.15

CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
EVAL_SOURCE = {"Forest": "eurosat", "Cropland": "eurosat", "Urban": "eurosat", "Water": "eurosat",
               "Cloud": "cloudsen12", "CloudShadow": "cloudsen12", "Ship": "hrsid"}
NUM_CLASSES = len(CLASSES)

torch.manual_seed(SEED)
np.random.seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Running QAT on: {device}")


# ---------------- Data (train + calibration only; the test split is not touched) ----------------
def load_split(name):
    d = np.load(os.path.join(cache_dir, f"{name}.npz"))
    return {k: d[k] for k in ["X", "Y", "M", "group", "source"]}


train = load_split("train")
cal = load_split("cal")
Xtr = torch.from_numpy(train["X"]).to(device)
Ytr = torch.from_numpy(train["Y"]).to(device)
Mtr = torch.from_numpy(train["M"]).to(device)
Xca = torch.from_numpy(cal["X"]).to(device)
steps_per_epoch = len(Xtr) // BATCH
print(f"Train tiles: {len(Xtr)} | Calibration-split tiles: {len(Xca)} | steps per epoch: {steps_per_epoch}")

groups, counts = np.unique(train["group"], return_counts=True)
count_of = dict(zip(groups.tolist(), counts.tolist()))
w = np.array([(1.0 / count_of[g]) ** BALANCE_POWER for g in train["group"].tolist()], dtype=np.float64)
sample_w = torch.tensor(w / w.sum(), dtype=torch.float32, device=device)
total_share = sum(count_of[g] * (1.0 / count_of[g]) ** BALANCE_POWER for g in count_of)
print("Sampling share per group:")
for g in sorted(count_of):
    share = count_of[g] * (1.0 / count_of[g]) ** BALANCE_POWER / total_share
    print(f"  {g:12s} tiles {count_of[g]:6d}  share of each batch {100 * share:5.1f}%")


def augment(x):
    """x: float (B, 3, H, W) in [0, 1]. Same augmentation as train_baseline.py."""
    b = x.shape[0]
    hflip = torch.rand(b, device=x.device) < 0.5
    vflip = torch.rand(b, device=x.device) < 0.5
    x = torch.where(hflip.view(-1, 1, 1, 1), x.flip(3), x)
    x = torch.where(vflip.view(-1, 1, 1, 1), x.flip(2), x)
    k = int(torch.randint(0, 4, (1,)).item())
    if k:
        x = torch.rot90(x, k, dims=(2, 3))
    bright = 1.0 + (torch.rand(b, 1, 1, 1, device=x.device) * 2 - 1) * BRIGHT_JITTER
    contrast = 1.0 + (torch.rand(b, 1, 1, 1, device=x.device) * 2 - 1) * CONTRAST_JITTER
    mean = x.mean(dim=(1, 2, 3), keepdim=True)
    x = ((x - mean) * contrast + mean) * bright
    return x.clamp(0.0, 1.0)


# ---------------- Model (same layers and buffers as train_baseline.py) ----------------
class Net(nn.Module):
    """Input: float tiles in [0, 1], shape (B, 3, 64, 64). Resize and normalisation are inside the model.
    The resize is unconditional because FX tracing cannot handle an 'if' on the tensor shape."""

    def __init__(self, num_classes, input_size):
        super().__init__()
        backbone = mobilenet_v3_small(weights=None)
        self.input_size = input_size
        self.features = backbone.features
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.drop = nn.Dropout(0.2)
        self.fc = nn.Linear(576, num_classes)
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, x):
        x = F.interpolate(x, size=(self.input_size, self.input_size), mode="bilinear", align_corners=False)
        x = (x - self.mean) / self.std
        x = self.pool(self.features(x)).flatten(1)
        return self.fc(self.drop(x))


ckpt = torch.load(best_fp32_path, map_location=device)
INPUT_SIZE = int(ckpt.get("input_size", 96))
model = Net(NUM_CLASSES, INPUT_SIZE).to(device)
model.load_state_dict(ckpt["state_dict"])      # strict: raises an error if anything does not match
model.eval()
print(f"Loaded FP32 model (epoch {ckpt.get('epoch')}, input {INPUT_SIZE}x{INPUT_SIZE}), all keys matched.")


# ---------------- Metrics (same as train_baseline.py, calibration split) ----------------
def pr_metrics(y, s):
    order = np.argsort(-s, kind="mergesort")
    y = y[order]
    tp = np.cumsum(y)
    prec = tp / np.arange(1, len(y) + 1)
    total = max(float(y.sum()), 1.0)
    rec = tp / total
    ap = float((prec * y).sum() / total)
    f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-12)
    return ap, float(f1.max())


@torch.no_grad()
def predict(net, X, bs=1024):
    net.eval()
    out = []
    for i in range(0, len(X), bs):
        xb = X[i:i + bs].permute(0, 3, 1, 2).float() / 255.0
        out.append(torch.sigmoid(net(xb).float()).cpu())
    return torch.cat(out).numpy()


def evaluate(probs, split):
    Y, M, source = split["Y"], split["M"], split["source"]
    per_class = {}
    for j, c in enumerate(CLASSES):
        sel = (M[:, j] == 1) & (source == EVAL_SOURCE[c])
        y, s = Y[sel, j], probs[sel, j]
        if len(y) == 0 or y.sum() == 0 or y.sum() == len(y):
            per_class[c] = (float("nan"), float("nan"))
        else:
            per_class[c] = pr_metrics(y, s)
    macro_ap = float(np.nanmean([v[0] for v in per_class.values()]))
    return per_class, macro_ap


def print_table(ref_pc, new_pc, ref_name, new_name):
    print(f"{'class':12s} {ref_name + ' AP':>10s} {new_name + ' AP':>10s} {'change':>8s} "
          f"{ref_name + ' F1':>10s} {new_name + ' F1':>10s}")
    for c in CLASSES:
        ra, rf = ref_pc[c]
        na, nf = new_pc[c]
        print(f"{c:12s} {ra:10.3f} {na:10.3f} {na - ra:+8.3f} {rf:10.3f} {nf:10.3f}")


print("\nEvaluating the FP32 model on the calibration split...")
fp32_pc, fp32_macro = evaluate(predict(model, Xca), cal)
print(f"FP32 macro AP: {fp32_macro:.4f}")


# ---------------- QAT model construction ----------------
example_inputs = (torch.rand(1, 3, 64, 64).to(device),)


def custom_qconfig_mapping():
    """uint8 activations (per tensor, full range) and int8 weights with ONE SCALE PER CHANNEL."""
    from torch.ao.quantization.fake_quantize import default_fused_per_channel_wt_fake_quant
    from torch.ao.quantization.observer import MovingAverageMinMaxObserver
    act = FusedMovingAvgObsFakeQuantize.with_args(
        observer=MovingAverageMinMaxObserver, quant_min=0, quant_max=255,
        dtype=torch.quint8, reduce_range=False)
    return QConfigMapping().set_global(QConfig(activation=act, weight=default_fused_per_channel_wt_fake_quant))


def build_qat_model(kind):
    mapping = custom_qconfig_mapping() if kind == "custom" else get_default_qat_qconfig_mapping("x86")
    m = copy.deepcopy(model)
    m.train()
    return prepare_qat_fx(m, mapping, example_inputs)


def set_observers(m, enabled):
    m.apply(taq.enable_observer if enabled else taq.disable_observer)


def set_fake_quant(m, enabled):
    m.apply(taq.enable_fake_quant if enabled else taq.disable_fake_quant)


def masked_bce(logits, y, m):
    loss = F.binary_cross_entropy_with_logits(logits, y, reduction="none") * m
    n = m.sum(0)
    per_class = loss.sum(0) / n.clamp(min=1.0)
    return per_class[n > 0].mean()


if EXPORT_ONLY:
    saved = torch.load(qat_state_path, map_location=device)
    qconfig_kind = saved["qconfig"]
    qat_model = build_qat_model(qconfig_kind)
    qat_model.load_state_dict(saved["state_dict"])
    print(f"EXPORT_ONLY: loaded saved QAT weights (qconfig '{qconfig_kind}', epoch {saved['epoch']}, "
          f"macro AP {saved['macro_ap']:.4f}).")
else:
    print("\nTracing model and inserting FakeQuantize nodes...")
    try:
        qconfig_kind = "custom"
        qat_model = build_qat_model("custom")
        print("QAT config: uint8 activations, int8 per-channel weights (custom).")
    except Exception as e:
        print(f"Custom config failed ({type(e).__name__}: {e}). Falling back to the 'x86' default.")
        qconfig_kind = "x86"
        qat_model = build_qat_model("x86")

    # ---- Step 1: calibrate the activation ranges (fake-quant OFF, observers ON) ----
    print(f"Calibrating activation ranges on {CALIB_BATCHES} batches...")
    qat_model.eval()
    set_observers(qat_model, True)
    set_fake_quant(qat_model, False)
    with torch.no_grad():
        for _ in range(CALIB_BATCHES):
            idx = torch.multinomial(sample_w, BATCH, replacement=True)
            xb = Xtr[idx].permute(0, 3, 1, 2).float() / 255.0
            qat_model(xb)
    set_fake_quant(qat_model, True)
    set_observers(qat_model, False)

    # ---- Step 2: accuracy right after calibration, before any QAT (about the same as per-channel PTQ) ----
    cal_pc, cal_macro = evaluate(predict(qat_model, Xca), cal)
    print(f"\nAfter calibration, BEFORE QAT training: macro AP {cal_macro:.4f} (FP32: {fp32_macro:.4f})")
    print_table(fp32_pc, cal_pc, "FP32", "Calib")

    best_macro, best_epoch = cal_macro, 0
    best_state = copy.deepcopy(qat_model.state_dict())
    history = [{"epoch": 0, "loss": None, "macro_ap": cal_macro}]

    # ---- Step 3: QAT fine-tuning ----
    optimizer = torch.optim.AdamW(qat_model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS * steps_per_epoch, eta_min=1e-6)
    bn_frozen = False

    print(f"\nStarting QAT for {EPOCHS} epochs (macro AP is measured on the calibration split)...")
    for epoch in range(1, EPOCHS + 1):
        observers_on = epoch < FREEZE_OBSERVER_EPOCH
        set_observers(qat_model, observers_on)
        if FREEZE_BN_EPOCH and epoch >= FREEZE_BN_EPOCH and FREEZE_BN is not None and not bn_frozen:
            qat_model.apply(FREEZE_BN)
            bn_frozen = True
            print("  -> BatchNorm statistics frozen")
        if epoch == FREEZE_OBSERVER_EPOCH:
            print("  -> quantization ranges frozen")

        t0 = time.time()
        qat_model.train()
        running = 0.0
        for s in range(steps_per_epoch):
            idx = torch.multinomial(sample_w, BATCH, replacement=True)
            xb = augment(Xtr[idx].permute(0, 3, 1, 2).float() / 255.0)
            yb, mb = Ytr[idx], Mtr[idx]

            logits = qat_model(xb)
            loss = masked_bce(logits, yb, mb)

            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            scheduler.step()
            running += float(loss.item())

        set_observers(qat_model, False)          # evaluation must not move the ranges
        pc, macro = evaluate(predict(qat_model, Xca), cal)
        history.append({"epoch": epoch, "loss": running / steps_per_epoch, "macro_ap": macro})
        ap_str = "  ".join(f"{c[:6]}={pc[c][0]:.3f}" for c in CLASSES)
        print(f"QAT epoch {epoch}/{EPOCHS} | loss {running / steps_per_epoch:.4f} | macro AP {macro:.4f} "
              f"| {time.time() - t0:.0f}s")
        print(f"    AP: {ap_str}")

        if macro > best_macro:
            best_macro, best_epoch = macro, epoch
            best_state = copy.deepcopy(qat_model.state_dict())
            print("    new best")

    qat_model.load_state_dict(best_state)
    qat_model.eval()
    set_observers(qat_model, False)
    best_pc, best_macro_check = evaluate(predict(qat_model, Xca), cal)

    print("\n" + "=" * 70)
    print(f"Best QAT state: epoch {best_epoch} (0 = the calibrated start), macro AP {best_macro_check:.4f}, "
          f"FP32 {fp32_macro:.4f}")
    print("=" * 70)
    print_table(fp32_pc, best_pc, "FP32", "QAT")

    torch.save({"state_dict": best_state, "qconfig": qconfig_kind, "epoch": best_epoch,
                "macro_ap": best_macro_check}, qat_state_path)
    with open(qat_report_path, "w") as f:
        json.dump({"fp32_macro_ap": fp32_macro, "calibrated_macro_ap": cal_macro,
                   "best_epoch": best_epoch, "best_macro_ap": best_macro_check,
                   "per_class_ap_fp32": {c: fp32_pc[c][0] for c in CLASSES},
                   "per_class_ap_qat": {c: best_pc[c][0] for c in CLASSES},
                   "history": history}, f, indent=1)
    print(f"\nSaved best QAT weights to: {qat_state_path}")
    print(f"Saved report to: {qat_report_path}")

# ---------------- Convert to a reference quantized model, then export ----------------
print("\nConverting to a reference quantized model (Quantize/Dequantize ops)...")
qat_model.eval()
set_observers(qat_model, False)
qat_cpu = copy.deepcopy(qat_model).cpu().eval()
ref_model = convert_to_reference_fx(copy.deepcopy(qat_cpu))
ref_model.eval()

print("Exporting INT8 QDQ model to ONNX...")
dummy_input = torch.rand(1, 3, 64, 64)
try:
    torch.onnx.export(
        ref_model,
        dummy_input,
        qat_onnx_path,
        opset_version=ONNX_OPSET,
        input_names=["input"],
        output_names=["output"],
        dynamic_axes={"input": {0: "batch"}, "output": {0: "batch"}},
        dynamo=False,
    )
except Exception as e:
    print(f"ONNX export failed: {type(e).__name__}: {e}")
    print(f"The QAT weights are safe in {qat_state_path}. Send me this error.")
    raise
print(f"Saved ONNX model to: {qat_onnx_path} ({os.path.getsize(qat_onnx_path) / 1e6:.2f} MB)")

# Sanity check: the converted model should behave like the fake-quantized one
try:
    with torch.no_grad():
        xb = Xca[:64].permute(0, 3, 1, 2).float().div(255.0).cpu()
        p_qat = torch.sigmoid(qat_cpu(xb))
        p_ref = torch.sigmoid(ref_model(xb))
    diff = (p_qat - p_ref).abs()
    agree = ((p_qat >= 0.5) == (p_ref >= 0.5)).float().mean().item()
    print(f"Converted vs fake-quant (64 tiles): mean |prob diff| = {diff.mean():.4f}, "
          f"max = {diff.max():.4f}, decision agreement = {100 * agree:.1f}%")
except Exception as e:
    print(f"Sanity check skipped: {type(e).__name__}: {e}")
print("Done.")
