import os
from collections import Counter, defaultdict

import dotenv
import numpy as np
import onnx
import onnxruntime as ort
from onnx import helper, numpy_helper

dotenv.load_dotenv()

# ---------------- Paths ----------------
data_root = os.getenv("DATA_ROOT")
SRC = os.path.join(data_root, "models", "model_qat_int8.onnx")
DST = os.path.join(data_root, "models", "model_qat_int8_packed.onnx")

# ---------------- Graph Loading & Mapping ----------------
model = onnx.load(SRC)
g = model.graph
inits = {i.name: i for i in g.initializer}
producers = {o: n for n in g.node for o in n.output}
consumers = defaultdict(list)

for n in g.node:
    for i in n.input:
        consumers[i].append(n)

def resolve(name):
    """Return a numpy array if `name` is a constant (initializer / Constant / Cast / Identity of one)."""
    if name in inits:
        return numpy_helper.to_array(inits[name])
    n = producers.get(name)
    if n is None:
        return None
    if n.op_type == "Identity":
        return resolve(n.input[0])
    if n.op_type == "Constant":
        for a in n.attribute:
            if a.name == "value":
                return numpy_helper.to_array(a.t)
        return None
    if n.op_type == "Cast":
        v = resolve(n.input[0])
        if v is None:
            return None
        to = next(a.i for a in n.attribute if a.name == "to")
        return v.astype(helper.tensor_dtype_to_np_dtype(to))
    return None

# ---------------- Node Folding ----------------
remove_nodes, new_inits, folded = set(), [], 0
for n in g.node:
    if n.op_type != "QuantizeLinear":
        continue
        
    x, scale, zp = resolve(n.input[0]), resolve(n.input[1]), resolve(n.input[2])
    
    if x is None or scale is None or zp is None or x.dtype != np.float32:
        continue                                   # activation fake-quant, leave alone
    if zp.dtype not in (np.int8, np.uint8):
        continue
        
    users = consumers[n.output[0]]
    if not users or any(u.op_type != "DequantizeLinear" for u in users):
        continue

    axis = next((a.i for a in n.attribute if a.name == "axis"), 1)
    
    if scale.ndim == 1:                            # per-channel: broadcast along `axis`
        shape = [1] * x.ndim
        shape[axis] = -1
        s, z = scale.reshape(shape), zp.reshape(shape)
    else:
        s, z = scale, zp
        
    info = np.iinfo(zp.dtype)
    q = np.clip(np.rint(x / s) + z.astype(np.float32), info.min, info.max).astype(zp.dtype)

    base = n.input[0]
    q_name, s_name, z_name = base + "_int8", base + "_qscale", base + "_qzp"
    
    new_inits += [
        numpy_helper.from_array(q, q_name),
        numpy_helper.from_array(scale.astype(np.float32), s_name),
        numpy_helper.from_array(zp, z_name),
    ]
    
    for u in users:
        u.input[0], u.input[1], u.input[2] = q_name, s_name, z_name
    remove_nodes.add(id(n))
    folded += 1

print(f"Folded {folded} weight QuantizeLinear nodes into int8 initializers")
if folded == 0:
    raise SystemExit("Nothing folded - send me the op census from the check script.")

g.initializer.extend(new_inits)
kept = [n for n in g.node if id(n) not in remove_nodes]

# ---------------- Dead-Code Elimination ----------------
# Clean up the old Cast/Constant zero-point chains and massive float weights
outputs = {o.name for o in g.output}
while True:
    used = {i for n in kept for i in n.input} | outputs
    alive = [n for n in kept if any(o in used for o in n.output)]
    if len(alive) == len(kept):
        break
    kept = alive
    
del g.node[:]
g.node.extend(kept)

used = {i for n in kept for i in n.input}
dead = {i.name for i in g.initializer if i.name not in used}
live_inits = [i for i in g.initializer if i.name in used]

del g.initializer[:]
g.initializer.extend(live_inits)

live_inputs = [i for i in g.input if i.name not in dead]
del g.input[:]
g.input.extend(live_inputs)

# ---------------- Save and Verify ----------------
onnx.checker.check_model(model)
onnx.save(model, DST)

print(f"\nSaved {DST}: {os.path.getsize(DST)/1e6:.2f} MB (was {os.path.getsize(SRC)/1e6:.2f} MB)")
print("Ops:", dict(Counter(n.op_type for n in model.graph.node)).get("QuantizeLinear"), "QuantizeLinear,",
      dict(Counter(n.op_type for n in model.graph.node)).get("DequantizeLinear"), "DequantizeLinear")

# ---- Verify: packed vs original must match, then load in ORT ----
print("\nVerifying math integrity against original model...")
x = np.random.rand(4, 3, 64, 64).astype(np.float32)
a = ort.InferenceSession(SRC, providers=["CPUExecutionProvider"]).run(None, {"input": x})[0]
b = ort.InferenceSession(DST, providers=["CPUExecutionProvider"]).run(None, {"input": x})[0]
print("max abs diff (orig vs packed):", np.abs(a - b).max())
print("argmax match:", (a.argmax(1) == b.argmax(1)).mean())
