import csv
import os
import random
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor

import numpy as np
from PIL import Image

# ---------------- Paths ----------------
data_root = r"C:\Users\MAINAK\ps14\data"
manifest_path = os.path.join(data_root, "manifest.csv")
cache_dir = os.path.join(data_root, "cache")
os.makedirs(cache_dir, exist_ok=True)

# ---------------- Settings (change caps here) ----------------
SEED = 0
NUM_THREADS = 8
TILE = 64
CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]

# No-data filter (optical sources only)
FILTER_SOURCES = {"eurosat", "cloudsen12"}
NODATA_PIXEL_MAX = 6          # a pixel is "black" if all three channels are <= this value (0-255)
NODATA_MAX_FRACTION = 0.005   # drop the tile if more than this share of its pixels are black

# Train split: cap per group. Groups not listed here keep ALL their tiles.
TRAIN_CAPS = {
    "Cloud": 8000,
    "CloudShadow": 8000,
    "CloudBoth": 4000,
    "Clear": 8000,
    "Ship": 15000,
    "NoShip": 15000,
}

# Calibration and test splits: random subset per source (None = keep all).
EVAL_SOURCE_CAPS = {
    "eurosat": None,
    "cloudsen12": 20000,
    "hrsid": 40000,
}

rng = random.Random(SEED)

# ---------------- Read manifest ----------------
with open(manifest_path, newline="", encoding="utf-8") as f:
    all_rows = list(csv.DictReader(f))
print(f"Manifest rows: {len(all_rows)}")


def load_tile(path):
    with Image.open(path) as img:
        img = img.convert("RGB")
        if img.size != (TILE, TILE):
            img = img.resize((TILE, TILE), Image.BILINEAR)
        return np.asarray(img, dtype=np.uint8)


def has_nodata(path):
    arr = load_tile(path)
    black = arr.max(axis=2) <= NODATA_PIXEL_MAX
    return bool(black.mean() > NODATA_MAX_FRACTION)


# ---------------- No-data filter ----------------
to_check = [r for r in all_rows if r["source"] in FILTER_SOURCES]
print(f"Checking {len(to_check)} optical tiles for black no-data borders...")
flags = {}
with ThreadPoolExecutor(max_workers=NUM_THREADS) as ex:
    for i, flag in enumerate(ex.map(has_nodata, [r["path"] for r in to_check])):
        flags[to_check[i]["path"]] = flag
        if (i + 1) % 50000 == 0:
            print(f"  checked {i + 1} / {len(to_check)}")

clean_rows = [r for r in all_rows if not flags.get(r["path"], False)]

total_by_group = Counter(r["group"] for r in all_rows)
removed_by_group = Counter(r["group"] for r in all_rows if flags.get(r["path"], False))
print("\nNo-data filter report (tiles removed per group):")
for g in sorted(total_by_group):
    t, rm = total_by_group[g], removed_by_group.get(g, 0)
    print(f"  {g:12s} removed {rm:7d} of {t:7d}  ({100.0 * rm / t:5.1f}%)")
print(f"Rows kept: {len(clean_rows)} of {len(all_rows)}\n")

by_split = defaultdict(list)
for r in clean_rows:
    by_split[r["split"]].append(r)


# ---------------- Selection ----------------
def select_train(rows):
    groups = defaultdict(list)
    for r in rows:
        groups[r["group"]].append(r)
    chosen = []
    for g in sorted(groups):
        items = groups[g]
        cap = TRAIN_CAPS.get(g)
        if cap is not None and len(items) > cap:
            items = rng.sample(items, cap)
        chosen.extend(items)
    rng.shuffle(chosen)
    return chosen


def select_eval(rows):
    sources = defaultdict(list)
    for r in rows:
        sources[r["source"]].append(r)
    chosen = []
    for s in sorted(sources):
        items = sources[s]
        cap = EVAL_SOURCE_CAPS.get(s)
        if cap is not None and len(items) > cap:
            items = rng.sample(items, cap)
        chosen.extend(items)
    rng.shuffle(chosen)
    return chosen


def channel_stats(X, chunk=5000):
    """Per-channel mean and std over all pixels, scaled to 0-1."""
    n = 0
    s = np.zeros(3, dtype=np.float64)
    s2 = np.zeros(3, dtype=np.float64)
    for i in range(0, len(X), chunk):
        part = X[i:i + chunk].astype(np.float32) / 255.0
        s += part.sum(axis=(0, 1, 2), dtype=np.float64)
        s2 += np.square(part).sum(axis=(0, 1, 2), dtype=np.float64)
        n += part.shape[0] * part.shape[1] * part.shape[2]
    mean = s / n
    std = np.sqrt(np.maximum(s2 / n - mean ** 2, 0.0))
    return mean, std


def build(split, rows):
    n = len(rows)
    X = np.empty((n, TILE, TILE, 3), dtype=np.uint8)
    paths = [r["path"] for r in rows]
    with ThreadPoolExecutor(max_workers=NUM_THREADS) as ex:
        for i, arr in enumerate(ex.map(load_tile, paths)):
            X[i] = arr
            if (i + 1) % 10000 == 0:
                print(f"  [{split}] decoded {i + 1} / {n}")

    Y = np.array([[float(r[f"y_{c}"]) for c in CLASSES] for r in rows], dtype=np.float32)
    M = np.array([[float(r[f"m_{c}"]) for c in CLASSES] for r in rows], dtype=np.float32)
    modality = np.array([0 if r["modality"] == "optical" else 1 for r in rows], dtype=np.int8)
    group = np.array([r["group"] for r in rows])
    source = np.array([r["source"] for r in rows])
    scene = np.array([r["scene"] for r in rows])

    out_path = os.path.join(cache_dir, f"{split}.npz")
    np.savez(out_path, X=X, Y=Y, M=M, modality=modality,
             group=group, source=source, scene=scene)

    print(f"\n[{split}] saved {n} tiles to {out_path} ({X.nbytes / 1e9:.2f} GB of pixels)")
    print(f"[{split}] tiles per group:")
    for g, c in sorted(Counter(group.tolist()).items()):
        print(f"    {g:12s} {c}")
    print(f"[{split}] tiles per source:", dict(Counter(source.tolist())))

    if split == "train":
        print("\nColour check (train split, 0-1 scale): per-source channel mean / std")
        for s in sorted(set(source.tolist())):
            idx = np.where(source == s)[0]
            mean, std = channel_stats(X[idx])
            print(f"    {s:11s} mean R,G,B = {np.round(mean, 3)}   std R,G,B = {np.round(std, 3)}")
        print()


# ---------------- Run ----------------
build("train", select_train(by_split["train"]))
build("cal", select_eval(by_split["cal"]))
build("test", select_eval(by_split["test"]))
print("Cache complete.")
