import json
import os
from PIL import Image

# ---------------- Paths ----------------
hrsid_dir = r"C:\Users\MAINAK\ps14\data\hrsid"
img_dir = os.path.join(hrsid_dir, "JPEGImages")
ann_files = ["train2017.json", "test2017.json"]   # any file that is missing is skipped
output_dir = r"C:\Users\MAINAK\ps14\data\hrsid_patches"
os.makedirs(output_dir, exist_ok=True)

# ---------------- Settings ----------------
patch_size = 64
MIN_FRAC_INSIDE = 0.5   # a ship counts if >= 50% of its box is inside the tile
                        # (or if the ship's centre is inside the tile)

# ---------------- Load annotations ----------------
images, bboxes = {}, {}
for name in ann_files:
    path = os.path.join(hrsid_dir, "annotations", name)
    if not os.path.exists(path):
        print(f"Skipping missing file: {name}")
        continue
    with open(path, "r") as f:
        coco = json.load(f)
    for img in coco["images"]:
        images[img["id"]] = img["file_name"]
        bboxes.setdefault(img["id"], [])
    for ann in coco["annotations"]:
        bboxes[ann["image_id"]].append(ann["bbox"])  # COCO format: [x_min, y_min, width, height]

print(f"Found {len(images)} images.")


def classify_tile(boxes, x0, y0, x1, y1):
    """Return 'Ship', 'NoShip', or None (ambiguous tile, discarded).

    Ship   : some ship has its centre inside the tile, or at least
             MIN_FRAC_INSIDE of its box area inside the tile.
    NoShip : the tile overlaps no ship box at all.
    None   : the tile only clips a sliver of a ship, so the label would be noisy.
    """
    touching = False
    for bx, by, bw, bh in boxes:
        bx2, by2 = bx + bw, by + bh
        iw = min(bx2, x1) - max(bx, x0)
        ih = min(by2, y1) - max(by, y0)
        if iw <= 0 or ih <= 0:
            continue                      # no overlap with this ship
        touching = True
        area = bw * bh
        frac = (iw * ih) / area if area > 0 else 0.0
        cx, cy = bx + bw / 2, by + bh / 2
        if (x0 <= cx < x1 and y0 <= cy < y1) or frac >= MIN_FRAC_INSIDE:
            return "Ship"
    return None if touching else "NoShip"


# ---------------- Slice images ----------------
total = len(images)
n_ship = 0
n_noship = 0
n_skipped = 0

for count, (img_id, filename) in enumerate(images.items(), 1):
    img_path = os.path.join(img_dir, filename)
    if not os.path.exists(img_path):
        continue

    stem = os.path.splitext(filename)[0]
    with Image.open(img_path) as img:
        img = img.convert("RGB")          # 3 channels, same as the other sources
        w, h = img.size
        boxes = bboxes[img_id]

        for i in range(0, h, patch_size):
            for j in range(0, w, patch_size):
                x0, y0, x1, y1 = j, i, j + patch_size, i + patch_size

                # Discard edge tiles that do not fit exactly 64x64
                if x1 > w or y1 > h:
                    continue

                label = classify_tile(boxes, x0, y0, x1, y1)
                if label is None:
                    n_skipped += 1        # ambiguous tile
                    continue

                # Default JPEG quality, same as the CloudSEN12 script
                img.crop((x0, y0, x1, y1)).save(
                    os.path.join(output_dir, f"{stem}_{y0}_{x0}_{label}.jpg")
                )
                if label == "Ship":
                    n_ship += 1
                else:
                    n_noship += 1

    if count % 500 == 0:
        print(f"Processed {count} / {total} images...")

print("HRSID patch extraction complete.")
print(f"Ship tiles: {n_ship} | NoShip tiles: {n_noship} | Ambiguous tiles skipped: {n_skipped}")
