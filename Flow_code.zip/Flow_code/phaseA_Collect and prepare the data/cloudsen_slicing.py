import rasterio as rio
import numpy as np
from PIL import Image
import os
import concurrent.futures
import tacoreader

# Set up directories
output_dir = r"C:\Users\MAINAK\ps14\data\cloudsen12_patches"
os.makedirs(output_dir, exist_ok=True)
patch_size = 64
threshold = 0.05 * (patch_size * patch_size)

# Global variable for the worker processes
worker_dataset = None

def init_worker():
    """Initializes the tacoreader dataset once per CPU core."""
    global worker_dataset
    worker_dataset = tacoreader.load("tacofoundation:cloudsen12-l1c")

def process_image(idx):
    global worker_dataset
    try:
        # Extract path on the fly inside the parallelized worker
        l1c_path = worker_dataset.read(idx).read(0)
        label_path = worker_dataset.read(idx).read(1)
        
        with rio.open(l1c_path) as src, rio.open(label_path) as dst:
            rgb = src.read([4, 3, 2])
            label = dst.read(1)
            
        rgb = np.clip(rgb / 3000, 0, 1)
        rgb = (rgb * 255).astype(np.uint8)
        rgb = rgb.transpose(1, 2, 0)
        
        h, w = label.shape
        
        for i in range(0, h, patch_size):
            for j in range(0, w, patch_size):
                p_xmin, p_ymin = j, i
                p_xmax, p_ymax = j + patch_size, i + patch_size
                
                if p_xmax > w or p_ymax > h:
                    continue
                
                patch_rgb = rgb[p_ymin:p_ymax, p_xmin:p_xmax]
                patch_label = label[p_ymin:p_ymax, p_xmin:p_xmax]
                
                labels = []
                if np.sum((patch_label == 1) | (patch_label == 2)) > threshold:
                    labels.append("Cloud")
                if np.sum(patch_label == 3) > threshold:
                    labels.append("Cloud_shadow")
                if not labels:
                    labels.append("Empty")
                    
                label_str = "_".join(labels)
                patch_img = Image.fromarray(patch_rgb)
                patch_name = f"cloudsen_{idx}_{p_ymin}_{p_xmin}_{label_str}.jpg"
                patch_img.save(os.path.join(output_dir, patch_name))
        return True
    except Exception as e:
        return False

if __name__ == '__main__':
    print("Initializing main process...")
    # Load just to get the total length in the main thread
    main_dataset = tacoreader.load("tacofoundation:cloudsen12-l1c")
    total_images = len(main_dataset)
    indices = list(range(total_images))
    
    print(f"Starting multiprocess extraction for {total_images} images.")
    print("Check your Task Manager - CPU usage should spike to 100%.")
    
    # Fire up all CPU cores, initializing tacoreader on each core
    with concurrent.futures.ProcessPoolExecutor(initializer=init_worker) as executor:
        results = executor.map(process_image, indices, chunksize=50)
        
        for count, _ in enumerate(results, 1):
            if count % 500 == 0:
                print(f"Processed {count} / {total_images} CloudSEN12 images...")
                
    print("Full CloudSEN12 patch extraction complete.")
