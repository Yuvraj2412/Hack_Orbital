import os

import numpy as np
from PIL import Image, ImageDraw

# ---------------- Paths ----------------
data_root = r"C:\Users\MAINAK\ps14\data"
cache_dir = os.path.join(data_root, "cache")
train_path = os.path.join(cache_dir, "train.npz")
montage_path = os.path.join(cache_dir, "colour_check_montage.png")

# ---------------- Settings ----------------
SEED = 0
MAX_TILES_PER_GROUP = 4000        # tiles sampled per group for the statistics
MAX_TILES_PER_SIDE = 8000         # tiles sampled per side in the EuroSAT-vs-Clear test
OPTICAL_GROUPS = ["Forest", "Cropland", "Urban", "Water",
                  "Clear", "Cloud", "CloudShadow", "CloudBoth"]
MONTAGE_GROUPS = ["Forest", "Cropland", "Urban", "Water",
                  "Clear", "Cloud", "CloudShadow", "CloudBoth"]
TILES_PER_ROW = 10
SCALE = 2                          # montage tiles are shown at 2x size
FEATURES = ["mean_R", "mean_G", "mean_B", "brightness", "contrast", "blue_minus_red"]

rng = np.random.default_rng(SEED)

# ---------------- Load ----------------
data = np.load(train_path)
X = data["X"]
group = data["group"]
source = data["source"]
print(f"Loaded {X.shape[0]} train tiles, tile shape {X.shape[1:]}\n")


def sample_idx(mask, n_max):
    idx = np.where(mask)[0]
    if len(idx) > n_max:
        idx = rng.choice(idx, n_max, replace=False)
    return np.sort(idx)


def channel_stats(Xs, chunk=4000):
    """Per-channel pixel mean and std over all pixels, on a 0-1 scale."""
    n = 0
    s = np.zeros(3, dtype=np.float64)
    s2 = np.zeros(3, dtype=np.float64)
    for i in range(0, len(Xs), chunk):
        part = Xs[i:i + chunk].astype(np.float32) / 255.0
        s += part.sum(axis=(0, 1, 2), dtype=np.float64)
        s2 += np.square(part).sum(axis=(0, 1, 2), dtype=np.float64)
        n += part.shape[0] * part.shape[1] * part.shape[2]
    mean = s / n
    std = np.sqrt(np.maximum(s2 / n - mean ** 2, 0.0))
    return mean, std


def tile_features(Xs, chunk=4000):
    """Simple per-tile statistics, one value per tile."""
    out = {k: [] for k in FEATURES}
    for i in range(0, len(Xs), chunk):
        part = Xs[i:i + chunk].astype(np.float32) / 255.0
        m = part.mean(axis=(1, 2))               # (n, 3) mean R, G, B per tile
        gray = part.mean(axis=3)                 # (n, 64, 64)
        out["mean_R"].append(m[:, 0])
        out["mean_G"].append(m[:, 1])
        out["mean_B"].append(m[:, 2])
        out["brightness"].append(m.mean(axis=1))
        out["contrast"].append(gray.std(axis=(1, 2)))
        out["blue_minus_red"].append(m[:, 2] - m[:, 0])
    return {k: np.concatenate(v) for k, v in out.items()}


def separability(a, b):
    """Rank-based AUC between two samples, folded to 0.5 (identical) .. 1.0 (fully separable)."""
    scores = np.concatenate([a, b])
    ranks = scores.argsort().argsort() + 1
    r_a = ranks[:len(a)].sum()
    auc = (r_a - len(a) * (len(a) + 1) / 2) / (len(a) * len(b))
    return max(auc, 1.0 - auc)


# ---------------- 1. Per-group statistics ----------------
print("=" * 78)
print("1. Per-group colour statistics (0-1 scale)")
print("=" * 78)
print(f"{'group':12s} {'n':>6s}  {'pixel mean R,G,B':>22s}  {'pixel std R,G,B':>22s}  "
      f"{'tile bright.':>12s}  {'tile contrast':>13s}")
for g in OPTICAL_GROUPS:
    idx = sample_idx(group == g, MAX_TILES_PER_GROUP)
    if len(idx) == 0:
        print(f"{g:12s} {'0':>6s}  (no tiles)")
        continue
    mean, std = channel_stats(X[idx])
    f = tile_features(X[idx])
    print(f"{g:12s} {len(idx):6d}  "
          f"{str(np.round(mean, 3)):>22s}  {str(np.round(std, 3)):>22s}  "
          f"{f['brightness'].mean():12.3f}  {f['contrast'].mean():13.3f}")

# ---------------- 2. EuroSAT vs CloudSEN12 Clear ----------------
print("\n" + "=" * 78)
print("2. Can simple statistics tell EuroSAT from CloudSEN12 'Clear' tiles apart?")
print("   (0.5 = indistinguishable, 1.0 = perfectly separable)")
print("=" * 78)
idx_e = sample_idx(source == "eurosat", MAX_TILES_PER_SIDE)
idx_c = sample_idx(group == "Clear", MAX_TILES_PER_SIDE)
if len(idx_e) == 0 or len(idx_c) == 0:
    print("Missing EuroSAT or Clear tiles, skipping this section.")
else:
    f_e = tile_features(X[idx_e])
    f_c = tile_features(X[idx_c])
    for k in FEATURES:
        sep = separability(f_e[k], f_c[k])
        flag = "  <-- strong fingerprint" if sep > 0.9 else ("  <-- notable" if sep > 0.75 else "")
        print(f"  {k:15s} EuroSAT mean {f_e[k].mean():7.3f} | Clear mean {f_c[k].mean():7.3f} | "
              f"separability {sep:.3f}{flag}")

    # ---------------- 3. Suggested linear match (reported only) ----------------
    print("\n" + "=" * 78)
    print("3. Per-channel linear match CloudSEN12 -> EuroSAT, fitted on Clear tiles")
    print("   new = gain * old + offset   (0-1 scale; NOT applied to anything)")
    print("=" * 78)
    m_e, s_e = channel_stats(X[idx_e])
    m_c, s_c = channel_stats(X[idx_c])
    gain = s_e / np.maximum(s_c, 1e-6)
    offset = m_e - gain * m_c
    for name, g_, o_ in zip("RGB", gain, offset):
        print(f"  channel {name}: gain = {g_:.3f}, offset = {o_:+.3f}")
    print("  Caveat: EuroSAT and the CloudSEN12 Clear tiles show different landscape mixes, so part\n"
          "  of any gap is real. Treat these numbers as a rough guide, not exact values.")

# ---------------- 4. Montage ----------------
print("\n" + "=" * 78)
print("4. Montage")
print("=" * 78)
tile = X.shape[1]
size = tile * SCALE
label_w = 110
rows_present = [g for g in MONTAGE_GROUPS if (group == g).any()]
canvas = Image.new("RGB", (label_w + TILES_PER_ROW * size, len(rows_present) * size), (30, 30, 30))
draw = ImageDraw.Draw(canvas)
for r, g in enumerate(rows_present):
    idx = sample_idx(group == g, TILES_PER_ROW)
    draw.text((6, r * size + size // 2 - 6), g, fill=(255, 255, 255))
    for c, i in enumerate(idx):
        im = Image.fromarray(X[i]).resize((size, size), Image.NEAREST)
        canvas.paste(im, (label_w + c * size, r * size))
canvas.save(montage_path)
print(f"Saved montage to {montage_path}")
print("Rows, top to bottom:", ", ".join(rows_present))
print("\nDone.")
