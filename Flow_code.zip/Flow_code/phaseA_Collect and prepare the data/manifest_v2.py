import csv
import os
import random
import re
from collections import Counter

import tacoreader

# ---------------- Paths (edit if yours differ) ----------------
data_root = r"C:\Users\MAINAK\ps14\data"
eurosat_dir = os.path.join(data_root, "eurosat")   # folder that CONTAINS the 10 class folders
cloudsen_dir = os.path.join(data_root, "cloudsen12_patches")
hrsid_dir = os.path.join(data_root, "hrsid_patches")
manifest_path = os.path.join(data_root, "manifest.csv")

# ---------------- Settings ----------------
SPLIT_FRACTIONS = (0.70, 0.15)      # train, calibration; the rest is test
SEED = 0
EUROSAT_IS_CLOUD_FREE = True        # EuroSAT tiles are treated as known Cloud=0, CloudShadow=0
                                    # (they were selected to be cloud-free). Set False to mask them.

# None = keep every CloudSEN12 label type found in the folder.
# Set to {"high"} if the printout at the end shows other label types.
CLOUDSEN_KEEP_LABEL_TYPES = {"high"}

CLASSES = ["Forest", "Cropland", "Urban", "Water", "Cloud", "CloudShadow", "Ship"]
LAND = ["Forest", "Cropland", "Urban", "Water"]

# EuroSAT folder -> our class (HerbaceousVegetation is left out)
EUROSAT_MAP = {
    "Forest": "Forest",
    "AnnualCrop": "Cropland",
    "PermanentCrop": "Cropland",
    "Pasture": "Cropland",
    "Residential": "Urban",
    "Industrial": "Urban",
    "Highway": "Urban",
    "River": "Water",
    "SeaLake": "Water",
}

CLOUDSEN_LABELS = {
    # filename suffix -> (group name, cloud flag, shadow flag)
    "Cloud": ("Cloud", 1, 0),
    "Cloud_shadow": ("CloudShadow", 0, 1),
    "Cloud_Cloud_shadow": ("CloudBoth", 1, 1),
    "Empty": ("Clear", 0, 0),        # generator called clear tiles "Empty"
}


def make_row(path, source, modality, group, scene, known):
    """known: dict {class_name: 0 or 1} for the classes whose label is known."""
    row = {"path": path, "source": source, "modality": modality,
           "group": group, "scene": scene}
    for c in CLASSES:
        if c in known:
            row[f"y_{c}"] = known[c]
            row[f"m_{c}"] = 1
        else:
            row[f"y_{c}"] = 0
            row[f"m_{c}"] = 0
    return row


def list_jpgs(folder):
    with os.scandir(folder) as it:
        for entry in it:
            if entry.is_file() and entry.name.lower().endswith(".jpg"):
                yield entry.name, entry.path


# ---------------- CloudSEN12 sample table: sample index -> location + label type ----------------
print("Loading CloudSEN12 metadata table (no pixel data is downloaded)...")
ds = tacoreader.load("tacofoundation:cloudsen12-l1c")
n_table = len(ds)
roi_list = ds["roi_id"].astype(str).tolist()
label_list = ds["label_type"].astype(str).tolist()
index_labels = ds.index.tolist()
print(f"CloudSEN12 table rows: {n_table}")

# Tile filenames use the same number you passed to ds.read(idx). Check whether that number
# is the row POSITION (iloc) or the index LABEL (loc) in this table, by comparing byte offsets.
pos_is_label = index_labels == list(range(n_table))
print("Table index equals row position:", pos_is_label)


def mapping_for(mode):
    if mode == "pos":
        return dict(enumerate(roi_list)), dict(enumerate(label_list))
    return dict(zip(index_labels, roi_list)), dict(zip(index_labels, label_list))


def verify(mode, sample_idx):
    """True/False if verifiable, None if the path format is not recognised."""
    ok = 0
    for idx in sample_idx:
        path = str(ds.read(int(idx)).read(0))
        m = re.search(r"/vsisubfile/(\d+)_(\d+)", path)
        if not m:
            return None
        child_offset = int(m.group(1))
        if mode == "pos":
            off = int(ds["tortilla:offset"].iloc[int(idx)])
            ln = int(ds["tortilla:length"].iloc[int(idx)])
        else:
            off = int(ds["tortilla:offset"].loc[int(idx)])
            ln = int(ds["tortilla:length"].loc[int(idx)])
        if off <= child_offset < off + ln:
            ok += 1
    return ok == len(sample_idx)


rows = []
bad = Counter()
seen_label = Counter()
seen_idx = set()
missing_idx = Counter()
cloudsen_files = []   # (idx, group, cloud, shadow, path)

# ---------------- EuroSAT ----------------
for folder_name, cls in EUROSAT_MAP.items():
    folder = os.path.join(eurosat_dir, folder_name)
    if not os.path.isdir(folder):
        print(f"WARNING: EuroSAT folder not found: {folder}")
        continue
    for fname, fpath in list_jpgs(folder):
        known = {c: 0 for c in LAND}
        known[cls] = 1
        if EUROSAT_IS_CLOUD_FREE:
            known["Cloud"] = 0
            known["CloudShadow"] = 0
        rows.append(make_row(fpath, "eurosat", "optical", cls,
                             f"eurosat_{folder_name}_{fname}", known))

# ---------------- CloudSEN12 ----------------
# filename: cloudsen_{sample_idx}_{y}_{x}_{label}.jpg
if os.path.isdir(cloudsen_dir):
    for fname, fpath in list_jpgs(cloudsen_dir):
        stem = os.path.splitext(fname)[0]
        parts = stem.split("_", 4)
        if len(parts) != 5 or parts[0] != "cloudsen" or parts[4] not in CLOUDSEN_LABELS:
            bad["cloudsen"] += 1
            continue
        try:
            idx = int(parts[1])
        except ValueError:
            bad["cloudsen"] += 1
            continue
        group, cloud, shadow = CLOUDSEN_LABELS[parts[4]]
        cloudsen_files.append((idx, group, cloud, shadow, fpath))
        seen_idx.add(idx)
else:
    print(f"WARNING: folder not found: {cloudsen_dir}")

# Decide how sample numbers map to table rows
if cloudsen_files:
    rng_check = random.Random(SEED)
    sample_idx = rng_check.sample(sorted(seen_idx), min(8, len(seen_idx)))
    result_pos = verify("pos", sample_idx)
    if result_pos is True:
        mode = "pos"
        print("Verified: sample number = table row position.")
    elif result_pos is False and not pos_is_label:
        result_label = verify("label", sample_idx)
        if result_label is True:
            mode = "label"
            print("Verified: sample number = table index label.")
        else:
            raise SystemExit("Could not match sample numbers to table rows (neither position nor "
                             "label verified). Stopping so the split is not built on a wrong mapping. "
                             "Paste this message back.")
    elif result_pos is False:
        raise SystemExit("Sample-number check FAILED even though index equals position. "
                         "Stopping. Paste this message back.")
    else:
        mode = "pos"
        print("WARNING: could not verify the sample-number mapping automatically "
              "(path format not recognised). Assuming row position.")

    ROI_OF, LABEL_OF = mapping_for(mode)

    for idx, group, cloud, shadow, fpath in cloudsen_files:
        if idx not in ROI_OF:
            missing_idx[idx] += 1
            continue
        lt = LABEL_OF[idx]
        seen_label[lt] += 1
        if CLOUDSEN_KEEP_LABEL_TYPES is not None and lt not in CLOUDSEN_KEEP_LABEL_TYPES:
            continue
        known = {"Cloud": cloud, "CloudShadow": shadow}   # land classes stay unknown (masked)
        rows.append(make_row(fpath, "cloudsen12", "optical", group,
                             f"cloudsen_{ROI_OF[idx]}", known))   # scene = location, not photo

# ---------------- HRSID ----------------
# filename: {image_stem}_{y}_{x}_{Ship|NoShip}.jpg   (image_stem may contain underscores)
if os.path.isdir(hrsid_dir):
    for fname, fpath in list_jpgs(hrsid_dir):
        stem = os.path.splitext(fname)[0]
        parts = stem.rsplit("_", 3)
        if len(parts) != 4 or parts[3] not in ("Ship", "NoShip"):
            bad["hrsid"] += 1
            continue
        known = {"Ship": 1 if parts[3] == "Ship" else 0}   # everything else masked
        rows.append(make_row(fpath, "hrsid", "radar", parts[3],
                             f"hrsid_{parts[0]}", known))
else:
    print(f"WARNING: folder not found: {hrsid_dir}")

if bad:
    print("Files with unexpected names (skipped):", dict(bad))
if missing_idx:
    print(f"WARNING: {len(missing_idx)} CloudSEN12 sample numbers were not in the table (skipped).")

# ---------------- Split by scene, separately inside each source ----------------
scenes_by_source = {}
for r in rows:
    scenes_by_source.setdefault(r["source"], set()).add(r["scene"])

rng = random.Random(SEED)
split_of = {}
for source in sorted(scenes_by_source):
    scenes = sorted(scenes_by_source[source])   # sorted first so the shuffle is reproducible
    rng.shuffle(scenes)
    n = len(scenes)
    n_train = int(n * SPLIT_FRACTIONS[0])
    n_cal = int(n * SPLIT_FRACTIONS[1])
    for k, scene in enumerate(scenes):
        if k < n_train:
            split = "train"
        elif k < n_train + n_cal:
            split = "cal"
        else:
            split = "test"
        split_of[(source, scene)] = split

for r in rows:
    r["split"] = split_of[(r["source"], r["scene"])]

# ---------------- Write CSV ----------------
fieldnames = (["path", "source", "modality", "group", "scene", "split"]
              + [f"y_{c}" for c in CLASSES] + [f"m_{c}" for c in CLASSES])
with open(manifest_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

# ---------------- Summary ----------------
print(f"\nWrote {len(rows)} rows to {manifest_path}\n")

print("Tiles per source and split:")
by_ss = Counter((r["source"], r["split"]) for r in rows)
for source in sorted(scenes_by_source):
    print(f"  {source:11s}", {s: by_ss[(source, s)] for s in ("train", "cal", "test")})

print("\nTiles per group (all splits):")
for g, n in sorted(Counter(r["group"] for r in rows).items()):
    print(f"  {g:12s} {n}")

print("\nKnown positives per output class (train split):")
for c in CLASSES:
    pos = sum(1 for r in rows if r["split"] == "train" and r[f"m_{c}"] == 1 and r[f"y_{c}"] == 1)
    neg = sum(1 for r in rows if r["split"] == "train" and r[f"m_{c}"] == 1 and r[f"y_{c}"] == 0)
    print(f"  {c:12s} positives: {pos:8d}   known negatives: {neg:8d}")

# ---------------- CloudSEN12 checks ----------------
print("\nCloudSEN12 tiles by label_type:", dict(seen_label))
if seen_idx:
    locs = {ROI_OF[i] for i in seen_idx if i in ROI_OF}
    print("CloudSEN12 distinct samples found:", len(seen_idx),
          "| distinct locations:", len(locs),
          "| highest sample number:", max(seen_idx))
chk = {}
for r in rows:
    if r["source"] == "cloudsen12":
        chk.setdefault(r["scene"], set()).add(r["split"])
leaks = sum(len(v) > 1 for v in chk.values())
print("CloudSEN12 locations appearing in more than one split:", leaks, "(must be 0)")
